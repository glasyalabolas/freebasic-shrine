#ifndef __config_h__
#define __config_h__

#define STBI_NO_WRITE

//#define STBI_NO_BMP
//#define STBI_NO_PNG
//#define STBI_NO_TGA
//#define STBI_NO_JPG
//#define STBI_NO_DDS
#define STBI_NO_PSD
#define STBI_NO_HDR



#endif // __config_h__
