OpenCL 1.0,1.1 for FreeBASIC 
-----------------------------
Windows:
copy cl.bi and cl_helpers.bi to your FreeBASIC\inc folder

Windows x86:
copy lib/win32/libOpenCL.dll.a to your FreeBASIC\lib\win32 folder

Windows x86_64:
copy lib/win64/libOpenCL.dll.a to your FreeBASIC\lib\win64 folder



Linux:
copy cl.bi and cl_helpers.bi to your user/local/freebasic/include folder

be sure the path to libOpenCL.so is in LD_LIBRARY_PATH 

or set the path for the linker manualy:
fbc -p path_to_libOpenCL_so xxx.bas

on my ubuntu it's "/usr/lib/x86_64-linux-gnu"


NOTE: if you are use OpenCL with OpenGL include gl.bi at first

#include "GL/gl.bi"
#include "cl.bi"
or 
#include "GL/gl.bi"
#include "cl_helpers.bi"


"a must read" for OpenCL beginners: 

A Gentle Introduction to OpenCL 
http://www.drdobbs.com/parallel/a-gentle-introduction-to-opencl/231002854


look also at:
OpenCL/doc/opencl-1.1.pdf
OpenCL/doc/opencl-1-1-quick-reference-card.pdf

khronos OpenCL forum:
http://forums.khronos.org/forumdisplay.php/87-OpenCL-parallel-programming-of-heterogeneous-systems

free online book: "The OpenCL Programming Book"
http://www.fixstars.com/en/opencl/book/OpenCLProgrammingBook/contents/
source codes: http://www.fixstars.com/files/opencl/samples.zip

book: Matthew Scarpino "OpenCL in action"
http://www.manning.com/books/opencl-in-action/
source codes: http://manning-content.s3.amazonaws.com/download/9/e558a4c-25b9-47a4-8074-f9f05dd56222/source_code_gnu.zip

book: OpenCL Programming Guide
http://www.heterogeneouscompute.org/?page_id=5
source codes: http://github.com/bgaster/opencl-book-samples
