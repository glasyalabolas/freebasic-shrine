#ifndef OPENCL_MATH
#define OPENCL_MATH

// kernel 
// __attribute__((reqd_work_group_size(X, Y, Z)))
// __attribute__((work_group_size_hint(X, Y, Z)))

// function
// __attribute__((always_inline))         // on
// __attribute__((noinline))              // off
// __attribute__((opencl_unroll_hint(N))) // on
// __attribute__((opencl_unroll_hint(0))) // off

float3 reflect(float3 V, float3 N) {
  return V - 2.0f * dot( V, N ) * N;
}

float3 refract(float3 V, float3 N, float ior) {
  float c1 = -dot( N, V );
  float c2 = 1.0f - ior*ior * (1.0f - c1 * c1);
  return (ior * V) + (ior * c1 - sqrt( c2 )) * N;
}

#endif
