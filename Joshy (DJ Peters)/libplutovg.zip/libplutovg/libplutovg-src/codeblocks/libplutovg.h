#ifndef __MAIN_H__
#define __MAIN_H__

/*
' JavaScript: Evan Wallace     https://github.com/evanw/csg.js/
' C PlusPlus: Tomasz Dabrowski https://github.com/dabroz/csgjs-cpp/blob/master/csgjs.cpp
' FreeBASIC : D.J.Peters       http://freebasic.net/forum/
*/

#ifdef WIN32
 #ifdef BUILD_DLL
  #define DLL_EXPORT __declspec(dllexport)
 #else
  #define DLL_EXPORT __declspec(dllimport)
 #endif
#else
 #define DLL_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif


// csg_mesh* DLL_EXPORT csg_trianglemesh_union(const csg_mesh* meshA, const csg_mesh* meshB);






#ifdef __cplusplus
}
#endif

#endif // __MAIN_H__
