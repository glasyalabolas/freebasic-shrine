PlutoVG is a komplete standalone 2D vector graphics C library.

https://github.com/sammycage/plutovg

Included are 32/64-bit static and dýnamic libs for Windows and Linux.

I prefer static linking for FreeBASIC

#define LIBPLUTOVG_STATIC
#include "plutovg.bi"
' ...

For other devices then x86,x86_64 eg. ARM / ARM64
I created in the libplutovg-src folder a codeblocks folder
you can open the libplutovg.workspace with the codeblocks IDE
and rebuild static/dynamic 32/64-bit libs for Windows or any Linux device.

Joshy
