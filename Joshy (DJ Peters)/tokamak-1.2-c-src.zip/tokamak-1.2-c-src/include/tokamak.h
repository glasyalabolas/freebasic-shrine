#ifndef TOKAMAK_H
#define TOKAMAK_H

/// !!!! added
#define NO_PERFORMANCE
#define NO_ANIMATED_SENSOR
/// #define NO_SLIDER
/// #define NO_LOG
/// #define NO_BREAKAGE
/// #define NO_JOINT_UERDATA

/*************************************************************************
 *                                                                       *
 * Tokamak Physics Engine, Copyright (C) 2002-2007 David Lam.            *
 * All rights reserved.  Email: david@tokamakphysics.com                 *
 *                       Web: www.tokamakphysics.com                     *
 *                                                                       *
 * This library is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    *
 * LICENSE.TXT for more details.                                         *
 *                                                                       *
 *************************************************************************/

#define TOKAMAK_VERSION_MAJOR 1
#define TOKAMAK_VERSION_MINOR 2
#define TOKAMAK_VERSION_BUGFIX 0

#define TOKAMAK_VERSION  (( TOKAMAK_VERSION_MAJOR <<24)+(TOKAMAK_VERSION_MINOR <<16)+(TOKAMAK_VERSION_BUGFIX <<8) + 0)

#include <malloc.h>

#include "math/ne_math.h"

#ifdef TOKAMAK_USE_DLL
 #ifdef TOKAMAK_DLL_EXPORTS
  #define TOKAMAK_API __declspec(dllexport)
 #else
  #define TOKAMAK_API __declspec(dllimport)
 #endif
#else
 #define TOKAMAK_API
#endif

/*
#define NE_INTERFACE(n)         \
protected: n(){                 \
  };                            \
  n & operator = (const n & e){ \
  if (&e != 0) {}               \
  return (*this);               \
  }
*/
/// !!!! changed
#define NE_INTERFACE(_type_) \
  protected: _type_() { }; \
  _type_ & operator = (const _type_ & e){ \
  return (*this); \
}


class TOKAMAK_API neRigidBody;

typedef neEnum neBodyType;
enum {
  NE_TERRAIN = 0,
  NE_RIGID_BODY,
  NE_ANIMATED_BODY
};

/****************************************************************************
*  Class: neAllocatorAbstract
****************************************************************************/
class neAllocatorAbstract {
  public:
  virtual neByte * Alloc(s32 size, s32 alignment = 0) = 0;
  virtual void   Free(neByte *) = 0;
};

/****************************************************************************
*  Class: neAllocatorDefault
****************************************************************************/
class neAllocatorDefault : public neAllocatorAbstract {
  public:
  neAllocatorDefault() {
    usedMem = 0;
  }
  neByte * Alloc(s32 size, s32 alignment = 0) {
    alignment=alignment;
    usedMem += size;
    return (neByte *)malloc(size);
  }
  void Free(neByte * ptr) {
    free(ptr);
  }
  public:
  s32 usedMem;
};


/****************************************************************************
*  Class: nePerformanceReport
****************************************************************************/
#ifndef NO_PERFORMANCE
class nePerformanceReport {
  public:
  enum {
    NE_PERF_TOTAL_TIME = 0,
    NE_PERF_DYNAMIC,
    NE_PERF_POSITION,
    NE_PERF_CONTRAIN_SOLVING_1,
    NE_PERF_CONTRAIN_SOLVING_2,
    NE_PERF_COLLISION_DETECTION,
    NE_PERF_COLLISION_CULLING,
    NE_PERF_TERRAIN_CULLING,
    NE_PERF_TERRAIN,
    NE_PERF_CONTROLLER_CALLBACK,
    NE_PERF_LAST
  };
  enum {
    NE_PERF_RUNNING_AVERAGE = 0,
    NE_PERF_SAMPLE
  };
  f32 time[NE_PERF_LAST];
  f32 accTime[NE_PERF_LAST];

  void Reset() {
    for (s32 i = 0; i < NE_PERF_LAST; i++) {
      time[i] = 0.0f;
      accTime[i] = 0.0f;
    }
    numSample = 0;
  }
  void SetReportType(s32 type) {
    reportType = type;
  }
  s32 reportType;
  s32 numSample;
};
#endif

/****************************************************************************
*  Class: neGeometry
****************************************************************************/
class TOKAMAK_API neGeometry;

#ifndef NO_BREAKAGE
typedef void (neBreakageCallback)(neByte * originalBody, u32 bodyType,
                                  neGeometry * brokenGeometry,
                                  neRigidBody * newBody);
#endif

class TOKAMAK_API neGeometry {
  NE_INTERFACE(neGeometry)
  public:
  typedef neEnum neBreakFlag;
  enum {
    NE_BREAK_DISABLE,
    NE_BREAK_NORMAL,
    NE_BREAK_ALL,
    NE_BREAK_NEIGHBOUR,
    //!  the following are the same as above,
    //!  except it create a rigid particle instead of a rigid body
    NE_BREAK_NORMAL_PARTICLE,
    NE_BREAK_ALL_PARTICLE,
    NE_BREAK_NEIGHBOUR_PARTICLE
  };

  public:
  u32   GetType();  /// !!! added

  void  SetTransform(neT3 & t);
  neT3  GetTransform();

  void  SetMaterialIndex(s32 index);
  s32   GetMaterialIndex();

  void  SetUserData(void* userData);
  void* GetUserData();

  /* Box */
  void   SetBoxSize(f32 width, f32 height, f32 depth);
  void   SetBoxSize(const neV3 & boxSize);
  neBool GetBoxSize(neV3 & boxSize); //! return false if geometry is not a box

  /*  Sphere */
  void   SetSphereDiameter(f32 diameter);
  neBool GetSphereDiameter(f32 & diameter); //! return false if geometry is not a sphere

  /* Cylinder  */
  void   SetCapsule(f32 diameter, f32 height);
  neBool GetCapsule(f32 & diameter, f32 & height); //! return false if geometry is not a cylinder

  /* Convex  */
  void   SetConvexMesh(neByte * convexData);
  neBool GetConvexMesh(neByte * & convexData);

#ifndef NO_BREAKAGE
  /// Breakage functions
  void  SetBreakageFlag(neBreakFlag flag);
  neBreakFlag GetBreakageFlag();

  void  SetBreakageMass(f32 mass);
  f32   GetBreakageMass();

  void  SetBreakageInertiaTensor(const neV3 & tensor);
  neV3  GetBreakageInertiaTensor();

  void  SetBreakageMagnitude(f32 mag);
  f32   GetBreakageMagnitude();

  void  SetBreakageAbsorption(f32 absorb);
  f32   GetBreakageAbsorption();

  void  SetBreakagePlane(const neV3 & planeNormal);
  neV3  GetBreakagePlane();

  void  SetBreakageNeighbourRadius(f32 radius);
  f32   GetBreakageNeighbourRadius();
#endif

};

/*******************
* class neTriangle *
*******************/
class neTriangle {
  public:
  typedef neEnum TriangleType;
  enum {
    NE_TRI_TRIANGLE = 0,
    NE_TRI_HEIGHT_MAP,
  };

  neTriangle() {
    indices[0] = -1;
    indices[1] = -1;
    indices[2] = -1;
    materialID = 0;
    flag = NE_TRI_TRIANGLE;
    userData = NULL;
  }

  s32 indices[3];
  s32 materialID;
  u32 flag;
  void* userData;
};
/***********************
* class neTriangleMesh *
***********************/
class neTriangleMesh {
  public:
  neV3 *       vertices;
  s32          vertexCount;
  neTriangle * triangles;
  s32          triangleCount;
  u32          privList; /// !!! added
};

/******************
*  class neSensor *
******************/
class TOKAMAK_API neRigidBody;
class TOKAMAK_API neAnimatedBody;

class TOKAMAK_API neSensor {
  NE_INTERFACE(neSensor)
  public:
  void  SetUserData(void* userData);
  void* GetUserData();

  void  SetLineSensor(const neV3 & pos, const neV3 & lineVector);

  neV3  GetLineVector();
  neV3  GetLineUnitVector();
  neV3  GetLinePos();
  f32   GetDetectDepth();
  neV3  GetDetectNormal();
  neV3  GetDetectContactPoint();
  neRigidBody    * GetDetectRigidBody();
  neAnimatedBody * GetDetectAnimatedBody();
  s32   GetDetectMaterial();
};

/***********************
* class neAnimatedBody *
************************/
class TOKAMAK_API neAnimatedBody {
  NE_INTERFACE(neAnimatedBody)

  public:
  void  SetUserData(void* userData);
  void* GetUserData();

  //! spatial states
  void  SetPos(const neV3 & p);
  neV3  GetPos();

  void  SetRotationM3(const neM3 & m);
  neM3  GetRotationM3();

  void  SetRotationQ(const neQ & q);
  neQ   GetRotationQ();

  neT3  GetTransform();

  //! collision related
  void  SetCollisionID(s32 cid);
  s32   GetCollisionID();

  //! collision geometries and sensors
  s32 GetGeometryCount();
  neGeometry * AddGeometry();
  neBool RemoveGeometry(neGeometry * g);
  void  BeginIterateGeometry();
  neGeometry * GetNextGeometry();

  neRigidBody * BreakGeometry(neGeometry * g);
#ifndef NO_ANIMATED_SENSOR
  neSensor * AddSensor();
  neBool RemoveSensor(neSensor * s);
  void BeginIterateSensor();
  neSensor * GetNextSensor();
#endif // NO_ANIMATED_SENSOR
  void UpdateBoundingInfo();

  void UseCustomCollisionDetection(neBool yes, const neT3 * obb, f32 boundingRadius);
  neBool UseCustomCollisionDetection();

  //! collide with any body which connected via neJoint to this body indirectly
  void CollideConnected(neBool yes);
  neBool CollideConnected();

  //! collide with any body which connected to this body directly
  void CollideDirectlyConnected(neBool yes);
  neBool CollideDirectlyConnected();

  void  Active(neBool yes, neRigidBody    * hint = NULL);
  void  Active(neBool yes, neAnimatedBody * hint = NULL);
  neBool  Active();
};

/****************************************************************************
*  Class: neRigidBody
****************************************************************************/
class TOKAMAK_API neRigidBodyController;
class TOKAMAK_API neJointController;


typedef void RigidBodyControllerCallback(neRigidBodyController * controller, f32 timeStep);
typedef void JointControllerCallback    (neJointController     * controller, f32 timeStep);

class TOKAMAK_API neRigidBody {
  NE_INTERFACE(neRigidBody)

  public:
  //! physical properties
  f32  GetMass();
  void SetMass(f32 mass);

  void SetInertiaTensor(const neM3 & tensor);
  void SetInertiaTensor(const neV3 & tensor);

  //! other properties
  void SetCollisionID(s32 cid);
  s32  GetCollisionID();

  void  SetUserData(void* userData);
  void* GetUserData();

  void SetLinearDamping(f32 damp);
  f32  GetLinearDamping();

  void SetAngularDamping(f32 damp);
  f32  GetAngularDamping();

  void SetSleepingParameter(f32 sleepingparam);
  f32  GetSleepingParameter();

  //! collision geometries, sensors and controllers
  neGeometry * AddGeometry();
  neBool RemoveGeometry(neGeometry * g);

  s32 GetGeometryCount();

  void BeginIterateGeometry();
  neGeometry *  GetNextGeometry();

  neRigidBody * BreakGeometry(neGeometry * g);

  void   UseCustomCollisionDetection(neBool yes,  const neT3 * obb, f32 boundingRadius);
  neBool UseCustomCollisionDetection();

  neSensor * AddSensor();
  neBool RemoveSensor(neSensor * s);

  void BeginIterateSensor();
  neSensor *  GetNextSensor();

  neRigidBodyController * AddController(RigidBodyControllerCallback * rbccb, s32 period);
  neBool RemoveController(neRigidBodyController * rbController);
  void BeginIterateController();
  neRigidBodyController * GetNextController();

  //! spatial states
  void SetPos(const neV3 & p);
  neV3 GetPos();

  void SetRotationM3(const neM3 & m);
  neM3 GetRotationM3();

  void SetRotationQ(const neQ & q);
  neQ  GetRotationQ();

  neT3 GetTransform();

  //! dynamic states
  void SetVelocity(const neV3 & v);
  neV3 GetVelocity();
  neV3 GetVelocityAtPoint(const neV3 & pt);

  neV3 GetAngularVelocity();

  void SetAngularMomentum(const neV3& am);
  neV3 GetAngularMomentum();


  //! functions
  void UpdateBoundingInfo();
  void UpdateInertiaTensor();

  void SetForce(const neV3 & force);
  void SetTorque(const neV3 & torque);
  void SetForce(const neV3 & force, const neV3 & pos);

  neV3 GetForce();
  neV3 GetTorque();

  void ApplyImpulse(const neV3 & impulse);
  void ApplyImpulse(const neV3 & impulse, const neV3 & pos);

  void ApplyTwist(const neV3 & twist);

  void GravityEnable(neBool yes);
  neBool GravityEnable();

  //! collide with any body which connected to this body indirectly
  void CollideConnected(neBool yes);
  neBool CollideConnected();

  //! collide with any body which connected to this body directly
  void CollideDirectlyConnected(neBool yes);
  neBool CollideDirectlyConnected();

  void Active(neBool yes, neRigidBody * hint = NULL);
  void Active(neBool yes, neAnimatedBody * hint = NULL);

  neBool Active();
  neBool IsIdle();
  void   WakeUp();
  neBool IsParticle();
};

/****************
* class neJoint *
****************/
class TOKAMAK_API neJoint {
  NE_INTERFACE(neJoint)

  public:
  typedef neEnum ConstraintType;
  enum {
    NE_JOINT_BALLSOCKET,
    NE_JOINT_HINGE,
#ifndef NO_SLIDER
    NE_JOINT_SLIDE
#endif
  };

  void SetType(ConstraintType t);
  ConstraintType GetType();

  void SetJointFrameA(const neT3 & frameA);
  neT3 GetJointFrameA();

  void SetJointFrameB(const neT3 & frameB);
  neT3 GetJointFrameB();

  void SetJointFrameWorld(const neT3 & frame);

  void SetJointLength(f32 length);
  f32 GetJointLength();

  neRigidBody * GetRigidBodyA();
  neRigidBody * GetRigidBodyB();
  neAnimatedBody * GetAnimatedBodyB();

  void Enable(neBool yes);
  neBool IsEnabled();

  void  SetUserData(void* ud);
  void* GetUserData();

  void SetDampingFactor(f32 damp);
  f32 GetDampingFactor();

  /* Constraint primary limit functions  */
  void EnableLimit(neBool yes);
  neBool EnableLimit();

  void SetUpperLimit(f32 upperLimit);
  f32 GetUpperLimit();

  void SetLowerLimit(f32 lowerLimit);
  f32 GetLowerLimit();

  /*  Constraint secondary limit functions (only apply to some Constraint types)  */
  void EnableLimit2(neBool yes);
  neBool EnableLimit2();

  void SetUpperLimit2(f32 upperLimit);
  f32 GetUpperLimit2();

  void SetLowerLimit2(f32 lowerLimit);
  f32 GetLowerLimit2();

  /* relates to accuracy and speed of the joint solver */
  void SetEpsilon(f32 e);
  f32 GetEpsilon();

  void SetIteration(s32 i);
  s32 GetIteration();

  //! Constraint controller functions
  neJointController * AddController(JointControllerCallback * jccb, s32 period);
  neBool  RemoveController(neJointController * controller);
  void  BeginIterateController();
  neJointController * GetNextController();

  //! Constraint primary motor function, currently only implemented for hinge Constraint
  void EnableMotor(neBool yes);
  neBool EnableMotor();

  void SetMotor(f32   desireValue, f32   maxForce);
  void GetMotor(f32 & desireValue, f32 & maxForce);
};

/*******************************
* Class: neRigidBodyController *
*******************************/
class TOKAMAK_API neRigidBodyController {
  NE_INTERFACE(neRigidBodyController);
  public:
  neRigidBody * GetRigidBody();

  void SetControllerForceV3(const neV3 & force);
  neV3 GetControllerForceV3();

  void SetControllerTorqueV3(const neV3 & torque);
  neV3 GetControllerTorqueV3();

  void SetControllerForceWithTorqueV3(const neV3 & force, const neV3 & pos);
};
/***************************
* Class: neJointController *
***************************/
class TOKAMAK_API neJointController {
  NE_INTERFACE(neJointController);

  public:
  neJoint * GetJoint();

  void SetControllerForceBodyAV3(const neV3 & force);
  neV3 GetControllerForceBodyAV3();

  void SetControllerForceBodyBV3(const neV3 & force);
  neV3 GetControllerForceBodyBV3();

  void SetControllerTorqueBodyAV3(const neV3 & torque);
  neV3 GetControllerTorqueBodyAV3();

  void SetControllerTorqueBodyBV3(const neV3 & torque);
  neV3 GetControllerTorqueBodyBV3();

  void SetControllerForceWithTorqueBodyAV3(const neV3 & force, const neV3 & pos);
  void SetControllerForceWithTorqueBodyBV3(const neV3 & force, const neV3 & pos);

};
/**************************
* Class: neCollisionTable *
**************************/
class TOKAMAK_API neCollisionTable {
  NE_INTERFACE(neCollisionTable)

  public:
  typedef neEnum neReponseBitFlag;
  enum {
    RESPONSE_IGNORE           = 0,
    RESPONSE_IMPULSE          = 1,
    RESPONSE_CALLBACK         = 2,
    RESPONSE_IMPULSE_CALLBACK = 3,
  };

  enum {
    NE_COLLISION_TABLE_MAX = 64,
  };
  void Set(s32 collisionID1, s32 collisionID2, neReponseBitFlag response = RESPONSE_IMPULSE);

  neReponseBitFlag Get(s32 collisionID1, s32 collisionID2);

  s32 GetMaxCollisionID();
};

/*****************************
* Class: neSimulatorSizeInfo *
*****************************/
class neSimulatorSizeInfo {
  public:
  enum {
    DEFAULT_RIGIDBODIES_COUNT          = 50,
    DEFAULT_ANIMATEDBODIES_COUNT       = 50,
    DEFAULT_RIGIDPARTICLES_COUNT       = 50,

    DEFAULT_CONTROLLERS_COUNT          = 50,
    DEFAULT_OVERLAPPED_PAIRS_COUNT     = 1225,

    DEFAULT_GEOMETRIES_COUNT           = 50,

    DEFAULT_CONSTRAINTS_COUNT          = 100,
    DEFAULT_CONTRAINT_SETS_COUNT       = 100,
    DEFAULT_SOLVER_BUFFER_SIZE         = 2000,
    DEFAULT_SENSORS_COUNT              = 100,

    DEFAULT_TERRAIN_NODES_START_COUNT  = 200,
    DEFAULT_TERRAIN_NODES_GROWBY_COUNT = -1
  };

  s32 rigidBodiesCount;      /* Number of rigid bodies in the simulation */
  s32 animatedBodiesCount;   /* Number of animated bodies in the simulation */
  s32 rigidParticleCount;    /* Number of rigid particles in the simulation */

  s32 controllersCount;      /* Number of controller instances in the simulation */

  s32 overlappedPairsCount;  /* Number of possible overlapping pairs.
                               This has the maximum value of (n x (n - 1)) / 2,
                               where n = rigidBodyCount + animatedBodyCount.
                               But in practice it rarely reach that high.
                               You can try to specify a smaller number to save memory.
                             */
  s32 geometriesCount;       /* Number of collision geometries in the simulator*/

  s32 constraintsCount;      /* Number of joints in the simulation */
  s32 constraintSetsCount;   /* Number of joint Sets in the simulation */
  s32 constraintBufferSize;  /* Size of the buffer use to solve joints */
  s32 sensorsCount;

  s32 terrainNodesStartCount;  /* Number of nodes use to store terrain triangles */
  s32 terrainNodesGrowByCount; /* Grow by this size if run out of nodes */


  neSimulatorSizeInfo()  {  /* Fill with default size values */
    rigidBodiesCount        = DEFAULT_RIGIDBODIES_COUNT;
    animatedBodiesCount     = DEFAULT_ANIMATEDBODIES_COUNT;
    rigidParticleCount      = DEFAULT_RIGIDPARTICLES_COUNT;
    controllersCount        = DEFAULT_CONTROLLERS_COUNT;
    overlappedPairsCount    = DEFAULT_OVERLAPPED_PAIRS_COUNT;
    geometriesCount         = DEFAULT_GEOMETRIES_COUNT;
    constraintsCount        = DEFAULT_CONSTRAINTS_COUNT;
    constraintSetsCount     = DEFAULT_CONTRAINT_SETS_COUNT;
    constraintBufferSize    = DEFAULT_SOLVER_BUFFER_SIZE;
    sensorsCount            = DEFAULT_SENSORS_COUNT;
    terrainNodesStartCount  = DEFAULT_TERRAIN_NODES_START_COUNT;
    terrainNodesGrowByCount = DEFAULT_TERRAIN_NODES_GROWBY_COUNT;
    //! -1 signify double the number of terrainNode, whenever the it reach full capacity.
  }
};

/*********************
* Class: neSimulator *
*********************/
typedef struct neCollisionInfo neCollisionInfo;

struct neCollisionInfo {
  neByte * bodyA;
  neByte * bodyB;
  //! neBodyType typeA;
  //! neBodyType typeB;
  u32 typeA;
  u32 typeB;
  neGeometry * geometryA;
  neGeometry * geometryB;
  s32  materialIdA;
  s32  materialIdB;
  neV3 bodyContactPointA;   //! contact point A in body space of A
  neV3 bodyContactPointB;   //! contact point B in body space of B
  neV3 worldContactPointA;  //! contact point A in world space
  neV3 worldContactPointB;  //! contact point B in world space
  neV3 relativeVelocity;
  neV3 collisionNormal;
};

#ifndef NO_LOG
typedef void (neLogOutputCallback)(char * logString);
#endif

typedef void (neCollisionCallback)(neCollisionInfo & collisionInfo);
typedef void (neTerrainTriangleQueryCallback)(const neV3 & minBound, const neV3 & maxBound,
                                              s32 ** candidateTriangles,
                                              neTriangle ** triangles,
                                              neV3 ** vertices,
                                              s32 * candidateCount,
                                              s32 * triangleCount,
                                              neRigidBody * body);

typedef struct neCustomCDInfo neCustomCDInfo;

struct neCustomCDInfo {
  neV3 collisionNormal;
  neV3 worldContactPointA;
  neV3 worldContactPointB;
  f32 penetrationDepth;
  s32 materialIdA;
  s32 materialIdB;
};

typedef bool (neCustomCDRB2RBCallback)(neRigidBody * bodyA, neRigidBody    * bodyB, neCustomCDInfo & cdInfo);
typedef bool (neCustomCDRB2ABCallback)(neRigidBody * bodyA, neAnimatedBody * bodyB, neCustomCDInfo & cdInfo);

class TOKAMAK_API neSimulator {
  NE_INTERFACE(neSimulator)

  public:
  typedef neEnum LOG_OUTPUT_LEVEL;
  enum {
    LOG_OUTPUT_LEVEL_NONE = 0,
    LOG_OUTPUT_LEVEL_ONE,
    LOG_OUTPUT_LEVEL_FULL,
  };

  public:
  /// Static factory functions
  static neSimulator * CreateSimulator(const neSimulatorSizeInfo & sizeInfo,
                                       neAllocatorAbstract * alloc = NULL,
                                       const neV3 * gravity = NULL);

  static void DestroySimulator(neSimulator * sim);

  /// Rigid body management functions
  neRigidBody * CreateRigidBody();
  neRigidBody * CreateRigidParticle();
  void FreeRigidBody(neRigidBody * body);
  neAnimatedBody * CreateAnimatedBody();
  void FreeAnimatedBody(neAnimatedBody * body);

  /// Active iteration
  neAnimatedBody * BeginIterateActiveAnimatedBody();
  neAnimatedBody * GetNextActiveAnimatedBody(neAnimatedBody* ab);

  neRigidBody * BeginIterateActiveRigidBody();
  neRigidBody * GetNextActiveRigidBody(neRigidBody* rb);

  neRigidBody * BeginIterateActiveRigidParticleBody();
  neRigidBody * GetNextActiveRigidParticleBody(neRigidBody* rb);

  /// Inactive iteration
  neAnimatedBody * BeginIterateInactiveAnimatedBody();
  neAnimatedBody * GetNextInactiveAnimatedBody(neAnimatedBody* ab);

  neRigidBody * BeginIterateInactiveRigidBody();
  neRigidBody * GetNextInactiveRigidBody(neRigidBody* rb);

  neRigidBody * BeginIterateInactiveRigidParticleBody();
  neRigidBody * GetNextInactiveRigidParticleBody(neRigidBody* rb);

  neCollisionTable * GetCollisionTable();

  /// Material management functions
  bool SetMaterial(s32 index, f32   friction, f32   restitution);
  bool GetMaterial(s32 index, f32 & friction, f32 & restitution);

  /* Advancing the simulation  */
#ifndef NO_PERFORMANCE
  void Advance(f32 sec, s32 nSteps = 1, nePerformanceReport * perfReport = NULL);
  void Advance(f32 sec, f32 minTimeStep, f32 maxTimeStep, nePerformanceReport * perfReport = NULL);
#else
  void Advance(f32 sec, s32 nSteps = 1);
  void Advance(f32 sec, f32 minTimeStep, f32 maxTimeStep);
#endif

  /// Terrain setup function
  void SetTerrainMesh(neTriangleMesh * tris);
  void FreeTerrainMesh();

  /// Constraint related
  neJoint * CreateJoint(neRigidBody * bodyA);
  neJoint * CreateJoint(neRigidBody * bodyA, neRigidBody    * bodyB);
  neJoint * CreateJoint(neRigidBody * bodyA, neAnimatedBody * bodyB);
  void FreeJoint(neJoint * joint);

  /* Others */
  void SetGravity(const neV3 & gravity);
  neV3 GetGravity();


#ifndef NO_BREAKAGE
  void SetBreakageCallback(neBreakageCallback * cb);
  neBreakageCallback * GetBreakageCallback();
#endif

  void SetCollisionCallback(neCollisionCallback * cb);
  neCollisionCallback * GetCollisionCallback();

  void SetTerrainTriangleQueryCallback(neTerrainTriangleQueryCallback * cb);
  neTerrainTriangleQueryCallback * GetTerrainTriangleQueryCallback();

  void SetCustomCDRB2RBCallback(neCustomCDRB2RBCallback * cb);
  neCustomCDRB2RBCallback * GetCustomCDRB2RBCallback();

  void SetCustomCDRB2ABCallback(neCustomCDRB2ABCallback * cb);
  neCustomCDRB2ABCallback * GetCustomCDRB2ABCallback();

#ifndef NO_LOG
  void SetLogOutputCallback(neLogOutputCallback * cb);
  neLogOutputCallback * GetLogOutputCallback();
  void SetLogOutputLevel(LOG_OUTPUT_LEVEL lvl = LOG_OUTPUT_LEVEL_FULL);
  LOG_OUTPUT_LEVEL GetLogOutputLevel();
#endif

  neSimulatorSizeInfo GetCurrentSizeInfo();
  neSimulatorSizeInfo GetStartSizeInfo();

  void GetMemoryAllocated(s32 & memoryAllocated);

  s32 GetIdleBodyCount();

};

/****************************************************************************
*  Misc. helper functions
****************************************************************************/
neV3 TOKAMAK_API neBoxInertiaTensor(f32 width, f32 height, f32 depth, f32 mass);
neV3 TOKAMAK_API neBoxInertiaTensor(const neV3 & boxSize, f32 mass);
neV3 TOKAMAK_API neSphereInertiaTensor(f32 diameter, f32 mass);
neV3 TOKAMAK_API neCapsuleInertiaTensor(f32 diameter, f32 height, f32 mass);

#endif //! TOKAMAK_H
