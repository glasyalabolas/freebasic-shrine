Tokamak Physics Engine, Copyright (C) 2002-2007 David Lam.

This is the distribution of the source code of Tokamak Physics Engine.
It contatins the source code to the core library. It does not contain 
the any samples. For sample codes, download the Tokamak Game Physics 
SDK Version 1 from www.tokamakphysics.com.

This library is distributed in the hope that it will be useful,       
but WITHOUT ANY WARRANTY; without even the implied warranty of        
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    
LICENSE.TXT for more details.                                         

For more information about Tokamak Physics Engine, visit 
www.tokamakphysics.com. or 
email me at david (at) tokamakphysics com 


History
=======
2007-07-05	1.0.2	release with source to adjacency.cpp
2007-07-20	1.0.3	linux friendly syntax changes, and Code::Blocks project file 
					courtesy of Cameron Villers.
2004-08-06	1.0.4	bug fixed: crash when constraint join two rigid bodies to one
					animated body.
2004-08-07	1.0.4a	bug fixed: crash when constraint join two rigid bodies to one
					animated body.
2004-04_10	1.0.5	added version number define TOKAMAK_VERSION
			added samples created with Direct 9.
			include tokamak-premake.zip courtesy of Adrian Boeing
			see http://sourceforge.net/forum/forum.php?thread_id=1879562&forum_id=696973
			added Zlib license to Tokamak Physics Engine.