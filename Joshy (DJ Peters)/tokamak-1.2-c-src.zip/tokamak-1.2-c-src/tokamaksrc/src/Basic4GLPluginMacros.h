/*
 * File:   Basic4GLPluginMacros.h
 * Author: Joshy (d.j.peters)
 *
 * Created on 14. November 2008, 03:52
 */

#ifndef _B4GLPLUGINMACROS_H
#define	_B4GLPLUGINMACROS_H

/* registry helper */

// register int,float,string constant by [n]ame and [v]alue
#define RIC(n,v) registry.RegisterIntConstant(#n,v)
#define RFC(n,v) registry.RegisterFloatConstant(#n,v)
#define RSC(n,v) registry.RegisterStringConstant(#n,v)

// register int,float,string constant by "[n]ame" and value from [n]ame
#define RIC2(n) registry.RegisterIntConstant(#n,n)

// hType = register type by name,major,minor
#define RT(n,ma,mi) registry.RegisterStructure(#n,ma,mi)

// register type padding field
#define RTPF(size) registry.AddStrucPadding(size) // size = nBytes

// register type byte,word,int,float,string field
#define RTBF(n) registry.AddStrucField(#n,DLL_BASIC4GL_EXT_BYTE)
#define RTWF(n) registry.AddStrucField(#n,DLL_BASIC4GL_EXT_WORD)
#define RTIF(n) registry.AddStrucField(#n,DLL_BASIC4GL_EXT_INT)
#define RTFF(n) registry.AddStrucField(#n,DLL_BASIC4GL_EXT_FLOAT)
#define RTSF(n,size) registry.AddStrucStringField(#n,size) // size included '0'

// register predefined type as type field
#define RTTF(n,v) registry.AddStrucField(#n,v)

// modify last type field as pointer or pointer on pointer
#define MTFLP() registry.ModStrucFieldPointer(1)   // level 1
#define MTFLPLP() registry.ModStrucFieldPointer(2) // level 2

// [r]egister [t]ype [b]yte,[w]ord,[i]nt,[f]loat,[s]tring [t]ype [P]ointer [F]ield
#define RTBPF(n) RTBF(n);MTFLP()
#define RTWPF(n) RTWF(n);MTFLP()
#define RTIPF(n) RTIF(n);MTFLP()
#define RTFPF(n) RTFF(n);MTFLP()
#define RTSPF(n,size) RTSF(n,size); MTFLP()
#define RTTPF(n,h) RTTF(n,h); MTFLP()

// register int,float,string pointer on pointer field
#define RTIPPF(n) RTIF(n); MTFLPLP()
#define RTFPPF(n) RTIF(n); MTFLPLP()
#define RTSPPF(n,size) RTSF(n,size); MTFLPLP()

// modify last type field as 1D,2D or 3D array
#define MTF1D(v1)       registry.ModStrucFieldArray(1,v1)
#define MTF2D(v1,v2)    registry.ModStrucFieldArray(2,v1,v2)
#define MTF3D(v1,v2,v3) registry.ModStrucFieldArray(3,v1,v2,v3)

// register type byte,word,int,float,string array field 1D
#define RTBA1DF(n,v) RTBF(n); MTF1D(v)
#define RTWA1DF(n,v) RTWF(n); MTF1D(v)
#define RTIA1DF(n,v) RTIF(n); MTF1D(v)
#define RTFA1DF(n,v) RTFF(n); MTF1D(v)
#define RTSA1DF(n,v0,v1) RTSF(n,v0);MTF1D(v1)

// register type byte,word,int,float,string array field 2D
#define RTBA2DF(n,v1,v2) RTBF(n);MTF2D(v1,v2)
#define RTWA2DF(n,v1,v2) RTWF(n);MTF2D(v1,v2)
#define RTIA2DF(n,v1,v2) RTIF(n);MTF2D(v1,v2)
#define RTFA2DF(n,v1,v2) RTFF(n);MTF2D(v1,v2)
#define RTSA2DF(n,v0,v1,v2) RTSF(n,v0);MTF2D(v1,v2)

// register type byte,word,int,float,string array field 3D
#define RTBA3DF(n,v1,v2,v3) RTBF(n);MTF3D(v1,v2,v3)
#define RTWA3DF(n,v1,v2,v3) RTWF(n);MTF3D(v1,v2,v3)
#define RTIA3DF(n,v1,v2,v3) RTIF(n);MTF3D(v1,v2,v3)
#define RTFA3DF(n,v1,v2,v3) RTFF(n);MTF3D(v1,v2,v3)
#define RTSA3DF(n,v0,v1,v2) RTSF(n,v0);MTF3D(v0,v1,v2,v3)

// register void,int,float,string,type function
#define RVF(name) registry.RegisterVoidFunction(#name,__##name)
#define RIF(name) registry.RegisterFunction(#name,__##name, DLL_BASIC4GL_INT)
#define RFF(name) registry.RegisterFunction(#name,__##name, DLL_BASIC4GL_FLOAT)
#define RSF(name) registry.RegisterFunction(#name,__##name, DLL_BASIC4GL_STRING)
#define RTF(name,h) registry.RegisterStructureFunction(#name,__##name,h)

// overload functions with other name
#define RVF2(name,name2) registry.RegisterVoidFunction(#name,__##name2)
#define RIF2(name,name2) registry.RegisterFunction(#name,__##name2, DLL_BASIC4GL_INT)
#define RFF2(name,name2) registry.RegisterFunction(#name,__##name2, DLL_BASIC4GL_FLOAT)
#define RSF2(name,name2) registry.RegisterFunction(#name,__##name2, DLL_BASIC4GL_STRING)
#define RTF2(name,h,name2) registry.RegisterStructureFunction(#name,__##name2, h)

#define RIAF2(name,d,name2) registry.RegisterArrayFunction(#name,__##name2,DLL_BASIC4GL_INT,d)
#define RFAF2(name,d,name2) registry.RegisterArrayFunction(#name,__##name2,DLL_BASIC4GL_FLOAT,d)


// register int,float,string array function by dimension
#define RIAF(name,d) registry.RegisterArrayFunction(#name,__##name,DLL_BASIC4GL_INT,d)
#define RFAF(name,d) registry.RegisterArrayFunction(#name,__##name,DLL_BASIC4GL_FLOAT,d)
#define RSAF(name,d) registry.RegisterArrayFunction(#name,__##name,DLL_BASIC4GL_STRING,d)

// add int float string param
#define AIP registry.AddParam(DLL_BASIC4GL_INT)
#define AFP registry.AddParam(DLL_BASIC4GL_FLOAT)
#define ASP registry.AddParam(DLL_BASIC4GL_STRING)

// add struct param by handle
#define ATP(h) registry.AddStrucParam(h)

// add int,float,string param as pointer
#define AIPP() registry.AddParam(DLL_BASIC4GL_INT);registry.ModParamPointer(1)
#define AFPP() registry.AddParam(DLL_BASIC4GL_FLOAT);registry.ModParamPointer(1)
#define ASPP() registry.AddParam(DLL_BASIC4GL_STRING);registry.ModParamPointer(1)
// add struct param as pointer h = handle
#define ATPP(h) registry.AddStrucParam(h);registry.ModParamPointer(1)

// add int,float,string,struct param as reference
#define AIPR registry.AddParam(DLL_BASIC4GL_INT);registry.ModParamReference()
#define AFPR registry.AddParam(DLL_BASIC4GL_FLOAT);registry.ModParamReference()
#define ASPR registry.AddParam(DLL_BASIC4GL_STRING);registry.ModParamReference()
#define ATPR(h) registry.AddStrucParam(h);registry.ModParamReference()

// add int,float,string array param by dimensions
#define AIAP(d) registry.AddArrayParam(DLL_BASIC4GL_INT   ,d)
#define AFAP(d) registry.AddArrayParam(DLL_BASIC4GL_FLOAT ,d)
#define ASAP(d) registry.AddArrayParam(DLL_BASIC4GL_STRING,d)

#define TIMESHARE registry.ModTimeshare()

/******************/
/* runtime helper */
/******************/
// declare plugin function
#define DPF(name) void DLLFUNC __##name(IDLL_Basic4GL_Runtime &basic4gl)

/* get params */

// get int float string param by index
#define GI(n) basic4gl.GetIntParam(n)
#define GF(n) basic4gl.GetFloatParam(n)
#define GS(n) basic4gl.GetStringParam(n)
// get struct param by registered handle,nIndex,pointer
#define GT(h,n,p) basic4gl.SetType(h);basic4gl.GetParam(n,p)
// get int float array param as 1D array()
#define GIA(n,pArray,n1) basic4gl.GetIntArrayParam(n,pArray,1,n1)
#define GFA(n,pArray,n1) basic4gl.GetFloatArrayParam(n,pArray,1,n1)
// get int float array param as 2D array()()
#define GIA2(n,pArray,n1,n2) basic4gl.GetIntArrayParam(n,pArray,2,n1,n2)
#define GFA2(n,pArray,n1,n2) basic4gl.GetFloatArrayParam(n,pArray,2,n1,n2)


/* set params */

// set byte,word,int,float,string param (byref)
#define SB(n,v) basic4gl.SetType(DLL_BASIC4GL_EXT_BYTE);basic4gl.ModTypeReference(); basic4gl.SetParam(n,v)
#define SW(n,v) basic4gl.SetType(DLL_BASIC4GL_EXT_WORD);basic4gl.ModTypeReference(); basic4gl.SetParam(n,v)
#define SI(n,v) basic4gl.SetType(DLL_BASIC4GL_EXT_INT);basic4gl.ModTypeReference(); basic4gl.SetParam(n,v)
#define SF(n,v) basic4gl.SetType(DLL_BASIC4GL_EXT_FLOAT);basic4gl.ModTypeReference(); basic4gl.SetParam(n,v)
#define SS(n,s,v) basic4gl.SetStringType(s);basic4gl.ModTypeReference();basic4gl.SetParam(n,v)
// set struct params by registered handle Index and pointer
#define ST(h,n,p) basic4gl.SetType(h);basic4gl.SetParam(n,p)

// set int,float 1D array() param byref
#define SIA(n,p,n1) basic4gl.SetType(DLL_BASIC4GL_EXT_INT);basic4gl.ModTypeArray(1,n1);basic4gl.SetParam(n,p)
#define SFA(n,p,n1) basic4gl.SetType(DLL_BASIC4GL_EXT_FLOAT);basic4gl.ModTypeArray(1,n1);basic4gl.SetParam(n,p)
// set int,float 2D array()() param byref
#define SIA2(n,p,n1,n2) basic4gl.SetType(DLL_BASIC4GL_EXT_INT);basic4gl.ModTypeArray(2,n1,n2);basic4gl.SetParam(n,p)
#define SFA2(n,p,n1,n2) basic4gl.SetType(DLL_BASIC4GL_EXT_FLOAT);basic4gl.ModTypeArray(2,n1,n2);basic4gl.SetParam(n,p)


/* set return values (result of functions) */

// set int float string result
#define SIR(r) basic4gl.SetIntResult((int) r)
#define SFR(r) basic4gl.SetFloatResult(r)
#define SSR(r) basic4gl.SetStringResult(r)
// set type result by handle and pointer
#define STR(h,p) basic4gl.SetType(h);basic4gl.SetReturnValue(p)

// set int float 1D array() result
#define SIAR(p,n1) basic4gl.SetFloatArrayResult(p,1,n1)
#define SFAR(p,n1) basic4gl.SetFloatArrayResult(p,1,n1)
// set int float 2D array()() result
#define SIAR2(p,n1,n2) basic4gl.SetFloatArrayResult(p,2,n1,n2)
#define SFAR2(p,n1,n2) basic4gl.SetFloatArrayResult(p,2,n1,n2)

// direct set int float string
#define DSI(p,v) basic4gl.DirectSetInt(p,(int) v)
#define DSF(p,v) basic4gl.DirectSetFloat(p,v)

#endif	/* _B4GLPLUGINMACROS_H */

