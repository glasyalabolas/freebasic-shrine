#ifndef __M3D__
#define __M3D__

#include "math.h"


#define _11 sclr.s11
#define _12 sclr.s12
#define _13 sclr.s13
#define _14 sclr.s14
#define _21 sclr.s21
#define _22 sclr.s22
#define _23 sclr.s23
#define _24 sclr.s24
#define _31 sclr.s31
#define _32 sclr.s32
#define _33 sclr.s33
#define _34 sclr.s34
#define _41 sclr.s41
#define _42 sclr.s42
#define _43 sclr.s43
#define _44 sclr.s44

struct Matrix3D
{
  union {
    struct { float s11,s12,s13,s14,
                   s21,s22,s23,s24,
                   s31,s32,s33,s34,
                   s41,s42,s43,s44; } sclr;
    float m[4][4];
  };
  static const Matrix3D Identity;

  Matrix3D() {}


  Matrix3D(const float *t)
  {
    _11=t[ 0]; _12=t[ 1]; _13=t[ 2]; _14=t[ 3];
    _21=t[ 4]; _22=t[ 5]; _23=t[ 6]; _24=t[ 7];
    _31=t[ 8]; _32=t[ 9]; _33=t[10]; _34=t[11];
    _41=t[12]; _42=t[13]; _43=t[14]; _44=t[15];
  }

  Matrix3D(float f11, float f12, float f13, float f14,
           float f21, float f22, float f23, float f24,
           float f31, float f32, float f33, float f34,
           float f41, float f42, float f43, float f44)
  {
    _11=f11; _12=f12; _13=f13; _14=f14;
    _21=f21; _22=f22; _23=f23; _24=f24;
    _31=f31; _32=f32; _33=f33; _34=f34;
    _41=f41; _42=f42; _43=f43; _44=f44;
  }



  friend Matrix3D PitchMatrix3D(const float theta);
  friend Matrix3D YawMatrix3D  (const float theta);
  friend Matrix3D RollMatrix3D (const float theta);
  void rotate(const float x, const float y, const float z);

  Matrix3D Inverse() const;
  Matrix3D Adjoint() const;
  float Determinant() const;

  float  operator() (int i, int j) const { return m[i][j]; }
  float& operator() (int i, int j)       { return m[i][j]; }

  //Matrix3D& operator*= (const Matrix3D& m);

};


inline Matrix3D operator*(float scalar, const Matrix3D& m)
{
  return Matrix3D(scalar*m(0,0),scalar*m(0,1),scalar*m(0,2),scalar*m(0,3),
                  scalar*m(1,0),scalar*m(1,1),scalar*m(1,2),scalar*m(1,3),
                  scalar*m(2,0),scalar*m(2,1),scalar*m(2,2),scalar*m(2,3),
                  scalar*m(3,0),scalar*m(3,1),scalar*m(3,2),scalar*m(3,3));
}

inline Matrix3D operator*(const Matrix3D& m1, const Matrix3D& m2)
{
  return Matrix3D(
    m1._11*m2._11 + m1._12*m2._21 + m1._13*m2._31 + m1._14*m2._41,
    m1._11*m2._12 + m1._12*m2._22 + m1._13*m2._32 + m1._14*m2._42,
    m1._11*m2._13 + m1._12*m2._23 + m1._13*m2._33 + m1._14*m2._43,
    m1._11*m2._14 + m1._12*m2._24 + m1._13*m2._34 + m1._14*m2._44,
    m1._21*m2._11 + m1._22*m2._21 + m1._23*m2._31 + m1._24*m2._41,
    m1._21*m2._12 + m1._22*m2._22 + m1._23*m2._32 + m1._24*m2._42,
    m1._21*m2._13 + m1._22*m2._23 + m1._23*m2._33 + m1._24*m2._43,
    m1._21*m2._14 + m1._22*m2._24 + m1._23*m2._34 + m1._24*m2._44,
    m1._31*m2._11 + m1._32*m2._21 + m1._33*m2._31 + m1._34*m2._41,
    m1._31*m2._12 + m1._32*m2._22 + m1._33*m2._32 + m1._34*m2._42,
    m1._31*m2._13 + m1._32*m2._23 + m1._33*m2._33 + m1._34*m2._43,
    m1._31*m2._14 + m1._32*m2._24 + m1._33*m2._34 + m1._34*m2._44,
    m1._41*m2._11 + m1._42*m2._21 + m1._43*m2._31 + m1._44*m2._41,
    m1._41*m2._12 + m1._42*m2._22 + m1._43*m2._32 + m1._44*m2._42,
    m1._41*m2._13 + m1._42*m2._23 + m1._43*m2._33 + m1._44*m2._43,
    m1._41*m2._14 + m1._42*m2._24 + m1._43*m2._34 + m1._44*m2._44);
}

/*
inline Matrix3D& operator *= (const Matrix3D& m)
  {
    return *this = *this * m;
  }
*/

inline Matrix3D TranslateMatrix3D(const float tx, const float ty, const float tz) {
  return Matrix3D(1.0f,0.0f,0.0f,0.0f,
                  0.0f,1.0f,0.0f,0.0f,
                  0.0f,0.0f,1.0f,0.0f,
                    tx,  ty,  tz,1.0f);
}

inline Matrix3D ScaleMatrix3D(const float sx, const float sy, const float sz) {
   return Matrix3D(  sx,0.0f,0.0f,0.0f,
                   0.0f,  sy,0.0f,0.0f,
                   0.0f,0.0f,  sz,0.0f,
                   0.0f,0.0f,0.0f,1.0f);
}

inline Matrix3D ScaleMatrix3D(const float s) {
   return ScaleMatrix3D(s,s,s);
}

inline Matrix3D PitchMatrix3D(const float c, const float s) {
   return Matrix3D(1.0f, 0.0f, 0.0f, 0.0f,
                   0.0f,    c,   -s, 0.0f,
                   0.0f,    s,    c, 0.0f,
                   0.0f, 0.0f, 0.0f, 1.0f);
}

inline Matrix3D PitchMatrix3D(const float theta) {
   return PitchMatrix3D((float) cos(theta), (float) sin(theta));
}

inline Matrix3D YawMatrix3D(const float c, const float s) {
   return Matrix3D(   c, 0.0f,    s, 0.0f,
                   0.0f, 1.0f, 0.0f, 0.0f,
                     -s, 0.0f,    c, 0.0f,
                   0.0f, 0.0f, 0.0f, 1.0f);
}

inline Matrix3D YawMatrix3D(const float theta) {
   return YawMatrix3D((float) cos(theta), (float) sin(theta));
}

inline Matrix3D RollMatrix3D(const float c, const float s) {
   return Matrix3D(c,   -s,    0.0f, 0.0f,
                   s,    c,    0.0f, 0.0f,
                   0.0f, 0.0f, 1.0f, 0.0f,
                   0.0f, 0.0f, 0.0f, 1.0f);
}

inline Matrix3D RollMatrix3D(const float theta) {
   return RollMatrix3D((float) cos(theta), (float) sin(theta));
}

inline void Matrix3D::rotate(const float rx, const float ry, const float rz) {
   if (rx!=0.0f) *this = PitchMatrix3D(rx) * (*this);
   if (ry!=0.0f) *this = YawMatrix3D  (ry) * (*this);
   if (rz!=0.0f) *this = RollMatrix3D (rz) * (*this);
}


#undef _11
#undef _12
#undef _13
#undef _14
#undef _21
#undef _22
#undef _23
#undef _24
#undef _31
#undef _32
#undef _33
#undef _34
#undef _41
#undef _42
#undef _43
#undef _44

#endif // __M3D__
