// TokamakPlugin.cpp by d.j.peters (Joshy)
/*
#ifdef  _MSC_VER
  extern "C" long _ftol( double ); //defined by VC6 C libs
  extern "C" long _ftol2( double dblSource ) { return _ftol( dblSource ); }
#endif
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/GL.h>
#include <GL/GLU.h>

#include <Basic4GLDLLInterface.h>
#include <Basic4GLStandardObjects.h>
#include "Basic4GLPluginMacros.h"


// #define TOKAMAK_USE_DLL
#include <tokamak.h>
#include "Matrix3D.h"

/*
 !!! added
// ne_interface.cpp
void neJoint::SetUserData(u32 userData){
	CAST_THIS(_neConstraint, c);
	c.userData = userData;
}
u32 neJoint::GetUserData(){
	CAST_THIS(_neConstraint, c);
	return c.userData;
}

*/

///////////////////////////////////////////////////////////////////////////////
// TokamakPlugin
//

#define SENSOR_ZERO 0.0000001f

struct CollisionInfo{
  neBodyType       TypeA;
  neBodyType       TypeB;
  neRigidBody    * RigidBodyA;
  neRigidBody    * RigidBodyB;
  neAnimatedBody * AnimatedBodyA;
  neAnimatedBody * AnimatedBodyB;
  neGeometry     * GeometryA;
  neGeometry     * GeometryB;
  s32              MaterialIdA;
  s32              MaterialIdB;
  f32              BodyContactPointA[3];
  f32              BodyContactPointB[3];
  f32              WorldContactPointA[3];
  f32              WorldContactPointB[3];
  f32              RelativeVelocity[3];
  f32              CollisionNormal[3];
};

struct ConvexData{
  unsigned char * pConvex;
  s32             nBytes;
  s32             UserData;
  f32             ScaleX;
  f32             ScaleY;
  f32             ScaleZ;

};

#ifndef NO_BREAKAGE
struct BreakageInfo{
  neBodyType       BodyType;
  neRigidBody    * OriginalRigidBody;
  neAnimatedBody * OriginalAnimatedBody;
  neGeometry     * BrokenGeometry;
  neRigidBody    * NewRigidBody;
};
#endif

enum DATA_OWNER {
  FREE,
  RIGIDBODY,
  ANIMATEDBODY,
  GEOMETRY,
  JOINT,
  SENSOR
};

struct UserData {
  int inUse;
  int userData;
  int controllerCode;
  // ConvexData
  ConvexData convexData;
};

struct DCDPoint
{
	f32 x,y,z,w;
};

struct DCDFace
{
	neByte *neighbourFaces;
	neByte *neighbourVerts;
	neByte *neighbourEdges;
};

struct DCDVert
{
	neByte * neighbourEdges;
};

struct DCDEdge
{
	neByte f1;
	neByte f2;
	neByte v1;
	neByte v2;
};

void BuildConvexData(neByte *pBytes,float sx,float sy,float sz) {
  sx=neAbs(sx);if (sx<0.0001f) sx=0.0001f;
  sy=neAbs(sy);if (sy<0.0001f) sy=0.0001f;
  sz=neAbs(sz);if (sz<0.0001f) sz=0.0001f;

	neByte * d = pBytes;

	s32 numFaces = *(int*)d;
	s32 numVerts = *((int*)d + 1);
	//s32 numEdges = *((int*)d + 2);

  s32 i=0;
  //                        |    header=16       |      normals * 16
  DCDPoint * p = (DCDPoint *)(d + sizeof(int) * 4 + numFaces * sizeof(f32) * 4);
  for (i = 0; i < numVerts; i++)
	{
		p[i].x *= sx;
    p[i].y *= sy;
    p[i].z *= sz;
	}
	//                       |    header=16       |      normals  * 16         |       vertices * 16
  DCDFace * f = (DCDFace *)(d + sizeof(int) * 4 + numFaces * sizeof(f32) * 4 + numVerts * sizeof(f32) * 4);
	DCDVert * v = (DCDVert *)(f + numFaces);
	for (i = 0; i < numFaces; i++)
	{
		f[i].neighbourEdges += (int)d;
		f[i].neighbourVerts += (int)d;
		f[i].neighbourFaces += (int)d;
	}
	for (i = 0; i < numVerts; i++)
	{
		v[i].neighbourEdges += (int)d;
	}
}


// Global variables.
char                  * pluginError     = NULL;
IB4GLCompiler         * gpCompiler      = NULL;

UserData              * gpUserDataPool  = NULL;
UserData              * gpUserData      = NULL;
UserData              * gpUD            = NULL;
int nUDAll=0;

float           gA[16];
neT3            gT3;
neV3            gV3;
neQ             gQ;

neTriangleMesh  tMesh;
CollisionInfo   cInfo;
ConvexData      cData;

#ifndef NO_BREAKAGE
BreakageInfo    bInfo;
#endif

// registered classes
neSimulatorSizeInfo   * pSimulatorSizeInfo   = NULL;
neSimulator           * pSimulator           = NULL;
neRigidBody           * pRigidBody           = NULL;
neAnimatedBody        * pAnimatedBody        = NULL;
neGeometry            * pGeometry            = NULL;
neSensor              * pSensor              = NULL;
neRigidBodyController * pRigidBodyController = NULL;
neJoint               * pJoint               = NULL;
neJointController     * pJointController     = NULL;
neCollisionTable      * pCollisionTable      = NULL;
// registered BASIC4GL structs
int hSimulatorSizeInfo   = 0;
int hSimulator           = 0;
int hRigidBody           = 0;
int hRigidBodyController = 0;
int hAnimatedBody        = 0;
int hGeometry            = 0;
int hSensor              = 0;
int hJoint               = 0;
int hJointController     = 0;
int hCollisionTable      = 0;
int hCollisionInfo       = 0;
int hConvexData          = 0;
#ifndef NO_BREAKAGE
int hBreakageInfo        = 0;
int hBreakageCallback    = 0;
#endif

//int gRBCC =0;   // RigidBodyControllerCallback
//int gJOCC =0;   // JointControllerCallback

int gCIC  =0;   // CollisionInfoCallback


// get/set/return classes

// neSimulatorgSizeInfo
#define GSIMULATORLATORSIZEINFO(n)  GT(hSimulatorSizeInfo,n,&pSimulatorSizeInfo)
#define SSIMULATORLATORSIZEINFO(n)  ST(hSimulatorSizeInfo,n,&pSimulatorSizeInfo)
#define RSIMULATORLATORSIZEINFO()   STR(hSimulatorSizeInfo,&pSimulatorSizeInfo)
#define RPSSI(p) STR(hSimulatorSizeInfo,&p)

// neSimulator
#define GSIMULATOR(n)  GT(hSimulator,n,&pSimulator)
#define SSIMULATOR(n)  ST(hSimulator,n,&pSimulator)
#define RSIMULATOR()   STR(hSimulator,&pSimulator)
#define RPSIMU(p) STR(hSimulator,(&p))

// neRigidBody
#define GRIGIDBODY(n)  GT(hRigidBody,n,&pRigidBody)
#define SRIGIDBODY(n)  ST(hRigidBody,n,&pRigidBody)
#define RRIGIDBODY()   STR(hRigidBody,&pRigidBody)
#define RPRB(p) STR(hRigidBody,&p)

// neAnimated
#define GANIMATEDBODY(n)  GT(hAnimatedBody,n,&pAnimatedBody)
#define SANIMATEDBODY(n)  ST(hAnimatedBody,n,&pAnimatedBody)
#define RANIMATEDBODY()   STR(hAnimatedBody,&pAnimatedBody)
#define RPAB(p) STR(hAnimatedBody,&p)

// neGemotry
#define GGEOMETRY(n)  GT(hGeometry,n,&pGeometry)
#define SGEOMETRY(n)  ST(hGeometry,n,&pGeometry)
#define RGEOMETRY()   STR(hGeometry,&pGeometry)
#define RPGEOM(p) STR(hGeometry,&p)

// neSensor
#define GSENSOR(n)  GT(hSensor,n,&pSensor)
#define SSENSOR(n)  ST(hSensor,n,&pSensor)
#define RSENSOR()   STR(hSensor,&pSensor)
#define RPSENS(p) STR(hSensor,&p)

// neRigidBodyController
#define GRIGIDBODYCONTROLLER(n)  GT(hRigidBodyController,n,&pRigidBodyController)
#define SRIGIDBODYCONTROLLER(n)  ST(hRigidBodyController,n,&pRigidBodyController)
#define RRIGIDBODYCONTROLLER()   STR(hRigidBodyController,&pRigidBodyController)
#define RPRBC(p) STR(hRigidBodyController,&p)

// neJoint
#define GJOINT(n)  GT(hJoint,n,&pJoint)
#define SJOINT(n)  ST(hJoint,n,&pJoint)
#define RJOINT()   STR(hJoint,&pJoint)
#define RPJO(p) STR(hJoint,&p)

// neJointController
#define GJOINTCONTROLLER(n)  GT(hJointController,n,&pJointController)
#define SJOINTCONTROLLER(n)  ST(hJointController,n,&pJointController)
#define RJOINTCONTROLLER()   STR(hJointController,&pJointController)
#define RPJOC(p) STR(hJointController,&p)

// neCollisionTable
#define GCOLLISIONTABLE(n)  GT(hCollisionTable,n,&pCollisionTable)
#define SCOLLISIONTABLE(n)  ST(hCollisionTable,n,&pCollisionTable)
#define RCOLLISIONTABLE()   STR(hCollisionTable,&pCollisionTable)
#define RPCOLT(p) STR(hCollisionTable,&p)

// neCollisionInfo
#define GCOLLISIONINFO(n)  GT(hCollisionInfo,n,&cInfo)
#define SCOLLISIONINFO(n)  ST(hCollisionInfo,n,&cInfo)
#define RCOLLISIONINFO()   STR(hCollisionInfo,&cInfo)
#define RPCOLI(p) STR(hCollisionInfo,&p)
// ConvexData
#define GCONVEXDATA(n)  GT(hConvexData,n,&cData)
#define SCONVEXDATA(n)  ST(hConvexData,n,&cData)
#define RCONV()   STR(hConvexData,&cData)
#define RPCONV(p) STR(hConvexData,&p)

#ifndef NO_BREAKAGE
 // neBreakageInfo
 #define GBREAKAGEINFO(n)  GT(hBreakageInfo,n,&bInfo)
 #define SBREAKAGEINFO(n)  ST(hBreakageInfo,n,&bInfo)
 #define RBREAKAGEINFO()   STR(hBreakageInfo,&bInfo)
 #define RPBI(p) STR(hBreakageInfo,&p)
#endif


class TokamakPlugin : public IDLL_Basic4GL_Plugin {
    public:
    TokamakPlugin() { ; }
    virtual bool DLLFUNC Load(IDLL_Basic4GL_FunctionRegistry &registry, bool isStandaloneExe);
    virtual bool DLLFUNC Start();
    virtual void DLLFUNC End();
    virtual void DLLFUNC Unload();
    virtual void DLLFUNC GetError(char *error);
    virtual void DLLFUNC Pause();
    virtual void DLLFUNC Resume();
    virtual void DLLFUNC DelayedResume();
    virtual void DLLFUNC ProcessMessages();
};
///////////////////////////////////////////////////////////////////////////////
// DLL exported functions
extern "C" {
  /// Query function
  DLLExport int DLLFUNC Basic4GL_Query(char *details, int *major, int *minor) {
    char detailSrc[] = "for Basic4GL";
    for (int i = 0; detailSrc[i] != 0; i++){
      details[i] = detailSrc[i];
    }
    *major = 1; *minor = 25;
    return BASIC4GL_DLL_VERSION;
  }

  DLLExport IDLL_Basic4GL_Plugin *DLLFUNC Basic4GL_Init() {
    return new TokamakPlugin();
  }
}

class RigidBodyCallback : public neRigidBodyControllerCallback {
  public:
  virtual void RigidBodyControllerCallback(neRigidBodyController * controller,float timestep) {
    timestep=timestep;
    neRigidBody * rb = controller->GetRigidBody();
    gpUD = (UserData *) rb->GetUserData();
    if (gpUD!=NULL) {
      if (gpUD->inUse==RIGIDBODY) {
        if (gpUD->controllerCode!=0) {
          pRigidBodyController=controller;
          gpCompiler->Execute(gpUD->controllerCode);
        }
      }
    }
  };
};

class JointCallback : public neJointControllerCallback {
  public:
  virtual void ConstraintControllerCallback(neJointController * controller,float timestep) {
    timestep=timestep;
    neJoint * jo = controller->GetJoint();
    gpUD = (UserData *) jo->GetUserData();
    if (gpUD!=NULL) {
      if (gpUD->inUse==JOINT) {
        if (gpUD->controllerCode!=0) {
          pJointController=controller;
          gpCompiler->Execute(gpUD->controllerCode);
        }
      }
    }
  };
};


u32 AllocUserData(int owner) {
  gpUserData = gpUserDataPool;
  for (int i=0;i<nUDAll;i++) {
    if (gpUserData->inUse==FREE) {
      break;
    }
    gpUserData++;
  }
  gpUserData->inUse=owner;
  return (u32) gpUserData;
}

void FreeUserDataPool(void) {
  // pool in use ?
  if (gpUserDataPool!=NULL) {
    if (nUDAll>0) {
      gpUserData=gpUserDataPool;
      for (int i=0;i<nUDAll;i++) {
        // any old Convex ?
        if (gpUserData->convexData.pConvex!=NULL) {
          delete[] gpUserData->convexData.pConvex;
          gpUserData->convexData.pConvex=NULL;
        }
        gpUserData++;
      }
      free(gpUserDataPool);
      gpUserDataPool=NULL;
      nUDAll=0;
    }
  }
  gpUserData=NULL;

}

void AllocUserDataPool(void) {
  if (gpUserDataPool!=NULL){
    FreeUserDataPool();
  }
  int nRB = pSimulatorSizeInfo->rigidBodiesCount;
  int nAB = pSimulatorSizeInfo->animatedBodiesCount;
  int nGE = pSimulatorSizeInfo->geometriesCount;
  int nJO = pSimulatorSizeInfo->constraintsCount;
  int nSE = pSimulatorSizeInfo->sensorsCount;
  nUDAll = nRB + nAB + nGE + nJO + nSE + 1;
  gpUserDataPool = (UserData *) malloc(sizeof(UserData)*nUDAll);
  memset(gpUserDataPool,0,sizeof(UserData)*nUDAll);
  gpUserData = gpUserDataPool;
}


RigidBodyCallback RBInstance;
JointCallback     JOInstance;

void CollisionInfoCallback(neCollisionInfo & collinfo) {
  if (gCIC!=0) {
    cInfo.TypeA=collinfo.typeA;
    cInfo.TypeB=collinfo.typeB;
    if (cInfo.TypeA==NE_RIGID_BODY){
      cInfo.RigidBodyA    = (neRigidBody *) collinfo.bodyA;
      cInfo.AnimatedBodyA = NULL;
    } else if (cInfo.TypeA==NE_ANIMATED_BODY) {
      cInfo.RigidBodyA    = NULL;
      cInfo.AnimatedBodyA = (neAnimatedBody *) collinfo.bodyA;
    }
    if (cInfo.TypeB==NE_RIGID_BODY){
      cInfo.RigidBodyB    = (neRigidBody *) collinfo.bodyB;
      cInfo.AnimatedBodyB = NULL;
    } else if (cInfo.TypeB==NE_ANIMATED_BODY) {
      cInfo.RigidBodyB    = NULL;
      cInfo.AnimatedBodyB = (neAnimatedBody *) collinfo.bodyB;
    }
    cInfo.MaterialIdA = collinfo.materialIdA;
    cInfo.MaterialIdB = collinfo.materialIdB;

    cInfo.GeometryA = collinfo.geometryA;
    cInfo.GeometryB = collinfo.geometryB;

    for (int i=0;i<3;i++){
      cInfo.BodyContactPointA[i] =collinfo.bodyContactPointA[i];
      cInfo.BodyContactPointB[i] =collinfo.bodyContactPointB[i];
      cInfo.WorldContactPointA[i]=collinfo.worldContactPointA[i];
      cInfo.WorldContactPointB[i]=collinfo.worldContactPointB[i];
      cInfo.RelativeVelocity[i]  =collinfo.relativeVelocity[i];
      cInfo.CollisionNormal[i]   =collinfo.collisionNormal[i];
    }
    gpCompiler->Execute(gCIC);
  }
}

#ifndef NO_BREAKAGE
void BreakageCallback(neByte * originalBody,
                      neBodyType bodyType,
                      neGeometry * brokenGeometry,
                      neRigidBody * newBody) {
  if (hBreakageCallback!=0) {
    bInfo.BodyType=bodyType;

    if (bInfo.BodyType==NE_RIGID_BODY){
      bInfo.OriginalRigidBody    = (neRigidBody *) originalBody;
      bInfo.OriginalAnimatedBody = NULL;
    } else if (bInfo.BodyType==NE_ANIMATED_BODY) {
      bInfo.OriginalRigidBody    = NULL;
      bInfo.OriginalAnimatedBody = (neAnimatedBody *) originalBody;
    }

    bInfo.BrokenGeometry = brokenGeometry;
    bInfo.NewRigidBody   = newBody;
    gpCompiler->Execute(hBreakageCallback);
  }

}
#endif // NO_BREAKAGE

neV3 RotAngle(neM3 m3) {
  float gA[9];
  gA[0] = m3.M[0].v[0];
  gA[1] = m3.M[0].v[1];
  gA[2] = m3.M[0].v[2];
  //gA[3] = m3.M[1].v[0];
  gA[4] = m3.M[1].v[1];
  //gA[5] = m3.gA[1].v[2];
  gA[6] = m3.M[2].v[0];
  gA[7] = m3.M[2].v[1];
  gA[8] = m3.M[2].v[2];

  neV3 r;
  if (gA[7]<1.0f) {
    if (gA[7]>-1.0f) {
      r.v[0] = (float)asin((double)gA[7]);
      r.v[1] = (float)atan2(-gA[6],gA[8]);
      r.v[2] = (float)atan2(-gA[1],gA[4]);
      return r;
    } else {
      r.v[0] = -1.570796f;
      r.v[1] = 0.0f;
      r.v[2] = (float)-atan2(gA[2],gA[0]);
      return r;
    }
  } else {
    r.v[0] = 1.570796f;
    r.v[1] = 0.0f;
    r.v[2] = (float)atan2(gA[2],gA[0]);
    return r;
  }
}

neM3 RotMatrixArray(float gA[3]){
  neQ   q;
  float p =gA[0]*0.5f;
  float y =gA[1]*0.5f;
  float r =gA[2]*0.5f;
  float cr = (float)cos( r);
  float cp = (float)cos( p);
  float cy = (float)cos(-y);
  float sr = (float)sin( r);
  float sp = (float)sin( p);
  float sy = (float)sin(-y);
  float cpcy = cp*cy;
  float spsy = sp*sy;
  float spcy = sp*cy;
  float cpsy = cp*sy;
  q.X = (cr*spcy)+(sr*cpsy);
  q.Y = (cr*cpsy)-(sr*spcy);
  q.Z = (sr*cpcy)-(cr*spsy);
  q.W = (cr*cpcy)+(sr*spsy);
  return q.BuildMatrix3();
}

neM3 RotMatrix(float p,float y,float r){
  neQ Rot;
  float	cr = (float)cos( r*0.5f);
  float	cp = (float)cos( p*0.5f);
  float cy = (float)cos(-y*0.5f);
  float sr = (float)sin( r*0.5f);
  float sp = (float)sin( p*0.5f);
  float	sy = (float)sin(-y*0.5f);
  float cpcy = cp*cy;
  float spsy = sp*sy;
  float spcy = sp*cy;
  float cpsy = cp*sy;
  Rot.W = (cr*cpcy)+(sr*spsy);
  Rot.X = (cr*spcy)+(sr*cpsy);
  Rot.Y = (cr*cpsy)-(sr*spcy);
  Rot.Z = (sr*cpcy)-(cr*spsy);
  return Rot.BuildMatrix3();
}

///////////////////////////////////////////////////////////////////////////////
// Runtime functions
// These are the functions that Basic4GL calls

//##########
//# neMath #
//##########
DPF(neSeed) { // (seed%)
  neSeed(GI(1));
}
DPF(neRnd) { // rnd#=()
  SFR( neFRand(0.0f,1.0f) );
}
DPF(neRnd1) { // rnd#=(max#)
  SFR( neFRand(0.0f,GF(1)) );
}
DPF(neRnd2) { // rnd#=(min#,max#)
  SFR( neFRand(GF(2),GF(1)) );
}
DPF(neAbs) { // r#=(x#)
  SFR( neAbs(GF(1)) );
}
DPF(neSin){ // r#=(x#)
  SFR( neSin(GF(1)) );
}
DPF(neCos){ // r#=(x#)
  SFR( neCos(GF(1)) );
}
DPF(neASin){ // r#=(x#)
  SFR( neASin(GF(1)) );
}
DPF(neACos){ // r#=(x#)
  SFR( neACos(GF(1)) );
}
DPF(neTan){ // r#=(x#)
  SFR( neTan(GF(1)) );
}
DPF(neATan){ // r#=(x#)
  SFR( neATan(GF(1)) );
}
DPF(neATan2) { //r#=(x#,y#)
  SFR( neATan2(GF(2),GF(1)) );
}
DPF(neIsEqual) { //r%=(a#,b#)
  SIR( neRealsEqual(GF(2),GF(1)) );
}

DPF(neRad){ // rad#=(deg#)
  SFR(NE_DEG_TO_RAD(GF(1)));
}
DPF(neDeg){ // deg#=(rad#)
  SFR(NE_RAD_TO_DEG(GF(1)));
}

DPF(nePI){ // deg#=PI
  SFR(NE_PI);
}

// ################
// # neQuaternion #
// ################
DPF(QuatIdentity){ // q=()
  gA[0]=0;gA[1]=0;gA[2]=0;gA[3]=1;
  SFAR(&gA[0],4);
}
DPF(Quat){ // q=(x#,y#.z#.w#)
  gA[0]=GF(4);gA[1]=GF(3);gA[2]=GF(2);gA[3]=GF(1);
  SFAR(&gA[0],4);
}
DPF(QuatEulerA){ // q = (deg_pyr()#)
  GFA(1,gA,3);
	float x  = NE_DEG_TO_RAD(gA[0]);
  float y  = NE_DEG_TO_RAD(gA[1]);
  float z  = NE_DEG_TO_RAD(gA[2]);
  float cx = neCos(0.5f*x);
  float cy = neCos(0.5f*y);
  float cz = neCos(0.5f*z);
	float sx = neSin(0.5f*x);
  float sy = neSin(0.5f*y);
  float sz = neSin(0.5f*z);
	gA[0] = cz*cy*sx - sz*sy*cx;
	gA[1] = cz*sy*cx + sz*cy*sx;
	gA[2] = sz*cy*cx - cz*sy*sx;
  gA[3] = cz*cy*cx + sz*sy*sx;
  SFAR(&gA[0],4);
}
DPF(QuatEuler){ // q = (deg_p#,deg_y#,deg_r#)
	float x  = NE_DEG_TO_RAD(GF(3));
  float y  = NE_DEG_TO_RAD(GF(2));
  float z  = NE_DEG_TO_RAD(GF(1));
  float cx = neCos(0.5f*x);
  float cy = neCos(0.5f*y);
  float cz = neCos(0.5f*z);
	float sx = neSin(0.5f*x);
  float sy = neSin(0.5f*y);
  float sz = neSin(0.5f*z);
	gA[0] = cz*cy*sx - sz*sy*cx;
	gA[1] = cz*sy*cx + sz*cy*sx;
	gA[2] = sz*cy*cx - cz*sy*sx;
  gA[3] = cz*cy*cx + sz*sy*sx;
  SFAR(&gA[0],4);
}
DPF(QuatRadA){ // q = (rad_pyr()#)
  GFA(1,gA,3);
	float x  = gA[0];
  float y  = gA[1];
  float z  = gA[2];
  float cx = neCos(0.5f*x);
  float cy = neCos(0.5f*y);
  float cz = neCos(0.5f*z);
	float sx = neSin(0.5f*x);
  float sy = neSin(0.5f*y);
  float sz = neSin(0.5f*z);
	gA[0] = cz*cy*sx - sz*sy*cx;
	gA[1] = cz*sy*cx + sz*cy*sx;
	gA[2] = sz*cy*cx - cz*sy*sx;
  gA[3] = cz*cy*cx + sz*sy*sx;
  SFAR(&gA[0],4);
}
DPF(QuatRad){ // q = (rad_p#,rad_y#,rad_r#)
	float x  = GF(3);
  float y  = GF(2);
  float z  = GF(1);
  float cx = neCos(0.5f*x);
  float cy = neCos(0.5f*y);
  float cz = neCos(0.5f*z);
	float sx = neSin(0.5f*x);
  float sy = neSin(0.5f*y);
  float sz = neSin(0.5f*z);
	gA[0] = cz*cy*sx - sz*sy*cx;
	gA[1] = cz*sy*cx + sz*cy*sx;
	gA[2] = sz*cy*cx - cz*sy*sx;
  gA[3] = cz*cy*cx + sz*sy*sx;
  SFAR(&gA[0],4);
}



DPF(QuatX){ // x#=(q)
  GFA(1,gA,4);SFR(gA[0]);
}
DPF(QuatY){ // y#=(q)
  GFA(1,gA,4);SFR(gA[1]);
}
DPF(QuatZ){ // z#=(q)
  GFA(1,gA,4);SFR(gA[2]);
}
DPF(QuatW){ // w#=(q)
  GFA(1,gA,4);SFR(gA[3]);
}

DPF(QuatNormalize){ // qn=(q)
  GFA(1,gA,4);
  float l=gA[0]*gA[0] + gA[1]*gA[1] +gA[2]*gA[2] +gA[3]*gA[3];
  if (l!=0.0f) {
    l=1.0f/(float)sqrt(l);
    gA[0]*=l;
    gA[1]*=l;
    gA[2]*=l;
    gA[3]*=l;
  }
  SFAR(&gA[0],4);
}

DPF(QuatAngleAxis){ // q = (angle#,axis#())
  neV3 axis; GFA(1,gA,3); axis.Set(gA[0],gA[1],gA[2]);
  float angle = GF(2);
  neQ q;
  q.Set(angle,axis);
  gA[0]=q.X; gA[1]=q.Y; gA[2]=q.Z; gA[3]=q.W;
  SFAR(&gA[0],4);
}
DPF(QuatGetAngleAxis){ // (q,&angle#,&axis#())
  neQ q; GFA(3,gA,4); q.Set(gA[0],gA[1],gA[2],gA[3]);
  neV3 axis; float angle;
  q.GetAxisAngle(axis,angle);
  SFA(1,&axis.v[0],3);
  SF (2,&angle);
}


DPF(QuatConjugate){ //q=(q)
  GFA(1,gA,4);
  gA[0]=-gA[0];
  gA[1]=-gA[1];;
  gA[2]=-gA[2];
  SFAR(&gA[0],4);
}

DPF(QuatInvert){ //qi=(q)
  GFA(1,gA,4);
  gA[0]=-gA[0];
  gA[1]=-gA[1];
  gA[2]=-gA[2];
  float l=gA[0]*gA[0] + gA[1]*gA[1] +gA[2]*gA[2] +gA[3]*gA[3];
  if (l!=0.0f) {
    l=1.0f/(float)sqrt(l);
    gA[0]*=l;
    gA[1]*=l;
    gA[2]*=l;
    gA[3]*=l;
  }
  SFAR(&gA[0],4);
}
DPF(QuatInverse){ // invq = (q)
  GFA(1,gA,4);
  float l=gA[0]*gA[0] + gA[1]*gA[1] +gA[2]*gA[2] +gA[3]*gA[3];
  if (l!=0.0f) l=1.0f/l;

  gA[0]*=-l;
  gA[1]*=-l;
  gA[2]*=-l;
  gA[3]*= l;

  SFAR(&gA[0],4);
}

DPF(QuatLength2){ //l2#=(q)
  GFA(1,gA,4); SFR(gA[0]*gA[0] + gA[1]*gA[1] +gA[2]*gA[2] +gA[3]*gA[3]);
}

DPF(QuatLength){ //l#=(q)
  GFA(1,gA,4); float l=gA[0]*gA[0] + gA[1]*gA[1] +gA[2]*gA[2] +gA[3]*gA[3];
  if (l!=0.0f) l=(float)sqrt(l);
  SFR(l);
}

DPF(QuatQuat){ // qc = (qa*qb)
  neQ qc,qa,qb;
  GFA(2,gA,4);qa.X=gA[0];qa.Y=gA[1];qa.Z=gA[2];qa.W=gA[3];
  GFA(1,gA,4);qb.X=gA[0];qb.Y=gA[1];qb.Z=gA[2];qb.W=gA[3];
  qc=qa*qb;
  gA[0]=qc.X;
  gA[1]=qc.Y;
  gA[2]=qc.Z;
  gA[3]=qc.W;
  SFAR(&gA[0],4);
}
DPF(QuatVec){ // v=q*v
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  neQ  q; GFA(2,gA,4); q.X=gA[0];q.Y=gA[1];q.Z=gA[2];q.W=gA[3];
  v=q*v; SFAR(&v[0],3);
}
DPF(QuatLerp){ // q=(qa,qb,t#)
  neQ qa,qb;
  float t=GF(1);
  GFA(2,gA,4); qb.Set(gA[0],gA[1],gA[2],gA[3]);
  GFA(2,gA,4); qa.Set(gA[0],gA[1],gA[2],gA[3]);
  qa=qa+(qb-qa)*t;
  gA[0]=qa.X;gA[1]=qa.Y;gA[2]=qa.Z;gA[3]=qa.W;
  SFAR(&gA[0],4);
}

// ##############
// # neSizeInfo #
// ##############
DPF(CreateSimulatorSizeInfo){
  neSimulatorSizeInfo * p = new neSimulatorSizeInfo;
  STR(hSimulatorSizeInfo,&p);
}
// set neSizeInfo
DPF(SetRigidBodiesCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->rigidBodiesCount = GI(1);
}
DPF(SetRigidParticleCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->rigidParticleCount = GI(1);
}
DPF(SetAnimatedBodiesCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->animatedBodiesCount = GI(1);
}
DPF(SetGeometriesCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->geometriesCount = GI(1);
}
DPF(SetOverlappedPairsCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->overlappedPairsCount = GI(1);
}
DPF(SetConstraintsCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->constraintsCount = GI(1);
}
DPF(SetConstraintSetsCount){
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->constraintSetsCount = GI(1);
}
DPF(SetConstraintBufferSize){
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->constraintBufferSize = GI(1);
}
DPF(SetControllersCount){
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->controllersCount = GI(1);
}
DPF(SetSensorsCount){
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->sensorsCount = GI(1);
}
DPF(SetTerrainNodesStartCount) {
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->terrainNodesStartCount = GI(1);
}
DPF(SetTerrainNodesGrowByCount){
  GSIMULATORLATORSIZEINFO(2);pSimulatorSizeInfo->terrainNodesGrowByCount = GI(1);
}


// get neSizeInfo
DPF(GetRigidBodiesCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->rigidBodiesCount);
}
DPF(GetRigidParticleCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->rigidParticleCount);
}
DPF(GetAnimatedBodiesCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->animatedBodiesCount);
}
DPF(GetGeometriesCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->geometriesCount);
}
DPF(GetOverlappedPairsCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->overlappedPairsCount);
}
DPF(GetConstraintsCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->constraintsCount);
}
DPF(GetConstraintSetsCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->constraintSetsCount);
}
DPF(GetConstraintBufferSize) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->constraintBufferSize);
}
DPF(GetSensorsCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->sensorsCount);
}
DPF(GetControllersCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->controllersCount);
}
DPF(GetTerrainNodesStartCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->terrainNodesStartCount);
}
DPF(GetTerrainNodesGrowByCount) {
  GSIMULATORLATORSIZEINFO(1);SIR(pSimulatorSizeInfo->terrainNodesGrowByCount);
}


// ###############
// # neSimulator #
// ###############
DPF(CreateSimulator) { // simu=create(ssi,gx#,gy#,gz#)
  neV3 gravity; GSIMULATORLATORSIZEINFO(4); gravity.Set(GF(3),GF(2),GF(1));
  pSimulator=neSimulator::CreateSimulator(*pSimulatorSizeInfo, NULL, &gravity);RSIMULATOR();
  AllocUserDataPool();

}
DPF(CreateSimulatorA) { // simu=create(ssi,g#())
  GFA(1,gA,3);neV3 gravity; GSIMULATORLATORSIZEINFO(2); gravity.Set(&gA[0]);
  pSimulator=neSimulator::CreateSimulator(*pSimulatorSizeInfo, NULL, &gravity);RSIMULATOR();
  AllocUserDataPool();
}
DPF(DestroySimulator) {
  GSIMULATOR(1);
  if (pSimulator!=NULL) {
    neSimulator::DestroySimulator(pSimulator);pSimulator=NULL;
  }
}

#ifndef NO_PERFORMANCE
DPF(SimulatorAdvance){
  GSIMULATOR(1);pSimulator->Advance(0.01f,1,NULL);
}
DPF(SimulatorAdvance1){
  GSIMULATOR(2);pSimulator->Advance(GF(1),1,NULL);
}
DPF(SimulatorAdvance2){
  GSIMULATOR(3);pSimulator->Advance(GF(2),GI(1),NULL);
}
DPF(SimulatorAdvance3){ // sec, minTimeStep, maxTimeStep
  GSIMULATOR(4);pSimulator->Advance(GF(3),GF(2),GF(1),NULL);
}
#else
DPF(SimulatorAdvance){
  GSIMULATOR(1);pSimulator->Advance(0.01f,1);
}
DPF(SimulatorAdvance1){
  GSIMULATOR(2);pSimulator->Advance(GF(1),1);
}
DPF(SimulatorAdvance2){
  GSIMULATOR(3);pSimulator->Advance(GF(2),GI(1));
}
DPF(SimulatorAdvance3){ // sec, minTimeStep, maxTimeStep
  GSIMULATOR(4);pSimulator->Advance(GF(3),GF(2),GF(1));
}
#endif


// inside Callbacks
DPF(GetCollisionInfo){
  RCOLLISIONINFO();
}
#ifndef NO_BREAKAGE
DPF(GetBreakageInfo){
  RBREAKAGEINFO();
}
#endif

DPF(SimulatorGetIdleBodyCount) {
  GSIMULATOR(1); SIR(pSimulator->GetIdleBodyCount());
}

DPF(SimulatorCreateRigidBody){ // simulator
  GSIMULATOR(1);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyCube) { // simulator, size#, mass#
  GSIMULATOR(3);
  pRigidBody   = pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry = pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(2),GF(2),GF(2));
  pRigidBody->SetInertiaTensor(neCubeInertiaTensor(GF(2), GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyCubeMat) { // simulator,size#,mass#,mat%
  GSIMULATOR(4);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(3),GF(3),GF(3));
  pGeometry->SetMaterialIndex(GI(1));
  pRigidBody->SetInertiaTensor(neCubeInertiaTensor(GF(3),GF(2)));
  pRigidBody->SetMass(GF(2));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyBox) { // simulator, w#,h#,d#, mass#
  GSIMULATOR(5);
  pRigidBody   = pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry = pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(4),GF(3),GF(2));
  pRigidBody->SetInertiaTensor(neBoxInertiaTensor(GF(4),GF(3),GF(2), GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyBoxMat) { // simulator,w#,h#,d#,mass#,mat%
  GSIMULATOR(6);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(5),GF(4),GF(3));
  pGeometry->SetMaterialIndex(GI(1));
  pRigidBody->SetInertiaTensor(neBoxInertiaTensor(GF(5),GF(4),GF(3),GF(2)));
  pRigidBody->SetMass(GF(2));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodySphere) { // simulator, d#, mass#
  GSIMULATOR(3);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetSphereDiameter(GF(2));
  pRigidBody->SetInertiaTensor(neSphereInertiaTensor(GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}
DPF(SimulatorCreateRigidBodySphereMat) { // simulator,d#,mass#,mat%
  GSIMULATOR(4);

  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetSphereDiameter(GF(3));
  pGeometry->SetMaterialIndex(GI(1));
  pRigidBody->SetInertiaTensor(neSphereInertiaTensor(GF(3),GF(2)));
  pRigidBody->SetMass(GF(2));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyCylinder) { // simulator, d#,h#, mass#
  GSIMULATOR(4);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));
  pGeometry->SetCylinder(GF(3),GF(2));
  pRigidBody->SetInertiaTensor(neCylinderInertiaTensor(GF(3),GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidBodyCylinderMat) { // simulator,d#,h#,mass#,mat%
  GSIMULATOR(5);
  pRigidBody=pSimulator->CreateRigidBody();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetCylinder(GF(4),GF(3));
  pGeometry->SetMaterialIndex(GI(1));
  pRigidBody->SetInertiaTensor(neCylinderInertiaTensor(GF(4),GF(3),GF(2)));
  pRigidBody->SetMass(GF(2));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidParticle){ // simulator
  GSIMULATOR(1);
  pRigidBody=pSimulator->CreateRigidParticle();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidParticleCube) { // simulator, size#, mass#
  GSIMULATOR(3);
  pRigidBody=pSimulator->CreateRigidParticle();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(2),GF(2),GF(2));
  pRigidBody->SetInertiaTensor(neBoxInertiaTensor(GF(2),GF(2),GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidParticleBox) { // simulator, w#,h#,d#, mass#
  GSIMULATOR(5);
  pRigidBody=pSimulator->CreateRigidParticle();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(4),GF(3),GF(2));
  pRigidBody->SetInertiaTensor(neBoxInertiaTensor(GF(4),GF(3),GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidParticleSphere) { // simulator, d#, mass#
  GSIMULATOR(3);
  pRigidBody=pSimulator->CreateRigidParticle();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetSphereDiameter(GF(2));
  pRigidBody->SetInertiaTensor(neSphereInertiaTensor(GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}

DPF(SimulatorCreateRigidParticleCylinder) { // simulator, d#,h#, mass#
  GSIMULATOR(4);
  pRigidBody=pSimulator->CreateRigidParticle();
  pRigidBody->SetUserData(AllocUserData(RIGIDBODY));

  pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetCylinder(GF(3),GF(2));
  pRigidBody->SetInertiaTensor(neCylinderInertiaTensor(GF(3),GF(2),GF(1)));
  pRigidBody->SetMass(GF(1));
  pRigidBody->UpdateBoundingInfo();
  RRIGIDBODY();
}


DPF(SimulatorFreeRigidBody){ // (simu,rb)
  GSIMULATOR(2);
  GRIGIDBODY(1);
  gpUD=(UserData *)pRigidBody->GetUserData();
  gpUD->inUse=0;

  pRigidBody->BeginIterateGeometry();
  pGeometry=pRigidBody->GetNextGeometry();
  while (pGeometry!=NULL) {
    gpUD=(UserData *)pGeometry->GetUserData();
    if (gpUD->convexData.pConvex!=NULL) {
      delete[] gpUD->convexData.pConvex;
      gpUD->convexData.pConvex=NULL;
    }
    gpUD->inUse=0;
    pGeometry=pRigidBody->GetNextGeometry();
  }

  pRigidBody->BeginIterateSensor();
  pSensor=pRigidBody->GetNextSensor();
  while (pSensor!=NULL) {
    gpUD=(UserData *)pSensor->GetUserData();
    gpUD->inUse=0;
    pSensor=pRigidBody->GetNextSensor();
  }

  pSimulator->FreeRigidBody(pRigidBody);
}

DPF(SimulatorCreateAnimatedBody){
  GSIMULATOR(1);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));
  RANIMATEDBODY();
}

DPF(SimulatorCreateAnimatedBodyCube) { // simulator, size#
  GSIMULATOR(2);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(1),GF(1),GF(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}
DPF(SimulatorCreateAnimatedBodyCubeMat) { // simulator, size#, mat%
  GSIMULATOR(3);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(2),GF(2),GF(2));
  pGeometry->SetMaterialIndex(GI(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}

DPF(SimulatorCreateAnimatedBodyBox) { // simulator, w#,h#,d#
  GSIMULATOR(4);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(3),GF(2),GF(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}
DPF(SimulatorCreateAnimatedBodyBoxMat) { // simulator, w#,h#,d#, mat%
  GSIMULATOR(5);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetBoxSize(GF(4),GF(3),GF(2));
  pGeometry->SetMaterialIndex(GI(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}
DPF(SimulatorCreateAnimatedBodySphere) { // simulator, d#
  GSIMULATOR(2);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetSphereDiameter(GF(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}

DPF(SimulatorCreateAnimatedBodySphereMat) { // simulator, d#,mat%
  GSIMULATOR(3);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetSphereDiameter(GF(2));
  pGeometry->SetMaterialIndex(GI(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}

DPF(SimulatorCreateAnimatedBodyCylinder) { // simulator, d#,h#
  GSIMULATOR(3);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetCylinder(GF(2),GF(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}
DPF(SimulatorCreateAnimatedBodyCylinderMat) { // simulator, d#,h#,mat%
  GSIMULATOR(4);
  pAnimatedBody=pSimulator->CreateAnimatedBody();
  pAnimatedBody->SetUserData(AllocUserData(ANIMATEDBODY));

  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));

  pGeometry->SetCylinder(GF(3),GF(2));
  pGeometry->SetMaterialIndex(GI(1));
  pAnimatedBody->UpdateBoundingInfo();
  RANIMATEDBODY();
}
DPF(SimulatorFreeAnimatedBody){ // (simu,ab)
  GSIMULATOR(2);
  GANIMATEDBODY(1);

  gpUD=(UserData *)pAnimatedBody->GetUserData();
  gpUD->inUse=0;

  pAnimatedBody->BeginIterateGeometry();
  pGeometry=pAnimatedBody->GetNextGeometry();
  while (pGeometry!=NULL) {
    gpUD=(UserData *)pGeometry->GetUserData();
    if (gpUD->convexData.pConvex!=NULL) {
      delete[] gpUD->convexData.pConvex;
      gpUD->convexData.pConvex=NULL;
    }
    gpUD->inUse=0;
    pGeometry=pAnimatedBody->GetNextGeometry();
  }

  pAnimatedBody->BeginIterateSensor();
  pSensor=pAnimatedBody->GetNextSensor();
  while (pSensor!=NULL) {
    gpUD=(UserData *)pSensor->GetUserData();
    gpUD->inUse=0;
    pSensor=pAnimatedBody->GetNextSensor();
  }


  pSimulator->FreeAnimatedBody(pAnimatedBody);
}

DPF(SimulatorSetMaterial){ // simulator, index%,f#,r#
  GSIMULATOR(4);
  SIR(pSimulator->SetMaterial(GI(3),GF(2),GF(1)));
}
DPF(SimulatorGetMaterial){ // simulator, index%,&f#,&r#
  float a,b;
  GSIMULATOR(4);
  SIR(pSimulator->GetMaterial(GI(3),a,b));
  SF(2,&a);
  SF(1,&b);
}

DPF(SimulatorCreateJoint){ //simu,rb
  GSIMULATOR(2);
  GRIGIDBODY(1);
  pJoint=pSimulator->CreateJoint(pRigidBody);
  pJoint->SetUserData(AllocUserData(JOINT));
  RJOINT();
}
DPF(SimulatorCreateJointRB){ // simu,rb,rb
  GRIGIDBODY(1);
  neRigidBody * b=pRigidBody;
  GSIMULATOR(3);
  GRIGIDBODY(2);
  pJoint=pSimulator->CreateJoint(pRigidBody,b);
  pJoint->SetUserData(AllocUserData(JOINT));
  RJOINT();
}
DPF(SimulatorCreateJointAB){ // simu.rb,ab
  GANIMATEDBODY(1);neAnimatedBody * b=pAnimatedBody;
  GSIMULATOR(3);GRIGIDBODY(2);
  pJoint=pSimulator->CreateJoint(pRigidBody,b);
  pJoint->SetUserData(AllocUserData(JOINT));
  RJOINT();
}
DPF(SimulatorFreeJoint){
  GSIMULATOR(2);GJOINT(1);
  gpUD=(UserData *)pJoint->GetUserData();
  gpUD->inUse=0;
  pSimulator->FreeJoint(pJoint);
}

DPF(SimulatorSetGravity){ // simu,x#,y#,z#
  GSIMULATOR(4);neV3 g;g.Set(GF(3),GF(2),GF(1));pSimulator->Gravity(g);
}
DPF(SimulatorSetGravityA){ // simu,g#()
  neV3 g;
  GFA(2,gA,3);
  g.Set(gA[0],gA[1],gA[2]);
  GSIMULATOR(2);
  pSimulator->Gravity(g);
}
DPF(SimulatorGetGravity){ // g#()=(simu)
  neV3 g;
  GSIMULATOR(1);
  g=pSimulator->Gravity();
  SFAR(&g[0],3);
}

DPF(SimulatorGetCollisionTable){ // table=(simu)
  GSIMULATOR(1);
  pCollisionTable=pSimulator->GetCollisionTable();
  RCOLLISIONTABLE();
}
DPF(SimulatorSetCollisionCallback){ // simu,"Callbacksub()"
  GSIMULATOR(2);
  int codeid=gpCompiler->Compile(GS(1));
  if (codeid!=0) {
    gCIC=codeid;
    pSimulator->SetCollisionCallback(&CollisionInfoCallback);
  }  else {
    pSimulator->SetCollisionCallback(NULL);
  }
}
#ifndef NO_BREAKAGE
DPF(SimulatorSetBreakageCallback){ // simu,"Callbacksub()"
  GSIMULATOR(2);
  int codeid=gpCompiler->Compile(GS(1));
  if (codeid!=0) {
    hBreakageCallback=codeid;
    pSimulator->SetBreakageCallback(&BreakageCallback);
  }  else {
    pSimulator->SetBreakageCallback(NULL);
  }
}
#endif // NO_BREAKAGE

DPF(SimulatorSetTerrainMesh){ //simu,v#(),nv%,i%(),ni%

  f32 *ver=NULL;
  s32 *ind=NULL;
  int nf,ni,i,j,p;
  GSIMULATOR(5);nf=GI(3);ni=GI(1);
  ver=(f32 *) malloc(sizeof(float) * nf);GFA(4,ver,nf);nf/=3;
  ind=(s32 *) malloc(sizeof(int)   * ni);GIA(2,ind,ni);ni/=3;

  tMesh.vertexCount = nf;
  if (tMesh.vertices != NULL)
     free(tMesh.vertices);

  tMesh.vertices = (neV3*) malloc (sizeof(neV3) * nf);
  for ( i = 0; i < nf; i++ ) {
    p=i*3;tMesh.vertices[i].Set (ver[p], ver[p+1], ver[p+2]);
  }

  tMesh.triangleCount = ni;
  if (tMesh.triangles != NULL)
    free(tMesh.triangles);

  tMesh.triangles = (neTriangle*) malloc ( sizeof ( neTriangle ) * ni);


  for ( i = 0; i < ni; i++ ) {
    p=i*3;
    for ( j = 0; j < 3; j++ ) {
      tMesh.triangles[i].indices[j] = ind[p+j];
    }
    tMesh.triangles[i].materialID = 0;
    tMesh.triangles[i].flag = neTriangle::NE_TRI_TRIANGLE;

  }
  pSimulator->SetTerrainMesh(&tMesh);
  free(ver);
  free(ind);
}

DPF(SimulatorSetTerrainMesh2){ //simu,v#()(),nv%,i%()(),ni%
  f32 *ver=NULL;
  s32 *ind=NULL;
  int nv,ni,i,j,p;
  GSIMULATOR(5);
  nv=GI(3);
  ni=GI(1);
  ver=(f32 *) malloc(sizeof(float) * nv * 3);GFA2(4,ver,nv,3);
  ind=(s32 *) malloc(sizeof(int)   * ni * 3);GIA2(2,ind,ni,3);

  tMesh.vertexCount = nv;
  if (tMesh.vertices != NULL){
     free(tMesh.vertices);
  }
  tMesh.vertices = (neV3*) malloc (sizeof(neV3) * nv);
  for ( i = 0; i < nv; i++ ) {
    p=i*3;
    tMesh.vertices[i].Set (ver[p], ver[p+1], ver[p+2]);
  }

  tMesh.triangleCount = ni;
  if (tMesh.triangles != NULL){
    free(tMesh.triangles);
  }
  tMesh.triangles = (neTriangle*) malloc ( sizeof ( neTriangle ) * ni);


  for ( i = 0; i < ni; i++ ) {
    p=i*3;
    for ( j = 0; j < 3; j++ ) {
      tMesh.triangles[i].indices[j] = ind[p+j];
    }
    tMesh.triangles[i].materialID = 0;
    tMesh.triangles[i].flag = neTriangle::NE_TRI_TRIANGLE;

  }
  pSimulator->SetTerrainMesh(&tMesh);
  free(ver);
  free(ind);
}

DPF(SimulatorFreeTerrainMesh){
  GSIMULATOR(1);
  pSimulator->FreeTerrainMesh();
}

DPF(SimulatorGetMemoryAllocated){
  s32 m;
  GSIMULATOR(1);pSimulator->GetMemoryAllocated(m);
  SIR(m);
}

// ###############
// # neRigidBody #
// ###############
DPF(RigidBodySetUserData){ // rb,value%
  GRIGIDBODY(2);
  gpUD=(UserData *) pRigidBody->GetUserData();
  gpUD->userData=GI(1);
}
DPF(RigidBodyGetUserData){ // value%=(rb)
  GRIGIDBODY(1);
  gpUD=(UserData *) pRigidBody->GetUserData();
  SIR(gpUD->userData);
}

DPF(RigidBodySetCollisionID){ // (rb,id%)
  GRIGIDBODY(2);pRigidBody->SetCollisionID(GI(1));
}
DPF(RigidBodyGetCollisionID){ //id%=(rb)
  GRIGIDBODY(1);SIR(pRigidBody->GetCollisionID());
}


DPF(RigidBodyUpdateBoundingInfo){
  GRIGIDBODY(1);
  pRigidBody->UpdateBoundingInfo();
}
// rigidbody mass and tensor
DPF(RigidBodySetMass){
  GRIGIDBODY(2);pRigidBody->SetMass(GF(1));
}
DPF(RigidBodyGetMass){
  GRIGIDBODY(1); SFR(pRigidBody->GetMass());
}
DPF(RigidBodySetInertiaTensor){ //rb,ix#,iy#,iz#
  neV3 v;
  v.Set(GF(3),GF(2),GF(1));
  GRIGIDBODY(4);
  pRigidBody->SetInertiaTensor(v);
}
DPF(RigidBodySetInertiaTensorA){ //rb,ixyz#()
  GFA(1,gA,3);
  neV3 v; v.Set(gA[0],gA[0],gA[0]);
  GRIGIDBODY(2); pRigidBody->SetInertiaTensor(v);
}

DPF(RigidBodySetBoxInertiaTensor){ //rb,w,h,d,mass
  GRIGIDBODY(5); pRigidBody->SetInertiaTensor(neBoxInertiaTensor(GF(4),GF(3),GF(2),GF(1)));
}
DPF(RigidBodySetBoxInertiaTensorA){ //rb,size(),mass
  GFA(2,gA,3);
  GRIGIDBODY(3);
  pRigidBody->SetInertiaTensor(neBoxInertiaTensor(gA[0],gA[1],gA[3],GF(1)));
}
DPF(RigidBodySetSphereInertiaTensor){ //rb,diameter,mass
  GRIGIDBODY(3);pRigidBody->SetInertiaTensor(neSphereInertiaTensor(GF(2),GF(1)));
}
DPF(RigidBodySetCylinderInertiaTensor){ //rb,diameter,height,mass
  GRIGIDBODY(4);pRigidBody->SetInertiaTensor(neCylinderInertiaTensor(GF(3), GF(2), GF(1)));
}

// RigidBodyGeometry
DPF(RigidBodyGetGeometryCount){
  GRIGIDBODY(1);SIR(pRigidBody->GetGeometryCount());
}
DPF(RigidBodyAddGeometry){
  GRIGIDBODY(1);pGeometry=pRigidBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));
  RGEOMETRY();
}
DPF(RigidBodyRemoveGeometry){
  GRIGIDBODY(2);GGEOMETRY(1);
  SIR(pRigidBody->RemoveGeometry(pGeometry));
}
DPF(RigidBodyBeginIterateGeometry){
  GRIGIDBODY(1);pRigidBody->BeginIterateGeometry();
}
DPF(RigidBodyGetNextGeometry){
  GRIGIDBODY(1);pGeometry=pRigidBody->GetNextGeometry();RGEOMETRY();
}
DPF(RigidBodyBreakGeometry) {
  GGEOMETRY(1);GRIGIDBODY(2);pRigidBody=pRigidBody->BreakGeometry(pGeometry);RRIGIDBODY();
}


DPF(RigidBodySetAngularDamping){
  GRIGIDBODY(2);pRigidBody->SetAngularDamping(GF(1));
}
DPF(RigidBodyGetAngularDamping){
  GRIGIDBODY(1);SFR(pRigidBody->GetAngularDamping());
}

DPF(RigidBodySetLinearDamping){
  GRIGIDBODY(2);pRigidBody->SetLinearDamping(GF(1));
}
DPF(RigidBodyGetLinearDamping){
  GRIGIDBODY(1);SFR(pRigidBody->GetLinearDamping());
}

DPF(RigidBodySetPos){ // rb,x,y,z
  neV3 pos; pos.Set(GF(3), GF(2), GF(1));
  GRIGIDBODY(4);pRigidBody->SetPos(pos);
}
DPF(RigidBodySetPosA){ // rb,p#()
  GFA(1,gA,3); neV3 pos; pos.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2);pRigidBody->SetPos(pos);
}
DPF(RigidBodyGetPos){ // p#()=Get(rb)
  neV3 p; GRIGIDBODY(1); p=pRigidBody->GetPos();
  SFAR(&p[0],3);
}

DPF(RigidBodyGetOpenGLMatrix){
  GRIGIDBODY(1); gT3=pRigidBody->GetTransform();
  gT3.MakeD3DCompatibleMatrix();
  SFAR2((float *) &gT3,4,4);
}
DPF(RigidBodyGetTransform){
  GRIGIDBODY(1); gT3=pRigidBody->GetTransform();
  SFAR2((float *) &gT3,4,4);
}
DPF(RigidBodyGetInverseTransform){
  GRIGIDBODY(1); gT3=pRigidBody->GetTransform();
  Matrix3D m((float *) &gT3); m.Inverse();
  SFAR2((float *) &m,4,4);
}


DPF(RigidBodySetRotation){ // (rb,xr,yr,zr)
  neV3 r; r.Set(GF(3),GF(2),GF(1));
  gT3.rot.RotateXYZ(r);
  GRIGIDBODY(4);
  pRigidBody->SetRotation(gT3.rot);
}
DPF(RigidBodySetRotationA){ // (rb,r#())
  neV3 r;
  GFA(1,gA,3);
  r.Set(gA[0],gA[1],gA[2]);
  gT3.rot.RotateXYZ(r);
  GRIGIDBODY(2);pRigidBody->SetRotation(gT3.rot);
}
DPF(RigidBodyGetRotation){ //r#()=(rb)
  GRIGIDBODY(1);
  neV3 r=RotAngle(pRigidBody->GetRotationM3());
  SFAR(&r[0],3);
}

DPF(RigidBodySetQuaternion){ // (rb,q#())
  neQ q;GFA(1,gA,4);q.Set(gA[0],gA[1],gA[2],gA[3]);
  GRIGIDBODY(2); pRigidBody->SetRotation(q);
}

DPF(RigidBodyGetQuaternion){ //q#()=(rb)
  neQ q; GRIGIDBODY(1); q=pRigidBody->GetRotationQ();
  gA[0] = q.X;
  gA[1] = q.Y;
  gA[2] = q.Z;
  gA[3] = q.W;
  SFAR(&gA[0],4);
}


DPF(RigidBodySetForce){ // (rb,force#())
  neV3 f;
  GFA(1,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2);
  pRigidBody->SetForce(f);
}
DPF(RigidBodySetForcePos){ // (rb,force#(),pos#())
  neV3 f,p;
  GFA(1,gA,3);p.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);f.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(3);pRigidBody->SetForce(f,p);
}
DPF(RigidBodyGetForce){ // force#() =(rb)
  neV3 f; GRIGIDBODY(1); f=pRigidBody->GetForce();
  SFAR(&f[0],3);
}

DPF(RigidBodySetTorque){
  neV3 t;
  GFA(1,gA,3);
  t.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2);
  pRigidBody->SetTorque(t);
}
DPF(RigidBodyGetTorque){
  neV3 t;
  GRIGIDBODY(1);
  t=pRigidBody->GetTorque();
  SFAR(&t[0],3);
}

DPF(RigidBodySetVelocity){
  neV3 v;
  GFA(1,gA,3);
  v.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2);
  pRigidBody->SetVelocity(v);
}
DPF(RigidBodyGetVelocity){
  neV3 v;
  GRIGIDBODY(1);
  v=pRigidBody->GetVelocity();
  SFAR(&v[0],3);
}

DPF(RigidBodyGetVelocityAtPoint){ // v#()=(rb,px#,py#,pz#)
  neV3 p; p.Set(GF(3),GF(2),GF(1));
  GRIGIDBODY(4);
  p=pRigidBody->GetVelocityAtPoint(p);
  SFAR(&p[0],3);
}
DPF(RigidBodyGetVelocityAtPointA){ // v#()=Get(rb,point#())
  GFA(1,gA,3);
  neV3 p;p.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2);
  p=pRigidBody->GetVelocityAtPoint(p);
  SFAR(&p[0],3);
}

DPF(RigidBodyGetAngularVelocity){
  neV3 v;
  GRIGIDBODY(1);
  v=pRigidBody->GetAngularVelocity();
  SFAR(&v[0],3);
}

DPF(RigidBodyGetAngularMomentum){
  neV3 m;
  GRIGIDBODY(1);
  m=pRigidBody->GetAngularMomentum();
  SFAR(&gA[0],3);
}
DPF(RigidBodySetAngularMomentum){ // rb,x#,y#,z#
  neV3 m;
  m.Set(GF(3),GF(2),GF(1));
  GRIGIDBODY(4);
  pRigidBody->SetAngularMomentum(m);
}
DPF(RigidBodySetAngularMomentumA){ // rb,AngularMomentum#()
  neV3 m; GFA(1,gA,3); m.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2); pRigidBody->SetAngularMomentum(m);
}

DPF(RigidBodyApplyImpulse){
  neV3 i; GFA(1,gA,3); i.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2); pRigidBody->ApplyImpulse(i);
}
DPF(RigidBodyApplyImpulsePos){
  neV3 i,p;
  GFA(1,gA,3);p.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);i.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(3);
  pRigidBody->ApplyImpulse(i,p);
}
DPF(RigidBodyApplyTwist){
  neV3 t; GFA(1,gA,3); t.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2); pRigidBody->ApplyTwist(t);
}

DPF(RigidBodyGravityEnable){
  GRIGIDBODY(2); pRigidBody->GravityEnable(GI(1));
}
DPF(RigidBodyGravityIsEnable){
  GRIGIDBODY(1); SIR(pRigidBody->GravityEnable());
}

DPF(RigidBodyCollideConnected){
  GRIGIDBODY(2); pRigidBody->CollideConnected(GI(1));
}
DPF(RigidBodyCollideIsConnected){
  GRIGIDBODY(1); SIR(pRigidBody->CollideConnected());
}

DPF(RigidBodyCollideDirectlyConnected){
  GRIGIDBODY(2); pRigidBody->CollideDirectlyConnected(GI(1));
}
DPF(RigidBodyCollideIsDirectlyConnected){
  GRIGIDBODY(1); SIR(pRigidBody->CollideDirectlyConnected());
}

DPF(RigidBodyActive){
  GRIGIDBODY(2);
  neRigidBody * nrb=NULL;
  pRigidBody->Active(GI(1),nrb);
}

DPF(RigidBodyActiveHintRB){
  neRigidBody * HintRB;
  GRIGIDBODY(1); HintRB=pRigidBody;
  GRIGIDBODY(3); pRigidBody->Active(GI(2),HintRB);
}
DPF(RigidBodyActiveHintAB){
  GANIMATEDBODY(1); GRIGIDBODY(3); pRigidBody->Active(GI(2),pAnimatedBody);
}
DPF(RigidBodyIsActive){
  GRIGIDBODY(1); SIR(pRigidBody->Active());
}

DPF(RigidBodyIsIdle){
  GRIGIDBODY(1); SIR(pRigidBody->IsIdle());
}

DPF(RigidBodySetSleepingParameter){
  GRIGIDBODY(2); pRigidBody->SetSleepingParameter(GF(1));
}
DPF(RigidBodyGetSleepingParameter){
  GRIGIDBODY(1); SFR(pRigidBody->GetSleepingParameter());
}

DPF(RigidBodyAddSensor){ // sen=rb
  GRIGIDBODY(1); pSensor=pRigidBody->AddSensor(); RSENSOR();
}
DPF(RigidBodyRemoveSensor){
  GRIGIDBODY(2); GSENSOR(1); SIR(pRigidBody->RemoveSensor(pSensor));
}
DPF(RigidBodyBeginIterateSensor){
  GRIGIDBODY(1); pRigidBody->BeginIterateSensor();
}
DPF(RigidBodyGetNextSensor){
  GRIGIDBODY(1); pSensor=pRigidBody->GetNextSensor(); RSENSOR();
}

DPF(RigidBodyAddController) { // rbc=AddController(rb,"sub()")
  GRIGIDBODY(2);
  gpUD = (UserData *) pRigidBody->GetUserData();

  gpUD->controllerCode = gpCompiler->Compile(GS(1));
  if (gpUD->controllerCode!=0) {
    pRigidBodyController=pRigidBody->AddController(&RBInstance,0);
    RRIGIDBODYCONTROLLER();
  }
}
DPF(RigidBodyAddController2) { // rbc=AddController(rb,"sub()",period%)
  GRIGIDBODY(3);
  gpUD = (UserData *) pRigidBody->GetUserData();
  gpUD->controllerCode = gpCompiler->Compile(GS(2));
  if (gpUD->controllerCode!=0) {
    pRigidBodyController=pRigidBody->AddController(&RBInstance,GI(1));
    RRIGIDBODYCONTROLLER();
  }
}
DPF(RigidBodyRemoveController) {
  GRIGIDBODY(2); GRIGIDBODYCONTROLLER(1); SIR(pRigidBody->RemoveController(pRigidBodyController));
}
DPF(RigidBodyBeginIterateController) {
  GRIGIDBODY(1); pRigidBody->BeginIterateController();
}
DPF(RigidBodyGetNextController) {
  GRIGIDBODY(1); pRigidBodyController=pRigidBody->GetNextController(); RRIGIDBODYCONTROLLER();
}

// rigidbody transform
DPF(RigidBodyTransformDirection) {// r#()= rb.m3 * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2); gT3=pRigidBody->GetTransform();
  v = gT3.rot * v;
  SFAR(&v[0],3);
}
DPF(RigidBodyTransformPoint) {// r#()= rb.t * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODY(2); gT3=pRigidBody->GetTransform();
  v = gT3 * v;
  SFAR(&v[0],3);
}


// #########################
// # neRigidBodyController #
// #########################
DPF(GetRigidBodyController){
  RRIGIDBODYCONTROLLER();
}

DPF(RigidBodyControllerGetRigidBody){
  GRIGIDBODYCONTROLLER(1);
  pRigidBody=pRigidBodyController->GetRigidBody();
  RRIGIDBODY();
}
DPF(RigidBodyControllerGetForce){
  neV3 f;
  GRIGIDBODYCONTROLLER(1);
  f=pRigidBodyController->GetControllerForce();
  SFAR(&f[0],3);
}
DPF(RigidBodyControllerGetTorque){
  neV3 t;
  GRIGIDBODYCONTROLLER(1);
  t=pRigidBodyController->GetControllerTorque();
  SFAR(&t[0],3);
}
DPF(RigidBodyControllerSetForce){
  neV3 f;
  GFA(1,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODYCONTROLLER(2);
  pRigidBodyController->SetControllerForce(f);
}
DPF(RigidBodyControllerSetTorque){
  neV3 t;
  GFA(1,gA,3);
  t.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODYCONTROLLER(2);
  pRigidBodyController->SetControllerTorque(t);
}
DPF(RigidBodyControllerSetForceWithTorque){
  neV3 f,p;
  GFA(1,gA,3);p.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);f.Set(gA[0],gA[1],gA[2]);
  GRIGIDBODYCONTROLLER(3);
  pRigidBodyController->SetControllerForceWithTorque(f,p);
}

// ##################
// # neAnimatedBody #
// ##################
DPF(AnimatedBodySetUserData){ // (ab,value%)
  GANIMATEDBODY(2);
  gpUD=(UserData *) pAnimatedBody->GetUserData();
  gpUD->userData=GI(1);
}
DPF(AnimatedBodyGetUserData){ // value%=(ab)
  GANIMATEDBODY(1);
  gpUD=(UserData *) pAnimatedBody->GetUserData();

  SIR(gpUD->userData);
}
DPF(AnimatedBodySetPos){ // (ab,x#,y#,z#)
  neV3 pos; pos.Set(GF(3),GF(2),GF(1)); GANIMATEDBODY(4); pAnimatedBody->SetPos(pos);
}
DPF(AnimatedBodySetPosA){ // (ab,p#())
  GFA(1,gA,3); neV3 pos;pos.Set(gA[0],gA[1],gA[2]); GANIMATEDBODY(2);pAnimatedBody->SetPos(pos);
}
DPF(AnimatedBodyGetPos){ // p#()=(ab)
  neV3 p; GANIMATEDBODY(1);p=pAnimatedBody->GetPos(); SFAR(&p[0],3);
}

DPF(AnimatedBodyGetOpenGLMatrix){
  GANIMATEDBODY(1); gT3=pAnimatedBody->GetTransform();
  gT3.MakeD3DCompatibleMatrix();
  SFAR2((float *) &gT3,4,4);
  /*
  gA[ 0]=t.rot[0][0];gA[ 1]=t.rot[0][1];gA[ 2]=t.rot[0][2];gA[ 3]=0.0f;
  gA[ 4]=t.rot[1][0];gA[ 5]=t.rot[1][1];gA[ 6]=t.rot[1][2];gA[ 7]=0.0f;
  gA[ 8]=t.rot[2][0];gA[ 9]=t.rot[2][1];gA[10]=t.rot[2][2];gA[11]=0.0f;
  gA[12]=t.pos[0]   ;gA[13]=t.pos[1]   ;gA[14]=t.pos[2]   ;gA[15]=1.0f;
  SFAR2(&gA[0],4,4);
  */
}
DPF(AnimatedBodyGetTransform){
  GANIMATEDBODY(1); gT3=pAnimatedBody->GetTransform();
  SFAR2((float *) &gT3,4,4);
}
DPF(AnimatedBodyGetInverseTransform){
  GANIMATEDBODY(1); gT3=pAnimatedBody->GetTransform();
  Matrix3D m((float *) &gT3);
  m.Inverse();
  SFAR2((float *) &m,4,4);
}

DPF(AnimatedBodySetRotation){ //ab,xr,yr,zr
  neV3 r;
  r.Set(GF(3),GF(2),GF(1));
  gT3.rot.RotateXYZ(r);
  GANIMATEDBODY(4);pAnimatedBody->SetRotation(gT3.rot);
}
DPF(AnimatedBodySetRotationA){ //ab,r#()
  neV3 r; GFA(1,gA,3);
  r.Set(gA[0],gA[1],gA[2]);
  gT3.rot.RotateXYZ(r);
  GANIMATEDBODY(2);pAnimatedBody->SetRotation(gT3.rot);
}
DPF(AnimatedBodyGetRotation){ //r#() = Get(ab)
  GANIMATEDBODY(1);
  neV3 r = RotAngle(pAnimatedBody->GetRotationM3());
  SFAR(&r[0],3);
}

DPF(AnimatedBodySetQuaternion){ // (ab,q)
  neQ q;GFA(1,gA,4);q.Set(gA[0],gA[1],gA[2],gA[3]);
  GANIMATEDBODY(2); pAnimatedBody->SetRotation(q);
}

DPF(AnimatedBodyGetQuaternion){ //Q#() = Get(ab)
  neQ q; GANIMATEDBODY(1); q=pAnimatedBody->GetRotationQ();
  gA[0] = q.X;
  gA[1] = q.Y;
  gA[2] = q.Z;
  gA[3] = q.W;
  SFAR(&gA[0],4);
}

DPF(AnimatedBodySetCollisionID){ // ab,id
  GANIMATEDBODY(2);
  pAnimatedBody->SetCollisionID(GI(1));
}
DPF(AnimatedBodyGetCollisionID){ //id=Get(ab)
  GANIMATEDBODY(1);
  SIR(pAnimatedBody->GetCollisionID());
}

DPF(AnimatedBodyAddGeometry){
  GANIMATEDBODY(1);
  pGeometry=pAnimatedBody->AddGeometry();
  pGeometry->SetUserData(AllocUserData(GEOMETRY));
  RGEOMETRY();
}
DPF(AnimatedBodyUpdateBoundingInfo){
  GANIMATEDBODY(1);
  pAnimatedBody->UpdateBoundingInfo();
}

DPF(AnimatedBodyGetGeometryCount){
  GANIMATEDBODY(1);
  SIR(pAnimatedBody->GetGeometryCount());
}
DPF(AnimatedBodyRemoveGeometry){
  GANIMATEDBODY(2);
  GGEOMETRY(1);
  SIR(pAnimatedBody->RemoveGeometry(pGeometry));
}
DPF(AnimatedBodyBeginIterateGeometry){
  GANIMATEDBODY(1);
  pAnimatedBody->BeginIterateGeometry();
}
DPF(AnimatedBodyGetNextGeometry){
  GANIMATEDBODY(1);
  pGeometry=pAnimatedBody->GetNextGeometry();
  RGEOMETRY();
}
DPF(AnimatedBreakGeometry) {
  GGEOMETRY(1);
  GANIMATEDBODY(2);
  pRigidBody=pAnimatedBody->BreakGeometry(pGeometry);
  RRIGIDBODY();
}
DPF(AnimatedBodyCollideConnected){
  GANIMATEDBODY(2);
  pAnimatedBody->CollideConnected(GI(1));
}
DPF(AnimatedBodyCollideIsConnected){
  GANIMATEDBODY(1);
  SIR(pAnimatedBody->CollideConnected());
}

DPF(AnimatedBodyCollideDirectlyConnected){
  GANIMATEDBODY(2);
  pAnimatedBody->CollideDirectlyConnected(GI(1));
}
DPF(AnimatedBodyCollideIsDirectlyConnected){
  GANIMATEDBODY(1);
  SIR(pAnimatedBody->CollideDirectlyConnected());
}

DPF(AnimatedBodyActive){
  GANIMATEDBODY(2);
  neRigidBody * nrb=NULL;
  pAnimatedBody->Active(GI(1),nrb);
}

DPF(AnimatedBodyActiveHintRB){
  neRigidBody * HintRB;
  GRIGIDBODY(1);
  HintRB=pRigidBody;
  GANIMATEDBODY(3);
  pAnimatedBody->Active(GI(2),HintRB);
}
DPF(AnimatedBodyActiveHintAB){
  neAnimatedBody * HintAB;
  GANIMATEDBODY(1);
  HintAB=pAnimatedBody;
  GANIMATEDBODY(3);
  pAnimatedBody->Active(GI(2),HintAB);
}
DPF(AnimatedBodyIsActive){
  GANIMATEDBODY(1);SIR(pAnimatedBody->Active());
}

#ifdef AB_USE_SENSOR
DPF(AnimatedBodyAddSensor){
  GANIMATEDBODY(1);
  pSensor=pAnimatedBody->AddSensor();
  RSENSOR();
}
DPF(AnimatedBodyRemoveSensor){
  GANIMATEDBODY(2);
  GSENSOR(1);
  SIR(pAnimatedBody->RemoveSensor(pSensor));
}
DPF(AnimatedBodyBeginIterateSensor){
  GANIMATEDBODY(1);
  pAnimatedBody->BeginIterateSensor();
}
DPF(AnimatedBodyGetNextSensor){
  GANIMATEDBODY(1);
  pSensor=pAnimatedBody->GetNextSensor();
  RSENSOR();
}
#endif

// animated body transform
DPF(AnimatedBodyTransformDirection) {// r#()= ab.m3 * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GANIMATEDBODY(2); gT3=pAnimatedBody->GetTransform();
  v = gT3.rot * v;
  SFAR(&v[0],3);
}
DPF(AnimatedBodyTransformPoint) {// r#()= ab.t * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GANIMATEDBODY(2); gT3=pAnimatedBody->GetTransform();
  v = gT3 * v;
  SFAR(&v[0],3);
}

// ##############
// # neGeometry #
// ##############
DPF(GeometrySetUserData){
  GGEOMETRY(2); gpUD=(UserData *) pGeometry->GetUserData();
  gpUD->userData=GI(1);
}
DPF(GeometryGetUserData){
  GGEOMETRY(1); gpUD=(UserData *) pGeometry->GetUserData();
  SIR(gpUD->userData);
}

DPF(GeometrySetMaterialIndex){
  GGEOMETRY(2);
  pGeometry->SetMaterialIndex(GI(1));
}
DPF(GeometryGetMaterialIndex){
  GGEOMETRY(1);
  SIR(pGeometry->GetMaterialIndex());
}

DPF(GeometrySetBoxSize){
  neV3 BoxSize;
  BoxSize.Set(GF(3), GF(2), GF(1));
  GGEOMETRY(4);pGeometry->SetBoxSize(BoxSize);
}
DPF(GeometrySetBoxSizeA){
  GFA(1,gA,3);
  neV3 s;
  s.Set(gA[0],gA[1],gA[2]);
  GGEOMETRY(2);
  pGeometry->SetBoxSize(s);
}
DPF(GeometryGetBoxSize) { // w&,&h,&d
  neV3 s;
  GGEOMETRY(4);
  SIR(pGeometry->GetBoxSize(s));
  SF(3,&s[0]);
  SF(2,&s[1]);
  SF(1,&s[2]);
}
DPF(GeometryGetBoxSizeA){ // size#()=
  neV3 s;
  GGEOMETRY(2);
  SIR(pGeometry->GetBoxSize(s));
  SFA(1,&s[0],3);
}

DPF(GeometrySetSphereDiameter){ //geom,diameter
  GGEOMETRY(2);
  pGeometry->SetSphereDiameter(GF(1));
}
DPF(GeometryGetSphereDiameter){ //geom,&diameter
  float d;
  GGEOMETRY(2);
  SIR(pGeometry->GetSphereDiameter(d));
  SF(1,&d);
}

DPF(GeometrySetCylinderDiameterHeight){ //geom,diameter,height
  GGEOMETRY(3);
  pGeometry->SetCylinder(GF(2),GF(1));
}
DPF(GeometryGetCylinderDiameterHeight){ //geom,&diameter,&height
  float d,h;
  GGEOMETRY(3);
  SIR(pGeometry->GetCylinder(d,h));
  SF(2,&d);
  SF(1,&h);
}

DPF(CreateConvexData) { // ConvexData=(ints%(),nBytes%,sx#,sy#,sz#)
  cData.nBytes = GI(4);
  int nInts = cData.nBytes;
  neByte * pBytes = new neByte[cData.nBytes+3];
  nInts>>=2;
  GIA(5,(int*)pBytes,nInts);
  BuildConvexData(pBytes,GF(3),GF(2),GF(1));
  cData.pConvex  = pBytes;
  cData.UserData = 0;
  cData.ScaleX = GF(3);
  cData.ScaleY = GF(2);
  cData.ScaleZ = GF(1);
  RCONV();
}

DPF(FreeConvexData) { // (ConvexData)
  GCONVEXDATA(1);
  if (cData.pConvex!=NULL) {
    delete[] cData.pConvex;
    cData.pConvex=NULL;
    cData.nBytes=0;
    cData.UserData=0;
  }
  SCONVEXDATA(1);
}

DPF(GeometrySetConvexData){ // (geom,ConvexData)
  GGEOMETRY(2); GCONVEXDATA(1);
  if (cData.pConvex!=NULL) {
    gpUD=(UserData *) pGeometry->GetUserData();
    // delete old convex if any
    if (gpUD->convexData.pConvex!=NULL) {
      delete[]  gpUD->convexData.pConvex;
      gpUD->convexData.pConvex=NULL;
    }
    gpUD->convexData.pConvex = new neByte[cData.nBytes];
    gpUD->convexData.nBytes  = cData.nBytes;
    gpUD->convexData.UserData = cData.UserData;
    memcpy(gpUD->convexData.pConvex,cData.pConvex,cData.nBytes);
    pGeometry->SetConvexMesh(gpUD->convexData.pConvex);

  }
}

DPF(GeometryGetConvexData){ // boolean%=(geom,ConvexData)
  GGEOMETRY(2);
  gpUD=(UserData *) pGeometry->GetUserData();
  if (gpUD->convexData.pConvex!=NULL) {
    cData.pConvex  = gpUD->convexData.pConvex;
    cData.nBytes   = gpUD->convexData.nBytes;
    cData.UserData = gpUD->convexData.UserData;
    SCONVEXDATA(1);
    SIR(-1);
  }
  else
  {
    cData.pConvex  = NULL;
    cData.nBytes   = 0;
    cData.UserData = 0;
    SIR(0);
  }
}

DPF(GeometryGetOpenGLMatrix){
  GGEOMETRY(1); gT3=pGeometry->GetTransform();
  gT3.MakeD3DCompatibleMatrix();
  SFAR2((float *) &gT3,4,4);
  /*
  gA[ 0]=t.rot[0][0];gA[ 1]=t.rot[0][1];gA[ 2]=t.rot[0][2];gA[ 3]=0.0f;
  gA[ 4]=t.rot[1][0];gA[ 5]=t.rot[1][1];gA[ 6]=t.rot[1][2];gA[ 7]=0.0f;
  gA[ 8]=t.rot[2][0];gA[ 9]=t.rot[2][1];gA[10]=t.rot[2][2];gA[11]=0.0f;
  gA[12]=t.pos[0]   ;gA[13]=t.pos[1]   ;gA[14]=t.pos[2]   ;gA[15]=1.0f;
  */
}
DPF(GeometryGetTransform){
  GGEOMETRY(1); gT3=pGeometry->GetTransform();
  SFAR2((float *) &gT3,4,4);
}
DPF(GeometryGetInverseTransform){
  GGEOMETRY(1); gT3=pGeometry->GetTransform();
  Matrix3D m((float *) &gT3);
  m.Inverse();
  SFAR2((float *) &m,4,4);
}

DPF(GeometrySetTransform){ // set(geom,px,py,pz , rx,ry,rz)
  gT3.pos.v[0] = GF(6);
  gT3.pos.v[1] = GF(5);
  gT3.pos.v[2] = GF(4);
  gT3.pos.v[3] = 0;
  gT3.rot = RotMatrix(GF(3),GF(2),GF(1));
  GGEOMETRY(7);pGeometry->SetTransform(gT3);
}
DPF(GeometrySetTransformA){ // set(geom,pos(),rot())
  GFA(2,gA,3);
  gT3.pos.v[0]=gA[0];
  gT3.pos.v[1]=gA[1];
  gT3.pos.v[2]=gA[2];
  gT3.pos.v[3]=0;
  GFA(1,gA,3);
  gT3.rot = RotMatrixArray(gA);
  GGEOMETRY(3);pGeometry->SetTransform(gT3);
}

#ifndef NO_BREAKAGE
DPF(GeometrySetBreakageFlag){
  GGEOMETRY(2);pGeometry->SetBreakageFlag((neGeometry::neBreakFlag)GI(1));
}
DPF(GeometryGetBreakageFlag){
  GGEOMETRY(1);SIR(pGeometry->GetBreakageFlag());
}

DPF(GeometrySetBreakageMass){
  GGEOMETRY(2);pGeometry->SetBreakageMass(GF(1));
}
DPF(GeometryGetBreakageMass){
  GGEOMETRY(1);SFR(pGeometry->GetBreakageMass());
}

DPF(GeometryGetBreakageInertiaTensor){
  neV3 t;GGEOMETRY(1);t=pGeometry->GetBreakageInertiaTensor();SFAR(&t[0],3);
}

DPF(GeometrySetBreakageInertiaTensor){ // geom,ix#,iy#,iz#
  neV3 v; v.Set(GF(3),GF(2),GF(1));
  GGEOMETRY(4);pGeometry->SetBreakageInertiaTensor(v);
}
DPF(GeometrySetBreakageInertiaTensorA){ // geom,ixyz#()
  GFA(1,gA,3); neV3 v; v.Set(gA[0],gA[1],gA[2]);
  GGEOMETRY(2); pGeometry->SetBreakageInertiaTensor(v);
}
DPF(GeometrySetBreakageBoxInertiaTensor){ //rb,w,h,d,mass
  GGEOMETRY(5); pGeometry->SetBreakageInertiaTensor(neBoxInertiaTensor(GF(4),GF(3),GF(2),GF(1)));
}
DPF(GeometrySetBreakageBoxInertiaTensorA){ //rb,size(),mass
  GFA(2,gA,3); GGEOMETRY(3); pGeometry->SetBreakageInertiaTensor(neBoxInertiaTensor(gA[0],gA[1],gA[3],GF(1)));
}
DPF(GeometrySetBreakageSphereInertiaTensor){ //rb,diameter,mass
  GGEOMETRY(3);
  pGeometry->SetBreakageInertiaTensor(neSphereInertiaTensor(GF(2),GF(1)));
}
DPF(GeometrySetBreakageCylinderInertiaTensor){ //rb,diameter,height,mass
  GGEOMETRY(4);
  pGeometry->SetBreakageInertiaTensor(neCylinderInertiaTensor(GF(3), GF(2), GF(1)));
}

DPF(GeometrySetBreakageMagnitude){
  GGEOMETRY(2);pGeometry->SetBreakageMagnitude(GF(1));
}
DPF(GeometryGetBreakageMagnitude){
  GGEOMETRY(1);SFR(pGeometry->GetBreakageMagnitude());
}
DPF(GeometrySetBreakageAbsorption){
  GGEOMETRY(2);pGeometry->SetBreakageAbsorption(GF(1));
}
DPF(GeometryGetBreakageAbsorption){
  GGEOMETRY(1);SFR(pGeometry->GetBreakageAbsorption());
}
DPF(GeometrySetBreakagePlane){
  GFA(1,gA,3);
  neV3 t;
  t.Set(gA[0],gA[1],gA[2]);
  GGEOMETRY(2);pGeometry->SetBreakagePlane(t);
}
DPF(GeometryGetBreakagePlane){
  neV3 t;
  GGEOMETRY(1);
  t=pGeometry->GetBreakagePlane();
  SFAR(&t[0],3);
}
DPF(GeometrySetBreakageNeighbourRadius){
  GGEOMETRY(2);pGeometry->SetBreakageNeighbourRadius(GF(1));
}
DPF(GeometryGetBreakageNeighbourRadius){
  GGEOMETRY(1);SFR(pGeometry->GetBreakageNeighbourRadius());
}
#endif //NO_BREAKAGE

// geometry transform
DPF(GeometryTransformDirection) {// r#()= geo.m3 * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GGEOMETRY(2); gT3=pGeometry->GetTransform();
  v = gT3.rot * v; SFAR(&v[0],3);
}
DPF(GeometryTransformPoint) {// r#()= geo.t * v#()
  neV3 v; GFA(1,gA,3); v.Set(gA[0],gA[1],gA[2]);
  GGEOMETRY(2); gT3=pGeometry->GetTransform();
  v = gT3 * v; SFAR(&v[0],3);
}




// ############
// # neSensor #
// ############
DPF(SensorSetUserData){ // sens,lpAny
  GSENSOR(2);
  pSensor->SetUserData(GI(1));
}
DPF(SensorGetUserData){
  GSENSOR(1);
  SIR(pSensor->GetUserData());
}
DPF(SensorSetLineSensor){ // sen, px,py,pz, dx,dy,dz
  neV3 p,d;
  float x=GF(3),y=GF(2),z=GF(1);
  if (x==0.0f) x=SENSOR_ZERO;
  if (y==0.0f) y=SENSOR_ZERO;
  if (z==0.0f) z=SENSOR_ZERO;

  d.Set(x,y,z);
  p.Set(GF(6),GF(5),GF(4));
  GSENSOR(7);
  pSensor->SetLineSensor(p,d);
}
DPF(SensorSetLineSensorA){// sen, pos#(), dir#()
  neV3 p,d;
  GFA(1,gA,3);
  if (gA[0]==0.0f) gA[0]=SENSOR_ZERO;
  if (gA[1]==0.0f) gA[1]=SENSOR_ZERO;
  if (gA[2]==0.0f) gA[2]=SENSOR_ZERO;
  d.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);p.Set(gA[0],gA[1],gA[2]);
  GSENSOR(3);
  pSensor->SetLineSensor(p,d);
}
DPF(SensorGetLineVector){ //n#() = Get(sens)
  neV3 n;
  GSENSOR(1);
  n=pSensor->GetLineVector();
  SFAR(&n[0],3);
}
DPF(SensorGetLineUnitVector){ //n#() = Get(sens)
  neV3 n;
  GSENSOR(1);
  n=pSensor->GetLineUnitVector();
  SFAR(&n[0],3);
}
DPF(SensorGetLinePos){ //n#() = Get(sens)
  neV3 n;
  GSENSOR(1);
  n=pSensor->GetLinePos();
  SFAR(&n[0],3);
}
DPF(SensorGetDetectDepth){
  GSENSOR(1);
  SFR(pSensor->GetDetectDepth());
}
DPF(SensorGetDetectNormal){ //n#() = Get(sens)
  neV3 n;
  GSENSOR(1);
  n=pSensor->GetDetectNormal();
  SFAR(&n[0],3);
}
DPF(SensorGetDetectContactPoint){ //p#() = Get(sens)
  neV3 n;
  GSENSOR(1);
  n=pSensor->GetDetectContactPoint();
  SFAR(&n[0],3);
}

DPF(SensorGetDetectRigidBody){ //rb = Get(sens)
  GSENSOR(1);
  pRigidBody=pSensor->GetDetectRigidBody();
  RRIGIDBODY();
}
DPF(SensorGetDetectAnimatedBody){ //ab = Get(sens)
  GSENSOR(1);
  pAnimatedBody=pSensor->GetDetectAnimatedBody();
  RANIMATEDBODY();
}
DPF(SensorGetDetectMaterial){ //id = Get(sens)
  GSENSOR(1);
  SIR(pSensor->GetDetectMaterial());
}


DPF(SensorGetABWorldLinePos){ // pos#() = (sen,ab)
  GSENSOR(2);GANIMATEDBODY(1);
  gT3 = pAnimatedBody->GetTransform();
  gV3 = gT3 * pSensor->GetLinePos();
  SFAR(&gV3[0],3);
}

DPF(SensorGetRBWorldLinePos){ // pos#() = (sen,rb)
  GSENSOR(2);GRIGIDBODY(1);
  gT3 = pRigidBody->GetTransform();
  gV3 = gT3 * pSensor->GetLinePos();
  SFAR(&gV3[0],3);
}


DPF(SensorGetABWorldLineUnitVector){ // nomalized dir#() = (sen,ab)
  GSENSOR(2);GANIMATEDBODY(1);
  gT3 = pAnimatedBody->GetTransform();
  gV3 = gT3.rot * pSensor->GetLineUnitVector();
  SFAR(&gV3[0],3);
}

DPF(SensorGetRBWorldLineUnitVector){ // nomalized dir#() = (sen,rb)
  GSENSOR(2);GRIGIDBODY(1);
  gT3 = pRigidBody->GetTransform();
  gV3 = gT3.rot * pSensor->GetLineUnitVector();
  SFAR(&gV3[0],3);
}

DPF(SensorGetABWorldLineVector){ // dir#() = (sen,ab)
  GSENSOR(2);GANIMATEDBODY(1);
  gT3 = pAnimatedBody->GetTransform();
  gV3 = gT3.rot * pSensor->GetLineVector();
  SFAR(&gV3[0],3);
}

DPF(SensorGetRBWorldLineVector){ // dir#() = (sen,rb)
  GSENSOR(2);GRIGIDBODY(1);
  gT3 = pRigidBody->GetTransform();
  gV3 = gT3.rot * pSensor->GetLineVector();
  SFAR(&gV3[0],3);
}


// ###########
// # neJoint #
// ###########
DPF(JointSetType){
  GJOINT(2);pJoint->SetType((neJoint::ConstraintType)GI(1));
}
DPF(JointGetType){
  GJOINT(1);SIR(pJoint->GetType());
}


DPF(JointSetUserData){ // neJoint,value%
  GJOINT(2);
  gpUD=(UserData *) pJoint->GetUserData();
  gpUD->userData=GI(1);
}
DPF(JointGetUserData){
  GJOINT(1);
  gpUD=(UserData *) pJoint->GetUserData();
  SIR(gpUD->userData);
}


DPF(JointGetRigidBodyA){
  GJOINT(1);pRigidBody=pJoint->GetRigidBodyA();RRIGIDBODY();
}
DPF(JointGetRigidBodyB){
  GJOINT(1);pRigidBody=pJoint->GetRigidBodyB();RRIGIDBODY();
}
DPF(JointGetAnimatedBodyB){
  GJOINT(1);pAnimatedBody=pJoint->GetAnimatedBodyB();RANIMATEDBODY();
}
DPF(JointSetFrameWorld){ // set(jo,px,py,pz , rx,ry,rz)
  gT3.pos.v[0] = GF(6);
  gT3.pos.v[1] = GF(5);
  gT3.pos.v[2] = GF(4);
  gT3.pos.v[3] = 0;
  gT3.rot = RotMatrix(GF(3),GF(2),GF(1));
  GJOINT(7);pJoint->SetJointFrameWorld(gT3);
}
DPF(JointSetFrameWorldA){ // set(jo,pos(),rot())
  GFA(2,gA,3);
  gT3.pos.v[0]=gA[0];
  gT3.pos.v[1]=gA[1];
  gT3.pos.v[2]=gA[2];
  gT3.pos.v[3]=0;
  GFA(1,gA,3);
  gT3.rot = RotMatrixArray(gA);
  GJOINT(3);pJoint->SetJointFrameWorld(gT3);
}

DPF(JointSetFrameWorldAxis){ // jo,pos#(),x#(),y#(),z#()
  float v[3];

  GFA(3,v,3);gT3.rot[0].Set(v[0],v[1],v[2]);
  GFA(2,v,3);gT3.rot[1].Set(v[0],v[1],v[2]);
  GFA(1,v,3);gT3.rot[2].Set(v[0],v[1],v[2]);
  GFA(4,v,3);gT3.pos.Set(v[0],v[1],v[2]);

  GJOINT(5);
  pJoint->SetJointFrameWorld(gT3);
}

DPF(JointSetFrameWorldPos){ // set(jo,px,py,pz)
  gT3.SetIdentity();
  gT3.pos.v[0] = GF(3);
  gT3.pos.v[1] = GF(2);
  gT3.pos.v[2] = GF(1);
  GJOINT(4);pJoint->SetJointFrameWorld(gT3);
}
DPF(JointSetFrameWorldPosA){ // set(jo,pos())
  GFA(1,gA,3);
  gT3.SetIdentity();
  gT3.pos.Set(gA);
  GJOINT(2);
  pJoint->SetJointFrameWorld(gT3);
}

DPF(JointSetFrameA){ // set(jo,px,py,pz , rx,ry,rz)
  GJOINT(7);
  gT3.pos.Set(GF(6),GF(5),GF(4));
  gT3.rot = RotMatrix(GF(3),GF(2),GF(1));
  pJoint->SetJointFrameA(gT3);
}
DPF(JointSetFrameA_A){ // set(jo,pos(),rot())
  GJOINT(3);
  GFA(2,gA,3);
  gT3.pos.Set(gA[0],gA[1],gA[2]);
  GFA(1,gA,3);
  gT3.rot = RotMatrixArray(gA);
  pJoint->SetJointFrameA(gT3);
}
DPF(JointSetFrameB){ // set(jo,px,py,pz , rx,ry,rz)
  GJOINT(7);
  gT3.pos.Set(GF(6),GF(5),GF(4));
  gT3.rot = RotMatrix(GF(3),GF(2),GF(1));
  pJoint->SetJointFrameB(gT3);
}
DPF(JointSetFrameB_A){ // set(jo,pos(),rot())
  GJOINT(3);
  GFA(2,gA,3);
  gT3.pos.Set(gA[0],gA[1],gA[2]);
  GFA(1,gA,3);
  gT3.rot = RotMatrixArray(gA);
  pJoint->SetJointFrameB(gT3);
}

DPF(JointGetFrameA) { // jo,pos(),rot()
  GJOINT(3);
  neV3 p,r;
  p = pJoint->GetJointFrameA().pos;
  SFA(2,&p[0],3);
  r = RotAngle(pJoint->GetJointFrameA().rot);
  SFA(1,&r[0],3);
}
DPF(JointGetFrameAPos) { // pos()=get(jo)
  GJOINT(1);
  neV3 p;
  p = pJoint->GetJointFrameA().pos;          SFAR(&p[0],3);
}
DPF(JointGetFrameARot) { // rot()=get(jo)
  GJOINT(1);
  neV3 r;
  r = RotAngle(pJoint->GetJointFrameA().rot);SFAR(&r[0],3);
}

DPF(JointGetFrameB) { // jo,pos(),rot()
  GJOINT(3);
  neV3 p,r;
  p = pJoint->GetJointFrameB().pos;
  SFA(2,&p[0],3);
  r = RotAngle(pJoint->GetJointFrameB().rot);
  SFA(1,&r[0],3);
}
DPF(JointGetFrameBPos) { // pos()=get(jo)
  GJOINT(1);
  neV3 p;
  p = pJoint->GetJointFrameB().pos;
  SFAR(&p[0],3);
}
DPF(JointGetFrameBRot) { // rot()=get(jo)
  GJOINT(1);
  neV3 r;
  r = RotAngle(pJoint->GetJointFrameB().rot);
  SFAR(&r[0],3);
}
DPF(JointSetLength){
  GJOINT(2);pJoint->SetJointLength(GF(1));
}
DPF(JointGetLength){
  GJOINT(1);SFR(pJoint->GetJointLength());
}
DPF(JointEnable){
  GJOINT(2);pJoint->Enable(GI(1));
}
DPF(JointIsEnable){
  GJOINT(1);SIR(pJoint->Enable());
}

DPF(JointEnableLimit){
  GJOINT(2);pJoint->EnableLimit(GI(1));
}
DPF(JointIsEnableLimit){
  GJOINT(1);SIR(pJoint->EnableLimit());
}
DPF(JointEnableLimit2){
  GJOINT(2);pJoint->EnableLimit2(GI(1));
}
DPF(JointIsEnableLimit2){
  GJOINT(1);SIR(pJoint->EnableLimit2());
}
DPF(JointSetUpperLimit){
  GJOINT(2);pJoint->SetUpperLimit(GF(1));
}
DPF(JointGetUpperLimit){
  GJOINT(1);SFR(pJoint->GetUpperLimit());
}
DPF(JointSetUpperLimit2){
  GJOINT(2);pJoint->SetUpperLimit2(GF(1));
}
DPF(JointGetUpperLimit2){
  GJOINT(1);SFR(pJoint->GetUpperLimit2());
}
DPF(JointSetLowerLimit){
  GJOINT(2);pJoint->SetLowerLimit(GF(1));
}
DPF(JointGetLowerLimit){
  GJOINT(1);SFR(pJoint->GetLowerLimit());
}
DPF(JointSetLowerLimit2){
  GJOINT(2);pJoint->SetLowerLimit2(GF(1));
}
DPF(JointGetLowerLimit2){
  GJOINT(1);SFR(pJoint->GetLowerLimit2());
}

DPF(JointSetEpsilon){
  GJOINT(2);pJoint->SetEpsilon(GF(1));
}
DPF(JointGetEpsilon){
  GJOINT(1);SFR(pJoint->GetEpsilon());
}
DPF(JointSetIteration){
  GJOINT(2);pJoint->SetIteration(GI(1));
}
DPF(JointGetIteration){
  GJOINT(1);SIR(pJoint->GetIteration());
}

DPF(JointSetDampingFactor){
  GJOINT(2);pJoint->SetDampingFactor(GF(1));
}
DPF(JointGetDampingFactor){
  GJOINT(1);SFR(pJoint->GetDampingFactor());
}

DPF(JointAddController) { // joc=AddController(jo,"sub()")
  GJOINT(2);
  gpUD = (UserData *) pJoint->GetUserData();
  gpUD->controllerCode = gpCompiler->Compile(GS(1));
  if (gpUD->controllerCode!=0) {
    pJointController=pJoint->AddController(&JOInstance,0);
	  RJOINTCONTROLLER();
  }
}

DPF(JointAddController2) { // joc=AddController(jo,"sub()",period)
  GJOINT(3);
  gpUD = (UserData *) pJoint->GetUserData();
  gpUD->controllerCode = gpCompiler->Compile(GS(2));
  if (gpUD->controllerCode!=0) {
    pJointController=pJoint->AddController(&JOInstance,GI(1));
	  RJOINTCONTROLLER();
  }
}

DPF(JointRemoveController){
  GJOINT(2);
  GJOINTCONTROLLER(1);
  SIR(pJoint->RemoveController(pJointController));
}
DPF(JointBeginIterateController){
  GJOINT(1);
  pJoint->BeginIterateController();
}
DPF(JointGetNextController){
  GJOINT(1);
  pJointController=pJoint->GetNextController();
  RJOINTCONTROLLER();
}

DPF(JointEnableMotor){
  GJOINT(2);
  pJoint->EnableMotor(GI(1));
}
DPF(JointIsEnableMotor){
  GJOINT(1);
  SIR(pJoint->EnableMotor());
}
DPF(JointSetMotor){ // (JO,Velocity#,Force#)
  GJOINT(3); pJoint->SetMotor(neJoint::NE_MOTOR_SPEED,GF(2),GF(1));
}
DPF(JointGetMotor){ // (JO,&Velocity#,&Force#)
  neJoint::MotorType  t;float a,b;
  GJOINT(3); pJoint->GetMotor(t,a,b);
  SF(2,&a); SF(1,&b);
}

#ifdef USE_MOTOR2
DPF(JointEnableMotor2){
  GJOINT(2);pJoint->EnableMotor2(GI(1));
}
DPF(JointIsEnableMotor2){ // (JO,Velocity#,Force#)
  GJOINT(1);SIR(pJoint->EnableMotor2());
}
DPF(JointSetMotor2){ //(JO,Velocity#,Force#)
  GJOINT(3);
  pJoint->SetMotor2(neJoint::NE_MOTOR_SPEED,GF(2),GF(1));
}
DPF(JointGetMotor2){ //(JO,&Velocity#,&Force#)
  neJoint::MotorType  t;float a,b;
  GJOINT(3);pJoint->GetMotor2(t,a,b);
  SF(2,&a);SF(1,&b);
}
#endif

// #####################
// # neJointController #
// #####################
DPF(GetJointController){
  RJOINTCONTROLLER();
}

DPF(JointControllerGetJoint){
  GJOINTCONTROLLER(1);
  pJoint=pJointController->GetJoint();
  RJOINT();
}
DPF(JointControllerGetForceBodyA){
  neV3 f;
  GJOINTCONTROLLER(1);
  f=pJointController->GetControllerForceBodyA();
  SFAR(&f[0],3);
}
DPF(JointControllerGetForceBodyB){
  neV3 f;
  GJOINTCONTROLLER(1);
  f=pJointController->GetControllerForceBodyB();
  SFAR(&f[0],3);
}
DPF(JointControllerGetTorqueBodyA){
  neV3 t;
  GJOINTCONTROLLER(1);
  t=pJointController->GetControllerTorqueBodyA();
  SFAR(&t[0],3);
}
DPF(JointControllerGetTorqueBodyB){
  neV3 t;
  GJOINTCONTROLLER(1);
  t=pJointController->GetControllerTorqueBodyB();
  SFAR(&t[0],3);
}
DPF(JointControllerSetForceBodyA){
  neV3 f;
  GFA(1,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(2);
  pJointController->SetControllerForceBodyA(f);
}
DPF(JointControllerSetForceBodyB){
  neV3 f;
  GFA(1,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(2);
  pJointController->SetControllerForceBodyB(f);
}
DPF(JointControllerSetTorqueBodyA){
  neV3 t;
  GFA(1,gA,3);t.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(2);
  pJointController->SetControllerTorqueBodyA(t);
}
DPF(JointControllerSetTorqueBodyB){
  neV3 t;
  GFA(1,gA,3);
  t.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(2);
  pJointController->SetControllerTorqueBodyB(t);
}
DPF(JointControllerSetForceWithTorqueBodyA){
  neV3 f,t;
  GFA(1,gA,3);
  t.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(3);
  pJointController->SetControllerForceWithTorqueBodyA(f,t);
}
DPF(JointControllerSetForceWithTorqueBodyB){
  neV3 f,t;
  GFA(1,gA,3);
  t.Set(gA[0],gA[1],gA[2]);
  GFA(2,gA,3);
  f.Set(gA[0],gA[1],gA[2]);
  GJOINTCONTROLLER(3);pJointController->SetControllerForceWithTorqueBodyA(f,t);
}

// ####################
// # neCollisionTable #
// ####################
DPF(CollisionTableSet){
  GCOLLISIONTABLE(3);pCollisionTable->Set(GI(2),GI(1));
}
DPF(CollisionTableSet2){
  GCOLLISIONTABLE(4);pCollisionTable->Set(GI(3),GI(2),(neCollisionTable::neReponseBitFlag)GI(1));
}
DPF(CollisionTableGet){
  GCOLLISIONTABLE(3);SIR(pCollisionTable->Get(GI(2),GI(1)));
}
DPF(CollisionTableGetMaxCollisionID){
  GCOLLISIONTABLE(1);SIR(pCollisionTable->GetMaxCollisionID());
}

// ########
// # misc #
// ########
DPF(ScreenTo3D) { // v3#() = (mxyz#())
  double modelMatrix[16];
  double projMatrix[16];
  int    viewport[4];
  double winx,winy,winz;
  double objx,objy,objz;
  float  ret[3];
  GFA(1,ret,3);
  winx=ret[0];
  winy=ret[1];
  winz=ret[2];
  glGetDoublev (GL_MODELVIEW_MATRIX ,modelMatrix);
  glGetDoublev (GL_PROJECTION_MATRIX,projMatrix);
  glGetIntegerv(GL_VIEWPORT         ,viewport);
  winx *=(double)viewport[2];
  winy *=(double)viewport[3];
  winy  =(double)viewport[3]-winy;

  gluUnProject(winx,winy,winz,
               modelMatrix, projMatrix, viewport,
               &objx, &objy, &objz);
  ret[0]=(float)objx;
  ret[1]=(float)objy;
  ret[2]=(float)objz;
  SFAR(ret,3);
}



///////////////////////////////////////////////////////////////////////////////
//	TokamakPlugin

bool DLLFUNC TokamakPlugin::Load(IDLL_Basic4GL_FunctionRegistry &registry, bool isStandaloneExe) {
    // Initialise DLL stuff
    // Register shared interfaces
    // Register constants
    // Register user defined data types (UDT's)
    // Register runtime functions
  isStandaloneExe=isStandaloneExe;
    // Fetch  interface
    gpCompiler=(IB4GLCompiler*)registry.FetchInterface("IB4GLCompiler",
                                                       IB4GLCOMPILER_MAJOR,
                                                       IB4GLCOMPILER_MINOR);
  // register const's

  // neBodyType
  RIC2(NE_TERRAIN);
  RIC2(NE_RIGID_BODY);
  RIC2(NE_ANIMATED_BODY);

  #define RIC_TRI(n) registry.RegisterIntConstant(#n,neTriangle::n)
  RIC_TRI(NE_TRI_TRIANGLE);
  RIC_TRI(NE_TRI_HEIGHT_MAP);


  /*
  // nePerformanceReport
  #define RIC_PERF(n) registry.RegisterIntConstant(#n,nePerformanceReport::n)
  RIC_PERF(NE_PERF_TOTAL_TIME);
  RIC_PERF(NE_PERF_DYNAMIC);
  RIC_PERF(NE_PERF_POSITION);
  RIC_PERF(NE_PERF_CONTRAIN_SOLVING_1);
  RIC_PERF(NE_PERF_CONTRAIN_SOLVING_2);
  RIC_PERF(NE_PERF_COLLISION_DETECTION);
  RIC_PERF(NE_PERF_COLLISION_CULLING);
  RIC_PERF(NE_PERF_TERRAIN_CULLING);
  RIC_PERF(NE_PERF_TERRAIN);
  RIC_PERF(NE_PERF_CONTROLLER_CALLBACK);
  RIC_PERF(NE_PERF_LAST);

  RIC_PERF(NE_PERF_RUNNING_AVERAGE);
  RIC_PERF(NE_PERF_SAMPLE);
  */

  // neBreakFlag
#ifndef NO_BREAKAGE
  #define RIC_BREAK(n) registry.RegisterIntConstant(#n,neGeometry::n)
  RIC_BREAK(NE_BREAK_DISABLE);
  RIC_BREAK(NE_BREAK_NORMAL);
  RIC_BREAK(NE_BREAK_ALL);
  RIC_BREAK(NE_BREAK_NEIGHBOUR);
  RIC_BREAK(NE_BREAK_NORMAL_PARTICLE);
  RIC_BREAK(NE_BREAK_ALL_PARTICLE);
  RIC_BREAK(NE_BREAK_NEIGHBOUR_PARTICLE);
#endif

  // ConstraintType
  #define RIC_JOINT(n) registry.RegisterIntConstant(#n,neJoint::n)
  RIC_JOINT(NE_JOINT_BALLSOCKET);
  //RIC_JOINT(NE_JOINT_BALLSOCKET2);
  RIC_JOINT(NE_JOINT_HINGE);
  RIC_JOINT(NE_JOINT_SLIDE);

  // MotorType
  //#define RIC_MOTOR(n) registry.RegisterIntConstant(#n,neJoint::n)
  //RIC_MOTOR(NE_MOTOR_SPEED);
  //RIC_MOTOR(NE_MOTOR_POSITION); //not implemented

  // neReponseBitFlag
  #define RIC_RESPONSE(n) registry.RegisterIntConstant(#n,neCollisionTable::n)
  RIC_RESPONSE(RESPONSE_IGNORE);
  RIC_RESPONSE(RESPONSE_IMPULSE);
  RIC_RESPONSE(RESPONSE_CALLBACK);
  RIC_RESPONSE(RESPONSE_IMPULSE_CALLBACK);
  RIC_RESPONSE(NE_COLLISION_TABLE_MAX);

  // neSimulatorSizeInfo
  #define RIC_DEFAULT(n) registry.RegisterIntConstant(#n,neSimulatorSizeInfo::n)
  RIC_DEFAULT(DEFAULT_RIGIDBODIES_COUNT);
  RIC_DEFAULT(DEFAULT_ANIMATEDBODIES_COUNT);
  RIC_DEFAULT(DEFAULT_RIGIDPARTICLES_COUNT);
  RIC_DEFAULT(DEFAULT_CONTROLLERS_COUNT);
  RIC_DEFAULT(DEFAULT_OVERLAPPED_PAIRS_COUNT);
  RIC_DEFAULT(DEFAULT_GEOMETRIES_COUNT);
  RIC_DEFAULT(DEFAULT_CONSTRAINTS_COUNT);
  RIC_DEFAULT(DEFAULT_CONTRAINT_SETS_COUNT);
  RIC_DEFAULT(DEFAULT_SOLVER_BUFFER_SIZE);
  RIC_DEFAULT(DEFAULT_SENSORS_COUNT);
  RIC_DEFAULT(DEFAULT_TERRAIN_NODES_START_COUNT);
  RIC_DEFAULT(DEFAULT_TERRAIN_NODES_GROWBY_COUNT);

  /*
  // LOG_OUTPUT_LEVEL
  #define RIC_LOG(n) registry.RegisterIntConstant(#n,neSimulator::n)
  RIC_LOG(LOG_OUTPUT_LEVEL_NONE);
  RIC_LOG(LOG_OUTPUT_LEVEL_ONE);
  RIC_LOG(LOG_OUTPUT_LEVEL_FULL);
  */

  // register classes
  hSimulatorSizeInfo  = RT(neSimulatorSizeInfo,  0,1); RTIF(THIS);
  hSimulator = RT(neSimulator,          0,1); RTIF(THIS);
  hRigidBody   = RT(neRigidBody,          0,1); RTIF(THIS);
  hAnimatedBody   = RT(neAnimatedBody,       0,1); RTIF(THIS);
  hGeometry = RT(neGeometry,           0,1); RTIF(THIS);
  hSensor = RT(neSensor,             0,1); RTIF(THIS);
  hRigidBodyController  = RT(neRigidBodyController,0,1); RTIF(THIS);
  hJoint   = RT(neJoint,              0,1); RTIF(THIS);
  hJointController  = RT(neJointController,    0,1); RTIF(THIS);
  hCollisionTable = RT(neCollisionTable,     0,1); RTIF(THIS);

  // register struct
  hCollisionInfo = RT(neCollisionInfo,0,1);
  RTIF(TypeA); // neBodyType
  RTIF(TypeB); //   "   "
  RTTF(RigidBodyA,hRigidBody);
  RTTF(RigidBodyB,hRigidBody);
  RTTF(AnimatedBodyA,hAnimatedBody);
  RTTF(AnimatedBodyB,hAnimatedBody);
  RTTF(GeometryA,hGeometry);
  RTTF(GeometryB,hGeometry);
  RTIF(MaterialIdA);
  RTIF(MaterialIdB);
  RTFA1DF(bodyContactPointA ,3); // contact point A in body space of A
  RTFA1DF(bodyContactPointB ,3); // contact point B in body space of B
  RTFA1DF(worldContactPointA,3); // contact point A in world space
  RTFA1DF(worldContactPointB,3); // contact point B in world space
  RTFA1DF(relativeVelocity  ,3);
  RTFA1DF(collisionNormal   ,3);

  hConvexData = RT(ConvexData,0,1);
  RTIF(memory);      // pBytes
  RTIF(size);        // memory nBytes
  RTIF(userdata);    // data%
  RTFF(sx);          // scale x#,y#,z#
  RTFF(sy);
  RTFF(sz);

#ifndef NO_BREAKAGE
  hBreakageInfo = RT(neBreakageInfo,0,1);
  RTIF(BodyType);
  RTTF(OriginalRigidBody,hRigidBody);
  RTTF(OriginalAnimatedBody,hAnimatedBody);
  RTTF(BrokenGeometry,hGeometry);
  RTTF(NewRigidBody,hRigidBody);
#endif



  // ##########
  // # neMath #
  // ##########
  RVF (neSeed)       ;AIP;
  RFF (neRnd)        ;          // r#=()
  RFF2(neRnd,neRnd1) ;AFP;      // r#=(max#)
  RFF2(neRnd,neRnd2) ;AFP;AFP;  // r#=(min#,max#)
  RFF (neAbs)        ;AFP;      // r#=(x#)
  RFF (neSin)        ;AFP;      // r#=(x#)
  RFF (neCos)        ;AFP;      // r#=(x#)
  RFF (neASin)       ;AFP;      // r#=(x#)
  RFF (neACos)       ;AFP;      // r#=(x#)
  RFF (neTan)        ;AFP;      // r#=(x#)
  RFF (neATan)       ;AFP;      // r#=(x#)
  RFF (neATan2)      ;AFP;AFP;  // r#=(x#,y#)
  RIF (neIsEqual)    ;AFP;AFP;  // b%=(a#,b#)
  RFF (neRad)        ;AFP;      // rad#=(deg#)
  RFF (neDeg)        ;AFP;      // deg#=(rad#)
  RFF (nePI);

  // ################
  // # neQuaternion #
  // ################
  RFAF (QuatEuler,1)            ;AFP;AFP;AFP;  // q = (deg_p#,deg_y#,deg_r#)
  RFAF2(QuatEuler,1,QuatEulerA) ;AFAP(1);      // q = (deg_pyr#())

  RFAF (QuatRad,1)              ;AFP;AFP;AFP;  // q = (rad_p#,rad_y#,rad_r#)
  RFAF2(QuatRad,1,QuatRadA)     ;AFAP(1);      // q = (rad_pyr#())

  RFAF(Quat,1)                  ;AFP;AFP;AFP;AFP;     // q   = (x#,y#,z#,w#)
  RFAF(QuatIdentity,1) ;                     // q   = ()
  RFF (QuatX)                   ;AFAP(1);             // x#  = (q)
  RFF (QuatY)                   ;AFAP(1);             // y#  = (q)
  RFF (QuatZ)                   ;AFAP(1);             // z#  = (q)
  RFF (QuatW)                   ;AFAP(1);             // w#  = (q)
  RFF (QuatLength2)             ;AFAP(1);             // l2# = (q)
  RFF (QuatLength)              ;AFAP(1);             // l#  = (q)
  RFAF(QuatNormalize,1)         ;AFAP(1);             // q   = Normlize(q)
  RFAF(QuatAngleAxis,1)         ;AFP;AFAP(1);         // q   = (angle#,axis#())
  RVF (QuatGetAngleAxis)        ;AFAP(1);AFPR;AFAP(1);// (q,&angle#,&axis#())
  RFAF(QuatInverse,1)           ;AFAP(1);             // q   = q
  RFAF(QuatInvert,1)            ;AFAP(1);             // q   = q
  RFAF(QuatConjugate,1)         ;AFAP(1);             // q   = q
  RFAF(QuatQuat,1)              ;AFAP(1);AFAP(1);     // q   = qa*qb
  RFAF(QuatVec,1)               ;AFAP(1);AFAP(1);     // v   = q*v
  RFAF(QuatLerp,1)              ;AFAP(1);AFAP(1);AFP; // q   = qFrom,qTo,t#


  // ##############
  // # neSizeInfo #
  // ##############
  RTF(CreateSimulatorSizeInfo,hSimulatorSizeInfo);

  // set SizeInfo params
  RVF(SetRigidBodiesCount);        ATP(hSimulatorSizeInfo);AIP;
  RVF(SetRigidParticleCount);      ATP(hSimulatorSizeInfo);AIP;
  RVF(SetAnimatedBodiesCount);     ATP(hSimulatorSizeInfo);AIP;
  RVF(SetGeometriesCount);         ATP(hSimulatorSizeInfo);AIP;
  RVF(SetOverlappedPairsCount);    ATP(hSimulatorSizeInfo);AIP;

  RVF(SetConstraintsCount);        ATP(hSimulatorSizeInfo);AIP;
  RVF(SetConstraintSetsCount);     ATP(hSimulatorSizeInfo);AIP;
  RVF(SetConstraintBufferSize);    ATP(hSimulatorSizeInfo);AIP;

  RVF(SetSensorsCount);            ATP(hSimulatorSizeInfo);AIP;
  RVF(SetControllersCount);        ATP(hSimulatorSizeInfo);AIP;
  RVF(SetTerrainNodesStartCount);  ATP(hSimulatorSizeInfo);AIP;
  RVF(SetTerrainNodesGrowByCount); ATP(hSimulatorSizeInfo);AIP;

   // get SizeInfo params
  RIF(GetRigidBodiesCount);        ATP(hSimulatorSizeInfo);
  RIF(GetRigidParticleCount);      ATP(hSimulatorSizeInfo);
  RIF(GetAnimatedBodiesCount);     ATP(hSimulatorSizeInfo);
  RIF(GetGeometriesCount);         ATP(hSimulatorSizeInfo);
  RIF(GetOverlappedPairsCount);    ATP(hSimulatorSizeInfo);

  RIF(GetConstraintsCount);        ATP(hSimulatorSizeInfo);
  RIF(GetConstraintSetsCount)     ;ATP(hSimulatorSizeInfo);
  RIF(GetConstraintBufferSize)    ;ATP(hSimulatorSizeInfo);

  RIF(GetSensorsCount)            ;ATP(hSimulatorSizeInfo);
  RIF(GetControllersCount)        ;ATP(hSimulatorSizeInfo);

  RIF(GetTerrainNodesStartCount);  ATP(hSimulatorSizeInfo);
  RIF(GetTerrainNodesGrowByCount) ;ATP(hSimulatorSizeInfo);

  // ###############
  // # neSimulator #
  // ###############
  RTF (CreateSimulator,hSimulator);                 ATP(hSimulatorSizeInfo);AFP;AFP;AFP; // simu=(SizeInfo,gx#,gy#,gz#)
  RTF2(CreateSimulator,hSimulator,CreateSimulatorA);ATP(hSimulatorSizeInfo);AFAP(1);     // simu=(SizeInfo,gravity#())
  RVF (DestroySimulator);                           ATP(hSimulator);

  RVF (SimulatorAdvance)                        ;ATP(hSimulator);TIMESHARE;
  RVF2(SimulatorAdvance,SimulatorAdvance1)      ;ATP(hSimulator);AFP;TIMESHARE;
  RVF2(SimulatorAdvanceSteps,SimulatorAdvance2) ;ATP(hSimulator);AFP;AIP;TIMESHARE;
  RVF2(SimulatorAdvanceMinMax,SimulatorAdvance3);ATP(hSimulator);AFP;AFP;AFP;TIMESHARE;

  RTF (SimulatorCreateRigidBody,hRigidBody);ATP(hSimulator);
  RVF (SimulatorFreeRigidBody);             ATP(hSimulator);ATP(hRigidBody);

  RTF (SimulatorCreateRigidBodyCube    ,hRigidBody);                                    ATP(hSimulator);AFP;AFP;     // size#, mass#
  RTF2(SimulatorCreateRigidBodyCube    ,hRigidBody,SimulatorCreateRigidBodyCubeMat);    ATP(hSimulator);AFP;AFP;AIP; // size#, mass#, mat%

  RTF (SimulatorCreateRigidBodyBox     ,hRigidBody);                                    ATP(hSimulator);AFP;AFP;AFP;AFP;     // w#,h#,d#, mass#
  RTF2(SimulatorCreateRigidBodyBox     ,hRigidBody,SimulatorCreateRigidBodyBoxMat);     ATP(hSimulator);AFP;AFP;AFP;AFP;AIP; // w#,h#,d#, mass#, mat%

  RTF (SimulatorCreateRigidBodySphere  ,hRigidBody);                                    ATP(hSimulator);AFP;AFP;             // d#, mass#
  RTF2(SimulatorCreateRigidBodySphere  ,hRigidBody,SimulatorCreateRigidBodySphereMat);  ATP(hSimulator);AFP;AFP;AIP;         // d#, mass#, mat%

  RTF (SimulatorCreateRigidBodyCylinder,hRigidBody);                                    ATP(hSimulator);AFP;AFP;AFP;         // d#,h#, mass#
  RTF2(SimulatorCreateRigidBodyCylinder,hRigidBody,SimulatorCreateRigidBodyCylinderMat);ATP(hSimulator);AFP;AFP;AFP;AIP;     // d#,h#, mass#, mat%

  RTF (SimulatorCreateRigidParticle        ,hRigidBody);ATP(hSimulator);

  RTF (SimulatorCreateRigidParticleCube    ,hRigidBody);ATP(hSimulator);AFP;AFP;         // size#, mass#
  RTF (SimulatorCreateRigidParticleBox     ,hRigidBody);ATP(hSimulator);AFP;AFP;AFP;AFP; // w#,h#,d#, mass#
  RTF (SimulatorCreateRigidParticleSphere  ,hRigidBody);ATP(hSimulator);AFP;AFP;         // d#, mass#
  RTF (SimulatorCreateRigidParticleCylinder,hRigidBody);ATP(hSimulator);AFP;AFP;AFP;     // d#,h#, mass#


  RTF (SimulatorCreateAnimatedBody,hAnimatedBody);ATP(hSimulator);
  RVF (SimulatorFreeAnimatedBody);                ATP(hSimulator);ATP(hAnimatedBody);

  RTF (SimulatorCreateAnimatedBodyCube    ,hAnimatedBody);                                   ATP(hSimulator);AFP;     // size#
  RTF2(SimulatorCreateAnimatedBodyCube    ,hAnimatedBody,SimulatorCreateAnimatedBodyCubeMat);ATP(hSimulator);AFP;AIP; // size#, mat%

  RTF (SimulatorCreateAnimatedBodyBox     ,hAnimatedBody);                                  ATP(hSimulator);AFP;AFP;AFP;     // w#,h#,d#
  RTF2(SimulatorCreateAnimatedBodyBox     ,hAnimatedBody,SimulatorCreateAnimatedBodyBoxMat);ATP(hSimulator);AFP;AFP;AFP;AIP; // w#,h#,d#, mat%

  RTF (SimulatorCreateAnimatedBodySphere  ,hAnimatedBody);                                     ATP(hSimulator);AFP;     // d#
  RTF2(SimulatorCreateAnimatedBodySphere  ,hAnimatedBody,SimulatorCreateAnimatedBodySphereMat);ATP(hSimulator);AFP;AIP; // d#, mat%

  RTF (SimulatorCreateAnimatedBodyCylinder,hAnimatedBody);                                       ATP(hSimulator);AFP;AFP;     // d#, h#
  RTF2(SimulatorCreateAnimatedBodyCylinder,hAnimatedBody,SimulatorCreateAnimatedBodyCylinderMat);ATP(hSimulator);AFP;AFP;AIP; // d#, h#, mat%


  RIF(SimulatorSetMaterial);ATP(hSimulator);AIP;AFP;AFP; // simu,index,friction,restitution
  RIF(SimulatorGetMaterial);ATP(hSimulator);AIP;AFPR;AFPR;// simu,index,&friction,&restitution

  RTF (SimulatorCreateJoint,hJoint);ATP(hSimulator);ATP(hRigidBody);
  RTF2(SimulatorCreateJoint,hJoint,SimulatorCreateJointRB);ATP(hSimulator);ATP(hRigidBody);ATP(hRigidBody);
  RTF2(SimulatorCreateJoint,hJoint,SimulatorCreateJointAB);ATP(hSimulator);ATP(hRigidBody);ATP(hAnimatedBody);
  RVF (SimulatorFreeJoint);ATP(hSimulator);ATP(hJoint);

  RVF  (SimulatorSetGravity);                     ATP(hSimulator);AFP;AFP;AFP;
  RVF2 (SimulatorSetGravity,SimulatorSetGravityA);ATP(hSimulator);AFAP(1);
  RFAF2(SimulatorGravity,1,SimulatorGetGravity);  ATP(hSimulator);

  RVF(SimulatorSetCollisionCallback);ATP(hSimulator);ASP;

#ifndef NO_BREAKAGE
  RVF(SimulatorSetBreakageCallback);ATP(hSimulator);ASP;
#endif

  RTF(SimulatorGetCollisionTable,hCollisionTable);ATP(hSimulator);

  RVF(SimulatorSetTerrainMesh);                          ATP(hSimulator);AFAP(1);AIP;AIAP(1);AIP; //v#(),nv,i(),ni%
  RVF2(SimulatorSetTerrainMesh,SimulatorSetTerrainMesh2);ATP(hSimulator);AFAP(2);AIP;AIAP(2);AIP; //v#()(),nv,i()(),ni%
  RVF(SimulatorFreeTerrainMesh);ATP(hSimulator);

  RIF(SimulatorGetMemoryAllocated);ATP(hSimulator); //mem%=(SI)
  RIF(SimulatorGetIdleBodyCount);ATP(hSimulator); //count%=(SI)
#if 0
  void SetTerrainTriangleQueryCallback(neTerrainTriangleQueryCallback * cb);
  neTerrainTriangleQueryCallback * GetTerrainTriangleQueryCallback();

  void SetCustomCDRB2RBCallback(neCustomCDRB2RBCallback * cb);
  neCustomCDRB2RBCallback * GetCustomCDRB2RBCallback();

  void SetCustomCDRB2ABCallback(neCustomCDRB2ABCallback * cb);
  neCustomCDRB2ABCallback * GetCustomCDRB2ABCallback();

#ifndef NO_LOG
  void SetLogOutputCallback(neLogOutputCallback * cb);
  neLogOutputCallback * GetLogOutputCallback();
  void SetLogOutputLevel(LOG_OUTPUT_LEVEL lvl = LOG_OUTPUT_LEVEL_FULL);
#endif


#endif

  // ################
  // # CallBackInfo #
  // ################
  RTF(GetCollisionInfo,hCollisionInfo);
#ifndef NO_BREAKAGE
  RTF(GetBreakageInfo,hBreakageInfo);
#endif

  // ###############
  // # neRigidBody #
  // ###############
  RVF(RigidBodySetMass);ATP(hRigidBody);AFP;
  RFF(RigidBodyGetMass);ATP(hRigidBody);

  RVF (RigidBodySetInertiaTensor)                           ;ATP(hRigidBody);AFP;AFP;AFP;
  RVF2(RigidBodySetInertiaTensor,RigidBodySetInertiaTensorA);ATP(hRigidBody);AFAP(1);

  RVF (RigidBodySetBoxInertiaTensor);                              ATP(hRigidBody);AFP;AFP;AFP;AFP; // width,height,depth,mass
  RVF2(RigidBodySetBoxInertiaTensor,RigidBodySetBoxInertiaTensorA);ATP(hRigidBody);AFAP(1);AFP;     // size(),mass
  RVF (RigidBodySetSphereInertiaTensor);                           ATP(hRigidBody);AFP;AFP;         // diameter,mass);
  RVF (RigidBodySetCylinderInertiaTensor);                         ATP(hRigidBody);AFP;AFP;AFP;     // diameter,height,mass

  RVF (RigidBodySetCollisionID);ATP(hRigidBody);AIP;
  RIF (RigidBodyGetCollisionID);ATP(hRigidBody);

  RVF (RigidBodySetUserData);ATP(hRigidBody);AIP;
  RIF (RigidBodyGetUserData);ATP(hRigidBody);

  RVF (RigidBodySetPos);ATP(hRigidBody);AFP;AFP;AFP;
  RVF2(RigidBodySetPos,RigidBodySetPosA) ;ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyGetPos,1);ATP(hRigidBody);

  RVF (RigidBodySetRotation);                      ATP(hRigidBody);AFP;AFP;AFP;
  RVF2(RigidBodySetRotation,RigidBodySetRotationA);ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyGetRotation,1);                    ATP(hRigidBody);

  RVF (RigidBodySetQuaternion);   ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyGetQuaternion,1); ATP(hRigidBody);

  RFAF(RigidBodyGetOpenGLMatrix,2);     ATP(hRigidBody); //mat#()()=xxx(rb)
  RFAF(RigidBodyGetTransform,2);        ATP(hRigidBody); //mat#()()=xxx(rb)
  RFAF(RigidBodyGetInverseTransform,2); ATP(hRigidBody); //mat#()()=xxx(rb)

  RVF (RigidBodySetForce);                     ATP(hRigidBody);AFAP(1); // rb,f()
  RVF2(RigidBodySetForce,RigidBodySetForcePos);ATP(hRigidBody);AFAP(1);AFAP(1); // rb,f(),p()
  RFAF(RigidBodyGetForce,1);                   ATP(hRigidBody);

  RVF (RigidBodySetTorque);  ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyGetTorque,1);ATP(hRigidBody);

  RVF  (RigidBodySetVelocity);                                      ATP(hRigidBody);AFAP(1);
  RFAF (RigidBodyGetVelocity,1);                                    ATP(hRigidBody);
  RFAF (RigidBodyGetVelocityAtPoint,1);                             ATP(hRigidBody);AFP;AFP;AFP;
  RFAF2(RigidBodyGetVelocityAtPoint,1,RigidBodyGetVelocityAtPointA);ATP(hRigidBody);AFAP(1);
  RFAF (RigidBodyGetAngularVelocity,1);                             ATP(hRigidBody);

  RVF (RigidBodySetAngularMomentum);                             ATP(hRigidBody);AFP;AFP;AFP;
  RVF2(RigidBodySetAngularMomentum,RigidBodySetAngularMomentumA);ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyGetAngularMomentum,1);                           ATP(hRigidBody);

  RVF (RigidBodyApplyImpulse);                         ATP(hRigidBody);AFAP(1);
  RVF2(RigidBodyApplyImpulse,RigidBodyApplyImpulsePos);ATP(hRigidBody);AFAP(1);AFAP(1);
  RVF (RigidBodyApplyTwist);                           ATP(hRigidBody);AFAP(1);

  RVF (RigidBodyGravityEnable);                               ATP(hRigidBody);AIP;
  RIF2(RigidBodyGravityEnable,RigidBodyGravityIsEnable);      ATP(hRigidBody);

  RVF (RigidBodyCollideConnected);                            ATP(hRigidBody);AIP;
  RIF2(RigidBodyCollideConnected,RigidBodyCollideIsConnected);ATP(hRigidBody);
  RVF (RigidBodyCollideDirectlyConnected);                            ATP(hRigidBody);AIP;
  RIF2(RigidBodyCollideConnected,RigidBodyCollideIsDirectlyConnected);ATP(hRigidBody);

  RVF (RigidBodyActive);                                      ATP(hRigidBody);AIP;
  RVF2(RigidBodyActive,RigidBodyActiveHintRB);                ATP(hRigidBody);AIP;ATP(hRigidBody);
  RVF2(RigidBodyActive,RigidBodyActiveHintAB);                ATP(hRigidBody);AIP;ATP(hAnimatedBody);
  RIF2(RigidBodyActive,RigidBodyIsActive);                    ATP(hRigidBody);
  RIF (RigidBodyIsIdle);                                      ATP(hRigidBody);
  RVF (RigidBodySetSleepingParameter);                        ATP(hRigidBody);AFP;
  RFF (RigidBodyGetSleepingParameter);                        ATP(hRigidBody);

  RTF (RigidBodyAddSensor,hSensor);    ATP(hRigidBody);
  RIF (RigidBodyRemoveSensor);        ATP(hRigidBody);ATP(hSensor);
  RVF (RigidBodyBeginIterateSensor);  ATP(hRigidBody);
  RTF (RigidBodyGetNextSensor,hSensor);ATP(hRigidBody);

  RTF (RigidBodyAddController,hRigidBodyController);                        ATP(hRigidBody);ASP;        // rbc=Add(rb,"code")
  RTF2(RigidBodyAddController,hRigidBodyController,RigidBodyAddController2);ATP(hRigidBody);ASP;AIP;    // rbc=Add(rb,"code",period)
  RIF (RigidBodyRemoveController);                           ATP(hRigidBody);ATP(hRigidBodyController); // bool=Remove(rb,rbc)
  RVF (RigidBodyBeginIterateController);                     ATP(hRigidBody);
  RTF (RigidBodyGetNextController,hRigidBodyController);                    ATP(hRigidBody);

  RVF (RigidBodySetAngularDamping);ATP(hRigidBody);AFP;
  RFF (RigidBodyGetAngularDamping);ATP(hRigidBody);

  RVF (RigidBodySetLinearDamping);ATP(hRigidBody);AFP;
  RFF (RigidBodyGetLinearDamping);ATP(hRigidBody);

  RTF (RigidBodyAddGeometry,hGeometry);    ATP(hRigidBody);
  RIF (RigidBodyGetGeometryCount);      ATP(hRigidBody);
  RIF (RigidBodyRemoveGeometry);        ATP(hRigidBody);ATP(hGeometry);
  RVF (RigidBodyBeginIterateGeometry);  ATP(hRigidBody);
  RTF (RigidBodyGetNextGeometry,hGeometry);ATP(hRigidBody);
  RTF (RigidBodyBreakGeometry,hRigidBody);    ATP(hRigidBody);ATP(hGeometry);

  RVF (RigidBodyUpdateBoundingInfo);ATP(hRigidBody);

  RFAF(RigidBodyTransformDirection,1);ATP(hRigidBody);AFAP(1);
  RFAF(RigidBodyTransformPoint,1);ATP(hRigidBody);AFAP(1);


  // #########################
  // # neRigidBodyController #
  // #########################
  RTF (GetRigidBodyController,hRigidBodyController);
  RTF (RigidBodyControllerGetRigidBody,hRigidBody); ATP(hRigidBodyController);
  RFAF(RigidBodyControllerGetForce,1);        ATP(hRigidBodyController);
  RFAF(RigidBodyControllerGetTorque,1);       ATP(hRigidBodyController);
  RVF (RigidBodyControllerSetForce);          ATP(hRigidBodyController);AFAP(1);
  RVF (RigidBodyControllerSetTorque);         ATP(hRigidBodyController);AFAP(1);
  RVF (RigidBodyControllerSetForceWithTorque);ATP(hRigidBodyController);AFAP(1);AFAP(1);

  // ##################
  // # neAnimatedBody #
  // ##################
  RVF (AnimatedBodySetPos)                     ;ATP(hAnimatedBody);AFP;AFP;AFP;
  RVF2(AnimatedBodySetPos,AnimatedBodySetPosA) ;ATP(hAnimatedBody);AFAP(1);
  RFAF(AnimatedBodyGetPos,1)                   ;ATP(hAnimatedBody);

  RVF (AnimatedBodySetRotation)                         ;ATP(hAnimatedBody);AFP;AFP;AFP;
  RVF2(AnimatedBodySetRotation,AnimatedBodySetRotationA);ATP(hAnimatedBody);AFAP(1);
  RFAF(AnimatedBodyGetRotation,1)                       ;ATP(hAnimatedBody);

  RVF (RigidBodySetQuaternion)                          ;ATP(hAnimatedBody);AFAP(1);
  RFAF(RigidBodyGetQuaternion,1)                        ;ATP(hAnimatedBody);

  RFAF(AnimatedBodyGetOpenGLMatrix,2)                   ;ATP(hAnimatedBody);
  RFAF(AnimatedBodyGetTransform,2)                      ;ATP(hAnimatedBody);
  RFAF(AnimatedBodyGetInverseTransform,2)               ;ATP(hAnimatedBody);

  RVF (AnimatedBodySetCollisionID)                      ;ATP(hAnimatedBody);AIP;
  RIF (AnimatedBodyGetCollisionID)                      ;ATP(hAnimatedBody);

  RVF (AnimatedBodySetUserData)                         ;ATP(hAnimatedBody);AIP;
  RIF (AnimatedBodyGetUserData)                         ;ATP(hAnimatedBody);

  RTF (AnimatedBodyAddGeometry,hGeometry)                  ;ATP(hAnimatedBody);
  RVF (AnimatedBodyUpdateBoundingInfo)                  ;ATP(hAnimatedBody);
  RIF (AnimatedBodyGetGeometryCount)                    ;ATP(hAnimatedBody);
  RIF (AnimatedBodyRemoveGeometry)                      ;ATP(hAnimatedBody);ATP(hGeometry);
  RVF (AnimatedBodyBeginIterateGeometry)                ;ATP(hAnimatedBody);
  RTF (AnimatedBodyGetNextGeometry,hGeometry)              ;ATP(hAnimatedBody);

  RVF (AnimatedBodyCollideConnected)                            ;ATP(hAnimatedBody);AIP;
  RIF2(AnimatedBodyCollideConnected,RigidBodyCollideIsConnected);ATP(hAnimatedBody);

  RVF (AnimatedBodyCollideDirectlyConnected)                                    ;ATP(hAnimatedBody);AIP;
  RIF2(AnimatedBodyCollideDirectlyConnected,RigidBodyCollideIsDirectlyConnected);ATP(hAnimatedBody);



  RVF (AnimatedBodyActive)                         ;ATP(hAnimatedBody);AIP;
  RVF2(AnimatedBodyActive,AnimatedBodyActiveHintRB);ATP(hAnimatedBody);AIP;ATP(hRigidBody);
  RVF2(AnimatedBodyActive,AnimatedBodyActiveHintAB);ATP(hAnimatedBody);AIP;ATP(hAnimatedBody);
  RIF2(AnimatedBodyActive,AnimatedBodyIsActive);    ATP(hAnimatedBody);
#ifdef AB_USE_SENSOR
  RTF(AnimatedBodyAddSensor,hSensor);    ATP(hAnimatedBody);
  RIF(AnimatedBodyRemoveSensor);        ATP(hAnimatedBody);ATP(hSensor);
  RVF(AnimatedBodyBeginIterateSensor);  ATP(hAnimatedBody);
  RTF(AnimatedBodyGetNextSensor,hSensor);ATP(hAnimatedBody);
#endif

  RFAF(AnimatedBodyTransformDirection,1);ATP(hAnimatedBody);AFAP(1);
  RFAF(AnimatedBodyTransformPoint,1)    ;ATP(hAnimatedBody);AFAP(1);

  //##############
  //# neGeometry #
  //##############
  RVF (GeometrySetBoxSize);                    ATP(hGeometry);AFP;AFP;AFP; // geom,w,h,d
  RVF2(GeometrySetBoxSize,GeometrySetBoxSizeA);ATP(hGeometry);AFAP(1);
  RIF (GeometryGetBoxSize);                    ATP(hGeometry);AFPR;AFPR;AFPR; // w,h,d
  RIF2(GeometryGetBoxSize,GeometryGetBoxSizeA);ATP(hGeometry);AFAP(1); // size#()

  RVF (GeometrySetSphereDiameter)             ;ATP(hGeometry);AFP; //geom,diameter
  RIF (GeometryGetSphereDiameter)             ;ATP(hGeometry);AFPR; //geom,&diameter

  RVF (GeometrySetCylinderDiameterHeight)     ;ATP(hGeometry);AFP;AFP; //geom,diameter,height
  RIF (GeometryGetCylinderDiameterHeight)     ;ATP(hGeometry);AFPR;AFPR; //geom,&diameter,&height

  RVF (GeometrySetUserData);ATP(hGeometry);AIP;
  RIF (GeometryGetUserData);ATP(hGeometry);

  RVF (GeometrySetMaterialIndex);ATP(hGeometry);AIP;
  RIF (GeometryGetMaterialIndex);ATP(hGeometry);

  RFAF(GeometryGetOpenGLMatrix,2)                 ;ATP(hGeometry); //mat#()()=xxx(geom)
  RFAF(GeometryGetTransform,2)                    ;ATP(hGeometry); //mat#()()=xxx(geom)
  RFAF(GeometryGetInverseTransform,2)             ;ATP(hGeometry); //mat#()()=xxx(geom)
  RVF (GeometrySetTransform)                      ;ATP(hGeometry);AFP;AFP;AFP; AFP;AFP;AFP; //geom,posxyz,rotxyz
  RVF2(GeometrySetTransform,GeometrySetTransformA);ATP(hGeometry);AFAP(1);AFAP(1); //geom,pos(),rot()

#ifndef NO_BREAKAGE
  RVF (GeometrySetBreakageFlag);ATP(hGeometry);AIP;
  RIF (GeometryGetBreakageFlag);ATP(hGeometry);

  RVF (GeometrySetBreakageMass);ATP(hGeometry);AFP;
  RFF (GeometryGetBreakageMass);ATP(hGeometry);

  RVF (GeometrySetBreakageInertiaTensor);ATP(hGeometry);AFAP(1);
  RFAF(GeometryGetBreakageInertiaTensor,1);ATP(hGeometry);
  RVF (GeometrySetBreakageBoxInertiaTensor);ATP(hGeometry);AFP;AFP;AFP;AFP;  // width,height,depth,mass
  RVF2(GeometrySetBreakageBoxInertiaTensor,GeometrySetBreakageBoxInertiaTensorA);ATP(hGeometry);AFAP(1);AFP; // size(),mass
  RVF (GeometrySetBreakageSphereInertiaTensor);ATP(hGeometry);AFP;AFP;       // diameter,mass);
  RVF (GeometrySetBreakageCylinderInertiaTensor);ATP(hGeometry);AFP;AFP;AFP; // diameter,height,mass

  RVF (GeometrySetBreakageMagnitude);ATP(hGeometry);AFP;
  RFF (GeometryGetBreakageMagnitude);ATP(hGeometry);

  RVF (GeometrySetBreakageAbsorption);ATP(hGeometry);AFP;
  RFF (GeometryGetBreakageAbsorption);ATP(hGeometry);

  RVF (GeometrySetBreakagePlane);ATP(hGeometry);AFAP(1); // normale()
  RFAF(GeometryGetBreakagePlane,1);ATP(hGeometry);

  RVF (GeometrySetBreakageNeighbourRadius);ATP(hGeometry);AFP;
  RFF (GeometryGetBreakageNeighbourRadius);ATP(hGeometry);
#endif // NO_BRAKEAGE

#if 0
  void	 SetConvexMesh(neByte * convexData);
  neBool GetConvexMesh(neByte *& convexData);
#endif

  RFAF(GeometryTransformDirection,1);ATP(hGeometry);AFAP(1);
  RFAF(GeometryTransformPoint,1)    ;ATP(hGeometry);AFAP(1);

  RTF (CreateConvexData,hConvexData);AIAP(1);AIP;AFP;AFP;AFP;  // ConvexData = (ints%(),nBytes%),sx#,sy#,sz#)
  RVF (FreeConvexData)              ;ATP(hConvexData);              // (ConvexData)
  RVF (GeometrySetConvexData)       ;ATP(hGeometry);ATP(hConvexData);  // (geo,ConvexData)
  RIF (GeometryGetConvexData)       ;ATP(hGeometry);ATP(hConvexData);  //  boolean%=(geom,&ConvexData)



  // ############
  // # neSensor #
  // ############
  RVF (SensorSetUserData);ATP(hSensor);AIP;
  RIF (SensorGetUserData);ATP(hSensor);

  RVF (SensorSetLineSensor);                     ATP(hSensor);AFP;AFP;AFP; AFP;AFP;AFP; // sens,px#,py#,pz# dx#,dy#,dz#
  RVF2(SensorSetLineSensor,SensorSetLineSensorA);ATP(hSensor);AFAP(1);AFAP(1);          // sens,pos#(),dir#()

  RFAF(SensorGetLineVector,1)        ;ATP(hSensor);
  RFAF(SensorGetLineUnitVector,1)    ;ATP(hSensor);
  RFAF(SensorGetLinePos,1)           ;ATP(hSensor);

  RFF (SensorGetDetectDepth)         ;ATP(hSensor);
  RFAF(SensorGetDetectNormal,1)      ;ATP(hSensor);
  RFAF(SensorGetDetectContactPoint,1);ATP(hSensor);

  RTF (SensorGetDetectRigidBody,hRigidBody)   ;ATP(hSensor);
  RTF (SensorGetDetectAnimatedBody,hAnimatedBody);ATP(hSensor);
  RIF (SensorGetDetectMaterial)         ;ATP(hSensor);

  RFAF2(SensorGetWorldLinePos       ,1,SensorGetABWorldLinePos)       ;ATP(hSensor);ATP(hAnimatedBody);
  RFAF2(SensorGetWorldLineVector    ,1,SensorGetABWorldLineVector)    ;ATP(hSensor);ATP(hAnimatedBody);
  RFAF2(SensorGetWorldLineUnitVector,1,SensorGetABWorldLineUnitVector);ATP(hSensor);ATP(hAnimatedBody);

  RFAF2(SensorGetWorldLinePos       ,1,SensorGetRBWorldLinePos)       ;ATP(hSensor);ATP(hRigidBody);
  RFAF2(SensorGetWorldLineVector    ,1,SensorGetRBWorldLineVector)    ;ATP(hSensor);ATP(hRigidBody);
  RFAF2(SensorGetWorldLineUnitVector,1,SensorGetRBWorldLineUnitVector);ATP(hSensor);ATP(hRigidBody);


  //###########
  //# neJoint #
  //###########
  RVF(JointSetType);ATP(hJoint);AIP;
  RIF(JointGetType);ATP(hJoint);

  RVF(JointSetUserData);ATP(hJoint);AIP;
  RIF(JointGetUserData);ATP(hJoint);

  RTF(JointGetRigidBodyA,hRigidBody);ATP(hJoint);
  RTF(JointGetRigidBodyB,hRigidBody);ATP(hJoint);
  RTF(JointGetAnimatedBodyB,hAnimatedBody);ATP(hJoint);

  RVF(JointSetFrameWorld);ATP(hJoint);AFP;AFP;AFP; AFP;AFP;AFP; //jo,px,py,pz, rx,ry,rz
  RVF2(JointSetFrameWorld,JointSetFrameWorldA);ATP(hJoint);AFAP(1);AFAP(1); //jo,pos#(),rot#()
  RVF(JointSetFrameWorldAxis);ATP(hJoint);AFAP(1);AFAP(1);AFAP(1);AFAP(1); //jo,pos#(),x#(),y#(),z#()

  RVF(JointSetFrameWorldPos);ATP(hJoint);AFP;AFP;AFP; //jo,x y z
  RVF2(JointSetFrameWorldPos,JointSetFrameWorldPosA);ATP(hJoint);AFAP(1); //jo, pos#()

  RVF(JointSetFrameA);ATP(hJoint);AFP;AFP;AFP; AFP;AFP;AFP; //jo,px,py,pz, rx,ry,rz
  RVF2(JointSetFrameA,JointSetFrameA_A);ATP(hJoint);AFAP(1);AFAP(1); //jo,pos(),rot()

  RVF(JointSetFrameB);ATP(hJoint);AFP;AFP;AFP; AFP;AFP;AFP; //jo,px,py,pz, rx,ry,rz
  RVF2(JointSetFrameB,JointSetFrameB_A);ATP(hJoint);AFAP(1);AFAP(1); //jo,pos(),rot()

  RVF(JointGetFrameA);ATP(hJoint);AFAP(1);AFAP(1);
  RFAF(JointGetFrameAPos,1);ATP(hJoint); // pos()=Get
  RFAF(JointGetFrameARot,1);ATP(hJoint); // rot()=Get

  RVF(JointGetFrameB);ATP(hJoint);AFAP(1);AFAP(1);
  RFAF(JointGetFrameBPos,1);ATP(hJoint); // pos()=Get
  RFAF(JointGetFrameBRot,1);ATP(hJoint); // rot()=Get

  RVF(JointSetLength);ATP(hJoint);AFP;
  RFF(JointGetLength);ATP(hJoint);

  RVF(JointEnable);ATP(hJoint);AIP;
  RIF2(JointEnable,JointIsEnable);ATP(hJoint);

  RVF(JointEnableLimit);ATP(hJoint);AIP;
  RIF2(JointEnableLimit,JointIsEnableLimit);ATP(hJoint);

  RVF(JointEnableLimit2);ATP(hJoint);AIP;
  RIF2(JointEnableLimit2,JointIsEnableLimit2);ATP(hJoint);

  RVF(JointSetUpperLimit);ATP(hJoint);AFP;
  RFF(JointGetUpperLimit);ATP(hJoint);

  RVF(JointSetUpperLimit2);ATP(hJoint);AFP;
  RFF(JointGetUpperLimit2);ATP(hJoint);

  RVF(JointSetLowerLimit);ATP(hJoint);AFP;
  RFF(JointGetLowerLimit);ATP(hJoint);

  RVF(JointSetLowerLimit2);ATP(hJoint);AFP;
  RFF(JointGetLowerLimit2);ATP(hJoint);

  RVF(JointSetEpsilon);ATP(hJoint);AFP;
  RFF(JointGetEpsilon);ATP(hJoint);

  RVF(JointSetIteration);ATP(hJoint);AIP;
  RIF(JointGetIteration);ATP(hJoint);

  RVF(JointSetDampingFactor);ATP(hJoint);AFP;
  RFF(JointGetDampingFactor);ATP(hJoint);

  RTF(JointAddController,hJointController);                     ATP(hJoint);ASP;
  RTF2(JointAddController,hJointController,JointAddController2);ATP(hJoint);ASP;AIP;
  RIF(JointRemoveController);ATP(hJoint);              ATP(hJointController);
  RVF(JointBeginIterateController);                  ATP(hJoint);
  RTF(JointGetNextController,hJointController);                 ATP(hJoint);

  RVF (JointEnableMotor);ATP(hJoint);AIP;
  RIF2(JointEnableMotor,JointIsEnableMotor); ATP(hJoint);
  RVF (JointSetMotor);                       ATP(hJoint);AFP;AFP;   // JO,velocity,force
  RVF (JointGetMotor);                       ATP(hJoint);AFPR;AFPR; // JO,&velocity,&force

#ifdef USE_MOTOR2
  RVF (JointEnableMotor2);                    ATP(hJoint);AIP;
  RIF2(JointEnableMotor2,JointIsEnableMotor2);ATP(hJoint);
  RVF (JointSetMotor2);                       ATP(hJoint);AFP;AFP;   // JO,velocity,force
  RVF (JointGetMotor2);                       ATP(hJoint);AFPR;AFPR; // JO,&velocity,&force
#endif

  // #####################
  // # neJointController #
  // #####################
  RTF(GetJointController,hJointController);

  RTF(JointControllerGetJoint,hJoint);ATP(hJointController);

  RFAF(JointControllerGetForceBodyA,1);ATP(hJointController);
  RFAF(JointControllerGetForceBodyB,1);ATP(hJointController);

  RFAF(JointControllerGetTorqueBodyA,1);ATP(hJointController);
  RFAF(JointControllerGetTorqueBodyB,1);ATP(hJointController);

  RVF(JointControllerSetForceBodyA);ATP(hJointController);AFAP(1);
  RVF(JointControllerSetForceBodyB);ATP(hJointController);AFAP(1);

  RVF(JointControllerSetTorqueBodyA);ATP(hJointController);AFAP(1);
  RVF(JointControllerSetTorqueBodyB);ATP(hJointController);AFAP(1);

  RVF(JointControllerSetForceWithTorqueBodyA);ATP(hJointController);AFAP(1);AFAP(1);
  RVF(JointControllerSetForceWithTorqueBodyB);ATP(hJointController);AFAP(1);AFAP(1);

  // ####################
  // # neCollisionTable #
  // ####################
  RVF (CollisionTableSet);ATP(hCollisionTable)       ;AIP;AIP;
  RVF2(CollisionTableSet,CollisionTableSet2);ATP(hCollisionTable);AIP;AIP;AIP;
  RIF (CollisionTableGet)                   ;ATP(hCollisionTable);AIP;AIP;
  RIF (CollisionTableGetMaxCollisionID)     ;ATP(hCollisionTable);

  // ########
  // # misc #
  // ########
  RFAF(ScreenTo3D,1);AFAP(1);

  return true;
}

void DLLFUNC TokamakPlugin::Unload() {
  // DLL is about to unload.
  // Final cleanup code
  FreeUserDataPool();
  if (pSimulator!=NULL) {
    pSimulator->FreeTerrainMesh();
    neSimulator::DestroySimulator(pSimulator);
  }
  // Delete this object. This is safe because Basic4GL will not access it again.
  delete this;
}
bool DLLFUNC TokamakPlugin::Start() {
  // Program is about to start.
  // Any pre-start init code would go here.
  return true;
}
void DLLFUNC TokamakPlugin::End() {
  // Program is about to end
  // Any cleanup code would go here
  FreeUserDataPool();

  if (pSimulator!=NULL) {
    pSimulator->FreeTerrainMesh();
    neSimulator::DestroySimulator(pSimulator);
  }
  pSimulator=NULL;
}
void DLLFUNC TokamakPlugin::Pause() {
  // Called when the program is paused (i.e. during debugging).
  // A full screen window might hide itself here so that the user can see the
  // Basic4GL edit window (and debug their program)
}
void DLLFUNC TokamakPlugin::Resume() {
  // Called when the program is resumed (i.e. during debugging).
  // This is also called when the user "steps"
}
void DLLFUNC TokamakPlugin::DelayedResume() {
  // Called when the program is resumed for more than a short "step".
  // This is where a fullscreen window would re-show itself (if it did so in ::Resume()
  // we would get flickering when the user steps through the program)
}
void DLLFUNC TokamakPlugin::GetError(char *error) {
  if (pluginError != NULL) {
    for (int i = 0; pluginError[i] != 0; i++){
        error[i] = pluginError[i];
    }
  }
}
void DLLFUNC TokamakPlugin::ProcessMessages() {
  // Called periodically (in practice, quite frequently).
  // This would be a good place to process windows messages etc.
}

