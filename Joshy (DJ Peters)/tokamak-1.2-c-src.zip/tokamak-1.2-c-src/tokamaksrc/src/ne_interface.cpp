/*************************************************************************
 *                                                                       *
 * Tokamak Physics Engine, Copyright (C) 2002-2007 David Lam.            *
 * All rights reserved.  Email: david@tokamakphysics.com                 *
 *                       Web: www.tokamakphysics.com                     *
 *                                                                       *
 * This library is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the files    *
 * LICENSE.TXT for more details.                                         *
 *                                                                       *
 *************************************************************************/

#include "math/ne_type.h"
#include "math/ne_debug.h"
#include "tokamak.h"
#include "containers.h"
#include "scenery.h"
#include "collision.h"
#include "constraint.h"
#include "rigidbody.h"


#include "stack.h"
#include "simulator.h"
#include "message.h"

#include "stdio.h"

#define CAST_THIS(a, b) a& b = reinterpret_cast<a&>(*this);


/***********************************************************
*  neSimulator::CreateSimulator -> neFixedTimeStepSimulator *
***********************************************************/
/*******************************
*  neSimulator::CreateSimulator *
*******************************/
neSimulator * neSimulator::CreateSimulator(const neSimulatorSizeInfo & sizeInfo, neAllocatorAbstract * alloc, const neV3 * grav){
  neFixedTimeStepSimulator * s = new neFixedTimeStepSimulator(sizeInfo, alloc, grav);
  return reinterpret_cast<neSimulator*>(s);
}

/****************************************************
*  neSimulator::DestroySimulator(neSimulator * sim); *
****************************************************/
void neSimulator::DestroySimulator(neSimulator * sim){
  if (sim) {
    neFixedTimeStepSimulator * s = reinterpret_cast<neFixedTimeStepSimulator *>(sim);
    delete s;
  }
}

/**************************
*  neSimulator::SetGravity *
***************************/
void neSimulator::SetGravity(const neV3 & g){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.SetGravity(g);
}
/**************************
*  neSimulator::GetGravity *
***************************/
neV3 neSimulator::GetGravity(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.GetGravity();
}

/*******************************
*  neSimulator::CreateRigidBody *
*******************************/
neRigidBody * neSimulator::CreateRigidBody(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * ret = sim.CreateRigidBody();
  return reinterpret_cast<neRigidBody *>(ret);
}

/***********************************
*  neSimulator::CreateRigidParticle *
***********************************/
neRigidBody * neSimulator::CreateRigidParticle(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * ret = sim.CreateRigidBody(true);
  return reinterpret_cast<neRigidBody *>(ret);
}

/**********************************
*  neSimulator::CreateAnimatedBody *
**********************************/
neAnimatedBody * neSimulator::CreateAnimatedBody(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neCollisionBody_ * ret = sim.CreateCollisionBody();
  return reinterpret_cast<neAnimatedBody *>(ret);
}

/************************
*  neSimulator::FreeBody *
************************/
void neSimulator::FreeRigidBody(neRigidBody * body){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Free(reinterpret_cast<neRigidBody_*>(body));
}

/*********************************
*  neSimulator::FreeCollisionBody *
*********************************/
void neSimulator::FreeAnimatedBody(neAnimatedBody * body){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Free(reinterpret_cast<neRigidBody_*>(body));
}
/// Active iteration
/**********************************************
*  neSimulator::BeginIterateActiveAnimatedBody *
***********************************************/
neAnimatedBody * neSimulator::BeginIterateActiveAnimatedBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neCollisionBody_ * cb = sim.activeCB.GetHead();
  return reinterpret_cast<neAnimatedBody*>(cb);
}
/*****************************************
*  neSimulator::GetNextActiveAnimatedBody *
*****************************************/
neAnimatedBody * neSimulator::GetNextActiveAnimatedBody(neAnimatedBody* ab) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!ab) return NULL;
  neCollisionBody_ * cb = reinterpret_cast<neCollisionBody_*>(ab);
  cb = sim.activeCB.GetNext(cb);
  return reinterpret_cast<neAnimatedBody*>(cb);
}

/*******************************************
*  neSimulator::BeginIterateActiveRigidBody *
*******************************************/
neRigidBody * neSimulator::BeginIterateActiveRigidBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * rb_ = sim.activeRB.GetHead();
  return reinterpret_cast<neRigidBody*>(rb_);
}
/**************************************
*  neSimulator::GetNextActiveRigidBody *
**************************************/
neRigidBody * neSimulator::GetNextActiveRigidBody(neRigidBody* rb) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!rb) return NULL;
  neRigidBody_ * rb_ = reinterpret_cast<neRigidBody_*>(rb);
  rb_ = sim.activeRB.GetNext(rb_);
  return reinterpret_cast<neRigidBody*>(rb_);
}

/***************************************************
*  neSimulator::BeginIterateActiveRigidParticleBody *
****************************************************/
neRigidBody * neSimulator::BeginIterateActiveRigidParticleBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * rb_ = sim.activeRP.GetHead();
  return reinterpret_cast<neRigidBody*>(rb_);
}
/**********************************************
*  neSimulator::GetNextActiveRigidParticleBody *
**********************************************/
neRigidBody * neSimulator::GetNextActiveRigidParticleBody(neRigidBody* rb) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!rb) return NULL;
  neRigidBody_ * rb_ = reinterpret_cast<neRigidBody_*>(rb);
  rb_ = sim.activeRB.GetNext(rb_);
  return reinterpret_cast<neRigidBody*>(rb_);
}


/// Inactive iteration
/**********************************************
*  neSimulator::BeginIterateInactiveAnimatedBody *
***********************************************/
neAnimatedBody * neSimulator::BeginIterateInactiveAnimatedBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neCollisionBody_ * cb = sim.inactiveCB.GetHead();
  return reinterpret_cast<neAnimatedBody*>(cb);
}
/*****************************************
*  neSimulator::GetNextInactiveAnimatedBody *
*****************************************/
neAnimatedBody * neSimulator::GetNextInactiveAnimatedBody(neAnimatedBody* ab) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!ab) return NULL;
  neCollisionBody_ * cb = reinterpret_cast<neCollisionBody_*>(ab);
  cb = sim.inactiveCB.GetNext(cb);
  return reinterpret_cast<neAnimatedBody*>(cb);
}

/*******************************************
*  neSimulator::BeginIterateInactiveRigidBody *
*******************************************/
neRigidBody * neSimulator::BeginIterateInactiveRigidBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * rb_ = sim.inactiveRB.GetHead();
  return reinterpret_cast<neRigidBody*>(rb_);
}
/**************************************
*  neSimulator::GetNextInactiveRigidBody *
**************************************/
neRigidBody * neSimulator::GetNextInactiveRigidBody(neRigidBody* rb) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!rb) return NULL;
  neRigidBody_ * rb_ = reinterpret_cast<neRigidBody_*>(rb);
  rb_ = sim.inactiveRB.GetNext(rb_);
  return reinterpret_cast<neRigidBody*>(rb_);
}

/***************************************************
*  neSimulator::BeginIterateInactiveRigidParticleBody *
****************************************************/
neRigidBody * neSimulator::BeginIterateInactiveRigidParticleBody() {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neRigidBody_ * rb_ = sim.inactiveRP.GetHead();
  return reinterpret_cast<neRigidBody*>(rb_);
}
/**********************************************
*  neSimulator::GetNextInactiveRigidParticleBody *
**********************************************/
neRigidBody * neSimulator::GetNextInactiveRigidParticleBody(neRigidBody* rb) {
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!rb) return NULL;
  neRigidBody_ * rb_ = reinterpret_cast<neRigidBody_*>(rb);
  rb_ = sim.inactiveRB.GetNext(rb_);
  return reinterpret_cast<neRigidBody*>(rb_);
}


/*********************************
*  neSimulator::GetCollisionTable *
*********************************/
neCollisionTable * neSimulator::GetCollisionTable(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return (neCollisionTable *)(&sim.colTable);
}

/***************************
*  neSimulator::SetMaterial *
***************************/
bool neSimulator::SetMaterial(s32 index, f32 friction, f32 restitution){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.SetMaterial(index, friction, restitution, 0.0f);
}

/***************************
*  neSimulator::GetMaterial *
***************************/
bool neSimulator::GetMaterial(s32 index, f32& friction, f32& restitution){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  f32 density;
  return sim.GetMaterial(index, friction, restitution, density);
}

/***********************
* neSimulator::Advance *
***********************/
#ifndef NO_PERFORMANCE
void neSimulator::Advance(f32 sec, s32 step, nePerformanceReport * perfReport){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Advance(sec, step, perfReport);
}
void neSimulator::Advance(f32 sec, f32 minTimeStep, f32 maxTimeStep, nePerformanceReport * perfReport){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Advance(sec, minTimeStep, maxTimeStep, perfReport);
}
#else
void neSimulator::Advance(f32 sec, s32 step){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Advance(sec, step);
}
void neSimulator::Advance(f32 sec, f32 minTimeStep, f32 maxTimeStep){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.Advance(sec, minTimeStep, maxTimeStep);
}
#endif
/******************************
*  neSimulator::SetTerrainMesh *
******************************/
void neSimulator::SetTerrainMesh(neTriangleMesh * tris){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.SetTerrainMesh(tris);
}

void neSimulator::FreeTerrainMesh(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.FreeTerrainMesh();
}

/****************************
*   neSimulator::CreateJoint *
****************************/
neJoint * neSimulator::CreateJoint(neRigidBody * bodyA){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!bodyA){
    return NULL;
  }
  _neConstraint * constr = sim.constraintHeap.Alloc(1); // 1 means make it solo
  if (!constr){
    if (sim.logLevel >= neSimulator::LOG_OUTPUT_LEVEL_ONE)  {
      sprintf(sim.logBuffer,  MSG_CONSTRAINT_FULL);
      sim.LogOutput(neSimulator::LOG_OUTPUT_LEVEL_ONE);
    }
    return NULL;
  }
  constr->Reset();
  constr->sim = &sim;
  constr->bodyA = (neRigidBody_*)bodyA;
  neRigidBody_ * ba = (neRigidBody_*)bodyA;
  ba->constraintCollection.Add(&constr->bodyAHandle);
  return reinterpret_cast<neJoint*>(constr);
}

/***************************
* neSimulator::CreateJoint *
***************************/
neJoint * neSimulator::CreateJoint(neRigidBody * bodyA, neRigidBody * bodyB){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!bodyA){
    return NULL;
  }
  if (!bodyB){
    return NULL;
  }
  _neConstraint * constr = sim.constraintHeap.Alloc(1); // 1 means make it solo
  if (!constr){
    if (sim.logLevel >= neSimulator::LOG_OUTPUT_LEVEL_ONE)  {
      sprintf(sim.logBuffer,  MSG_CONSTRAINT_FULL);
      sim.LogOutput(neSimulator::LOG_OUTPUT_LEVEL_ONE);
    }
    return NULL;
  }

  constr->Reset();
  constr->sim = &sim;

  constr->bodyA = (neRigidBody_*)bodyA;
  neRigidBody_ * ba = (neRigidBody_*)bodyA;
  ba->constraintCollection.Add(&constr->bodyAHandle);

  constr->bodyB = (neRigidBodyBase*)bodyB;
  neRigidBody_ * bb = (neRigidBody_*)bodyB;
  bb->constraintCollection.Add(&constr->bodyBHandle);
  return reinterpret_cast<neJoint*>(constr);
}

/***************************
* neSimulator::CreateJoint *
****************************/
neJoint * neSimulator::CreateJoint(neRigidBody * bodyA, neAnimatedBody * bodyB){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  if (!bodyA){
    return NULL;
  }
  if (!bodyB){
    return NULL;
  }
  _neConstraint * constr = sim.constraintHeap.Alloc(1); // 1 means make it solo
  if (!constr){
    if (sim.logLevel >= neSimulator::LOG_OUTPUT_LEVEL_ONE)  {
      sprintf(sim.logBuffer,  MSG_CONSTRAINT_FULL);
      sim.LogOutput(neSimulator::LOG_OUTPUT_LEVEL_ONE);
    }
    return NULL;
  }

  constr->Reset();
  constr->sim = &sim;

  constr->bodyA = (neRigidBody_*)bodyA;
  neRigidBody_ * ba = (neRigidBody_*)bodyA;
  ba->constraintCollection.Add(&constr->bodyAHandle);

  constr->bodyB = (neRigidBodyBase*)bodyB;
  neRigidBodyBase * bb = (neRigidBodyBase*)bodyB;
  bb->constraintCollection.Add(&constr->bodyBHandle);

  return reinterpret_cast<neJoint*>(constr);
}

/*************************
* neSimulator::FreeJoint *
*************************/
void neSimulator::FreeJoint(neJoint * constraint){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  _neConstraint * c = (_neConstraint *)constraint;
  ASSERT(sim.constraintHeap.CheckBelongAndInUse(c));
  if (c->bodyA)  {
    c->bodyA->constraintCollection.Remove(&c->bodyAHandle);
    if (c->bodyB){
      c->bodyB->constraintCollection.Remove(&c->bodyBHandle);
    }
    neConstraintHeader * h = c->bodyA->GetConstraintHeader();
    if (h){
      h->Remove(c);
      h->flag = neConstraintHeader::FLAG_NEED_REORG;
    }
    sim.constraintHeap.Dealloc(c, 1);

    if (c->bodyA->constraintCollection.count == 0){
      c->bodyA->RemoveConstraintHeader();
    }

    if (c->bodyB &&  c->bodyB->constraintCollection.count == 0){
      c->bodyB->RemoveConstraintHeader();
    }
  }
  else
  {
    sim.constraintHeap.Dealloc(c, 1);
  }
}

/************************************
* neSimulator::SetCollisionCallback *
************************************/
void neSimulator::SetCollisionCallback(neCollisionCallback * fn){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.SetCollisionCallback(fn);
}
/************************************
* neSimulator::GetCollisionCallback *
************************************/
neCollisionCallback * neSimulator::GetCollisionCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.collisionCallback;
}

/***********************************
*  neSimulator::SetBreakageCallback *
***********************************/
void neSimulator::SetBreakageCallback(neBreakageCallback * cb){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.breakageCallback = cb;
}
/***********************************
*  neSimulator::GetBreakageCallback *
***********************************/
neBreakageCallback * neSimulator::GetBreakageCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.breakageCallback;
}

/***********************************************
*  neSimulator::SetTerrainTriangleQueryCallback *
***********************************************/
void neSimulator::SetTerrainTriangleQueryCallback(neTerrainTriangleQueryCallback * cb){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.terrainQueryCallback = cb;
}

/***********************************************
*  neSimulator::GetTerrainTriangleQueryCallback *
***********************************************/
neTerrainTriangleQueryCallback * neSimulator::GetTerrainTriangleQueryCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.terrainQueryCallback;
}

/****************************************
*  neSimulator::SetCustomCDRB2RBCallback *
****************************************/
void neSimulator::SetCustomCDRB2RBCallback(neCustomCDRB2RBCallback * cb){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.customCDRB2RBCallback = cb;
}
/****************************************
*  neSimulator::GetCustomCDRB2RBCallback *
****************************************/
neCustomCDRB2RBCallback * neSimulator::GetCustomCDRB2RBCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.customCDRB2RBCallback;
}

/****************************************
*  neSimulator::SetCustomCDRB2ABCallback *
****************************************/
void neSimulator::SetCustomCDRB2ABCallback(neCustomCDRB2ABCallback * cb){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.customCDRB2ABCallback = cb;
}
/****************************************
*  neSimulator::GetCustomCDRB2ABCallback *
****************************************/
neCustomCDRB2ABCallback * neSimulator::GetCustomCDRB2ABCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.customCDRB2ABCallback;
}

/************************************
*  neSimulator::SetLogOutputCallback *
************************************/
void neSimulator::SetLogOutputCallback(neLogOutputCallback * fn){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.SetLogOutputCallback(fn);
}
/************************************
*  neSimulator::GetLogOutputCallback *
************************************/
neLogOutputCallback * neSimulator::GetLogOutputCallback(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.logCallback;
}

/*********************************
*  neSimulator::SetLogOutputLevel *
*********************************/
void neSimulator::SetLogOutputLevel(neSimulator::LOG_OUTPUT_LEVEL lvl){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.SetLogOutputLevel(lvl);
}
/*********************************
*  neSimulator::GetLogOutputLevel *
*********************************/
neSimulator::LOG_OUTPUT_LEVEL neSimulator::GetLogOutputLevel(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.GetLogOutputLevel();
}

/**********************************
*  neSimulator::GetCurrentSizeInfo *
**********************************/
neSimulatorSizeInfo neSimulator::GetCurrentSizeInfo(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  neSimulatorSizeInfo ret;
  ret.rigidBodiesCount = sim.rigidBodyHeap.GetUsedCount();
  ret.animatedBodiesCount = sim.collisionBodyHeap.GetUsedCount();
  ret.rigidParticleCount = sim.rigidParticleHeap.GetUsedCount();
  ret.controllersCount = sim.controllerHeap.GetUsedCount();
  ret.overlappedPairsCount = sim.region.overlappedPairs.GetUsedCount();
  ret.geometriesCount = sim.geometryHeap.GetUsedCount();
  ret.constraintsCount = sim.constraintHeap.GetUsedCount();
  ret.constraintSetsCount = sim.constraintHeaders.GetUsedCount();
  ret.sensorsCount = sim.sensorHeap.GetUsedCount();
  ret.terrainNodesStartCount = sim.region.terrainTree.nodes.GetUsedCount();
  ret.terrainNodesGrowByCount = sim.sizeInfo.terrainNodesGrowByCount;
  return ret;
}
/********************************
*  neSimulator::GetStartSizeInfo *
********************************/
neSimulatorSizeInfo neSimulator::GetStartSizeInfo(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.sizeInfo;
}
/**********************************
*  neSimulator::GetMemoryAllocated *
***********************************/
void neSimulator::GetMemoryAllocated(s32 & memoryAllocated){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  sim.GetMemoryAllocated(memoryAllocated);
}
/********************************
*  neSimulator::GetIdleBodyCount *
********************************/
s32 neSimulator::GetIdleBodyCount(){
  CAST_THIS(neFixedTimeStepSimulator, sim);
  return sim.idleBodyCount;
}

/*************************************
* neJoint interface -> _neConstraint *
*************************************/
/*******************
*  neJoint::SetType *
*******************/
void neJoint::SetType(ConstraintType t){
  CAST_THIS(_neConstraint, c);
  c.SetType(t);
}
/*******************
* neJoint::GetType *
*******************/
neJoint::ConstraintType neJoint::GetType(){
  CAST_THIS(_neConstraint, c);
  return c.type;
}

/***********************
* neJoint::SetUserData *
***********************/
void neJoint::SetUserData(void* userData){
  CAST_THIS(_neConstraint, c);
  c.userData = userData;
}
/***********************
* neJoint::GetUserData *
***********************/
void* neJoint::GetUserData(){
  CAST_THIS(_neConstraint, c);
  return c.userData;
}

/*************************
* neJoint::GetRigidBodyA *
*************************/
neRigidBody * neJoint::GetRigidBodyA(){
  CAST_THIS(_neConstraint, c);
  return reinterpret_cast<neRigidBody *>(c.bodyA);
}
/*************************
* neJoint::GetRigidBodyB *
*************************/
neRigidBody * neJoint::GetRigidBodyB(){
  CAST_THIS(_neConstraint, c);
  if (!c.bodyB){
    return NULL;
  }
  if (c.bodyB->AsCollisionBody()){
    return NULL;
  }
  return reinterpret_cast<neRigidBody *>(c.bodyB);
}

/****************************
* neJoint::GetAnimatedBodyB *
****************************/
neAnimatedBody * neJoint::GetAnimatedBodyB(){
  CAST_THIS(_neConstraint, c);
  if (!c.bodyB){
    return NULL;
  }
  if (c.bodyB->AsRigidBody()){
    return NULL;
  }
  return reinterpret_cast<neAnimatedBody *>(c.bodyB);
}
/******************************
* neJoint::SetJointFrameWorld *
******************************/
void neJoint::SetJointFrameWorld(const neT3 & frame){
  CAST_THIS(_neConstraint, c);
  neT3 worldTobody;
  worldTobody = c.bodyA->GetB2W().FastInverse();
  c.frameA = worldTobody * frame;
  if (!c.bodyB)  {
    c.frameB = frame;
    return;
  }
  worldTobody = c.bodyB->GetB2W().FastInverse();
  c.frameB = worldTobody * frame;
}


/**************************
* neJoint::SetJointFrameA *
**************************/
void neJoint::SetJointFrameA(const neT3 & frameA){
  CAST_THIS(_neConstraint, c);
  c.frameA = frameA;
}
/**************************
* neJoint::GetJointFrameA *
**************************/
neT3 neJoint::GetJointFrameA(){
  neT3 ret;
  CAST_THIS(_neConstraint, c);
  if (!c.bodyA)  {
    return c.frameA;
  }
  ret = c.bodyA->State().b2w * c.frameA;
  return ret;
}

/**************************
* neJoint::SetJointFrameB *
**************************/
void neJoint::SetJointFrameB(const neT3 & frameB){
  CAST_THIS(_neConstraint, c);
  c.frameB = frameB;
}
/**************************
* neJoint::GetJointFrameB *
**************************/
neT3 neJoint::GetJointFrameB(){
  neT3 ret;
  CAST_THIS(_neConstraint, c);
  if (!c.bodyB){
    return c.frameB;
  }

  neCollisionBody_ * cb = c.bodyB->AsCollisionBody();
  if (cb){
    ret = cb->b2w * c.frameB;
  }
  else
  {
    neRigidBody_ * rb = c.bodyB->AsRigidBody();
    ret = rb->State().b2w * c.frameB;
  }
  return ret;
}

/**************************
* neJoint::SetJointLength *
**************************/
void neJoint::SetJointLength(f32 length){
  CAST_THIS(_neConstraint, c);
  c.jointLength = length;
}
/**************************
* neJoint::GetJointLength *
**************************/
f32 neJoint::GetJointLength(){
  CAST_THIS(_neConstraint, c);
  return c.jointLength;
}
/******************
* neJoint::Enable *
******************/
void neJoint::Enable(neBool yes){
  CAST_THIS(_neConstraint, c);
  c.Enable(yes);
}
/********************
* neJoint::IsEnable *
********************/
neBool neJoint::IsEnabled(){
  CAST_THIS(_neConstraint, c);
  return c.enable;
}
/****************************
* neJoint::SetDampingFactor *
****************************/
void neJoint::SetDampingFactor(f32 damp){
  CAST_THIS(_neConstraint, c);
  c.jointDampingFactor = damp;
}
/****************************
* neJoint::GetDampingFactor *
****************************/
f32 neJoint::GetDampingFactor(){
  CAST_THIS(_neConstraint, c);
  return c.jointDampingFactor;
}
/**********************
* neJoint::SetEpsilon *
**********************/
void neJoint::SetEpsilon(f32 t){
  CAST_THIS(_neConstraint, c);
  c.accuracy = t;
}
/**********************
* neJoint::GetEpsilon *
**********************/
f32 neJoint::GetEpsilon(){
  CAST_THIS(_neConstraint, c);
  if (c.accuracy <= 0.0f){
    return DEFAULT_CONSTRAINT_EPSILON;
  }
  return c.accuracy;
}
/************************
* neJoint::SetIteration *
************************/
void neJoint::SetIteration(s32 i){
  CAST_THIS(_neConstraint, c);
  c.iteration = i;
}
/************************
* neJoint::GetIteration *
************************/
s32 neJoint::GetIteration(){
  CAST_THIS(_neConstraint, c);
  return c.iteration;
}
/*************************
* neJoint::GetUpperLimit *
*************************/
f32 neJoint::GetUpperLimit(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[0].upperLimit;
}
/*************************
* neJoint::SetUpperLimit *
*************************/
void neJoint::SetUpperLimit(f32 upperLimit){
  CAST_THIS(_neConstraint, c);
  c.limitStates[0].upperLimit = upperLimit;
}
/*************************
* neJoint::GetLowerLimit *
*************************/
f32 neJoint::GetLowerLimit(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[0].lowerLimit;
}
/*************************
* neJoint::SetLowerLimit *
*************************/
void neJoint::SetLowerLimit(f32 lowerLimit){
  CAST_THIS(_neConstraint, c);
  c.limitStates[0].lowerLimit = lowerLimit;
}

/***********************
* neJoint::EnableLimit *
***********************/
void neJoint::EnableLimit(neBool yes){
  CAST_THIS(_neConstraint, c);
  c.limitStates[0].enableLimit = yes;
}
/*************************
* neJoint::IsEnableLimit *
*************************/
neBool neJoint::EnableLimit(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[0].enableLimit;
}

/**************************
* neJoint::SetUpperLimit2 *
**************************/
void neJoint::SetUpperLimit2(f32 upperLimit){
  CAST_THIS(_neConstraint, c);
  c.limitStates[1].upperLimit = upperLimit;
}
/**************************
* neJoint::GetUpperLimit2 *
**************************/
f32 neJoint::GetUpperLimit2(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[1].upperLimit;
}

/**************************
* neJoint::SetLowerLimit2 *
**************************/
void neJoint::SetLowerLimit2(f32 lowerLimit){
  CAST_THIS(_neConstraint, c);
  c.limitStates[1].lowerLimit = lowerLimit;
}
/**************************
* neJoint::GetLowerLimit2 *
**************************/
f32 neJoint::GetLowerLimit2(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[1].lowerLimit;
}
/************************
* neJoint::EnableLimit2 *
************************/
void neJoint::EnableLimit2(neBool yes){
  CAST_THIS(_neConstraint, c);
  c.limitStates[1].enableLimit = yes;
}
/************************
* neJoint::EnableLimit2 *
************************/
neBool neJoint::EnableLimit2(){
  CAST_THIS(_neConstraint, c);
  return c.limitStates[1].enableLimit;
}

/***********************
* neJoint::EnableMotor *
***********************/
void neJoint::EnableMotor(neBool yes){
  CAST_THIS(_neConstraint, c);
  c.motor.enable = yes;
}
/***********************
* neJoint::EnableMotor *
***********************/
neBool neJoint::EnableMotor(){
  CAST_THIS(_neConstraint, c);
  return c.motor.enable;
}
/********************
* neJoint::SetMotor *
********************/
void neJoint::SetMotor(f32 desireValue, f32 maxForce){
  CAST_THIS(_neConstraint, c);
  c.motor.desireVelocity = desireValue;
  c.motor.maxForce       = neAbs(maxForce);
}
/********************
* neJoint::GetMotor *
********************/
void neJoint::GetMotor(f32 & desireValue, f32 & maxForce){
  CAST_THIS(_neConstraint, c);
  desireValue = c.motor.desireVelocity;
  maxForce = c.motor.maxForce;
}

/*************************
* neJoint::AddController *
*************************/
neJointController * neJoint::AddController(JointControllerCallback * jccb, s32 period){
  CAST_THIS(_neConstraint, c);
  /// return (neJointController *)c.AddController(jccb, period);
  /// !!!! cast
  return reinterpret_cast<neJointController *>(c.AddController(jccb, period));
}
/****************************
* neJoint::RemoveController *
****************************/
neBool neJoint::RemoveController(neJointController * jController){
  CAST_THIS(_neConstraint, c);

  if (!c.controllers){
    return false;
  }
  neControllerItem * ci = (neControllerItem *)c.controllers;
  while (ci){
    neController * con = reinterpret_cast<neController *>(ci);
    ci = ci->next;
    if (con == reinterpret_cast<neController *>(jController))  {
      c.sim->controllerHeap.Dealloc(con, 1);
      return true;
    }
  }
  return false;
}
/**********************************
* neJoint::BeginIterateController *
**********************************/
void neJoint::BeginIterateController(){
  CAST_THIS(_neConstraint, c);
  c.BeginIterateController();
}
/*****************************
* neJoint::GetNextController *
*****************************/
neJointController * neJoint::GetNextController(){
  CAST_THIS(_neConstraint, c);
  /// return (neJointController *)c.GetNextController();
  /// !!!! cast
  return reinterpret_cast<neJointController *>(c.GetNextController());
}

/**********************************************
* interface neJointController -> neController *
**********************************************/
/******************************
* neJointController::GetJoint *
******************************/
neJoint * neJointController::GetJoint(){
  CAST_THIS(neController, c);
  /// return (neJoint *)c.constraint;
  /// !!!! cast
  return reinterpret_cast<neJoint *>(c.constraint);
}
/*************************************************
* neJointController::::SetControllerForceBodyAV3 *
*************************************************/
void neJointController::SetControllerForceBodyAV3(const neV3 & force){
  CAST_THIS(neController, c);
  c.forceA = force;
}
/***********************************************
* neJointController::GetControllerForceBodyAV3 *
***********************************************/
neV3 neJointController::GetControllerForceBodyAV3(){
  CAST_THIS(neController, c);
  return c.forceA;
}
/***********************************************
* neJointController::SetControllerForceBodyBV3 *
***********************************************/
void neJointController::SetControllerForceBodyBV3(const neV3 & force){
  CAST_THIS(neController, c);
  c.forceB = force;
}
/*************************************************
* neJointController::::GetControllerForceBodyBV3 *
*************************************************/
neV3 neJointController::GetControllerForceBodyBV3(){
  CAST_THIS(neController, c);
  return c.forceB;
}
/**************************************************
* neJointController::::SetControllerTorqueBodyAV3 *
**************************************************/
void neJointController::SetControllerTorqueBodyAV3(const neV3 & torque){
  CAST_THIS(neController, c);
  c.torqueA = torque;
}
/************************************************
* neJointController::GetControllerTorqueBodyAV3 *
************************************************/
neV3 neJointController::GetControllerTorqueBodyAV3(){
  CAST_THIS(neController, c);
  return c.torqueA;
}
/************************************************
* neJointController::SetControllerTorqueBodyBV3 *
************************************************/
void neJointController::SetControllerTorqueBodyBV3(const neV3 & torque){
  CAST_THIS(neController, c);
  c.torqueB = torque;
}
/************************************************
*  neJointController::GetControllerTorqueBodyBV3 *
************************************************/
neV3 neJointController::GetControllerTorqueBodyBV3(){
  CAST_THIS(neController, c);
  return c.torqueB;
}
/***********************************************************
*  neJointController::::SetControllerForceWithTorqueBodyAV3 *
***********************************************************/
void neJointController::SetControllerForceWithTorqueBodyAV3(const neV3 & force, const neV3 & pos){
  CAST_THIS(neController, c);
  c.forceA = force;
  c.torqueA = ((pos - c.constraint->bodyA->GetPos()).Cross(force));
}
/**********************************************************
*  neJointController:: SetControllerForceWithTorqueBodyBV3 *
**********************************************************/
void neJointController::SetControllerForceWithTorqueBodyBV3(const neV3 & force, const neV3 & pos){
  CAST_THIS(neController, c);
  c.forceB = force;

  if (c.constraint->bodyB && !c.constraint->bodyB->AsCollisionBody())  {
    neRigidBody_ * rb = (neRigidBody_*)c.constraint->bodyB;
    c.torqueB = ((pos - rb->GetPos()).Cross(force));
  }
}


/*********************
*  interface neSensor *
*********************/
/************************
*  neSensor::SetUserData *
************************/
void neSensor::SetUserData(void* userData){
  CAST_THIS(neSensor_, sensor);
  sensor.userData = userData;
}
/************************
*  neSensor::GetUserData *
************************/
void* neSensor::GetUserData(){
  CAST_THIS(neSensor_, sensor);
  return sensor.userData;
}
/**************************
*  neSensor::SetLineSensor *
**************************/
void neSensor::SetLineSensor(const neV3 & p, const neV3 & d){
  CAST_THIS(neSensor_, sensor);
  sensor.pos = p;
  sensor.dir = d;
  sensor.dirNormal = d;
  sensor.dirNormal.Normalize();
  sensor.length = sensor.dir.Length();
}
/**************************
*  neSensor::GetLineNormal *
**************************/
neV3 neSensor::GetLineVector(){
  CAST_THIS(neSensor_, sensor);
  return sensor.dir;
}
/**************************
*  neSensor::GetLineNormal *
**************************/
neV3 neSensor::GetLineUnitVector(){
  CAST_THIS(neSensor_, sensor);
  return sensor.dirNormal ;
}
/***********************
*  neSensor::GetLinePos *
***********************/
neV3 neSensor::GetLinePos(){
  CAST_THIS(neSensor_, sensor);
  return sensor.pos;
}
/***************************
*  neSensor::GetDetectDepth *
***************************/
f32  neSensor::GetDetectDepth(){
  CAST_THIS(neSensor_, sensor);
  return sensor.depth;
}
/****************************
*  neSensor::GetDetectNormal *
****************************/
neV3 neSensor::GetDetectNormal(){
  CAST_THIS(neSensor_, sensor);
  return sensor.normal;
}
/**********************************
*  neSensor::GetDetectContactPoint *
**********************************/
neV3 neSensor::GetDetectContactPoint(){
  CAST_THIS(neSensor_, sensor);
  return sensor.contactPoint;
}
/*******************************
*  neSensor::GetDetectRigidBody *
*******************************/
neRigidBody * neSensor::GetDetectRigidBody(){
  CAST_THIS(neSensor_, sensor);
  if (!sensor.body){
    return NULL;
  }
  if (sensor.body->AsCollisionBody()){
    return NULL;
  }
  return (neRigidBody *)sensor.body;
}
/**********************************
*  neSensor::GetDetectAnimatedBody *
**********************************/
neAnimatedBody * neSensor::GetDetectAnimatedBody(){
  CAST_THIS(neSensor_, sensor);
  if (!sensor.body){
    return NULL;
  }
  if (sensor.body->AsRigidBody()){
    return NULL;
  }
  return (neAnimatedBody *)sensor.body;
}
/******************************
*  neSensor::GetDetectMaterial *
******************************/
s32  neSensor::GetDetectMaterial(){
  CAST_THIS(neSensor_, sensor);
  return sensor.materialID;
}



/**************************************************
*  interface neCollisionTable -> neCollisionTable_ *
**************************************************/
/************************
*  neCollisionTable::Set *
************************/
void neCollisionTable::Set(s32 collisionID1, s32 collisionID2, neReponseBitFlag response){
  CAST_THIS(neCollisionTable_, ct);
  ct.Set(collisionID1, collisionID2, response);
}
/************************
*  neCollisionTable::Get *
************************/
neCollisionTable::neReponseBitFlag neCollisionTable::Get(s32 collisionID1, s32 collisionID2){
  CAST_THIS(neCollisionTable_, ct);
  ASSERT(collisionID1 < NE_COLLISION_TABLE_MAX);
  ASSERT(collisionID2 < NE_COLLISION_TABLE_MAX);
  if (collisionID1 < NE_COLLISION_TABLE_MAX && collisionID2 < NE_COLLISION_TABLE_MAX)  {
    return ct.table[collisionID1][collisionID2];
  }
  else
  {
    return RESPONSE_IGNORE;
  }

}

/**************************************
*  neCollisionTable::GetMaxCollisionID *
**************************************/
s32 neCollisionTable::GetMaxCollisionID(){
  return NE_COLLISION_TABLE_MAX;
}


/**********************************
* interface neGeometry -> TConvex *
***********************************/
/**************************
*  neGeometry::SetUserData *
**************************/
void neGeometry::SetUserData(void* userData){
  CAST_THIS(TConvex, con);
  con.userData = userData;
}
/**************************
*  neGeometry::GetUserData *
**************************/
void* neGeometry::GetUserData(){
  CAST_THIS(TConvex, con);
  return con.userData;
}
/******************************
*  neGeometry::GetType (added) *
*******************************/
u32 neGeometry::GetType() {
  CAST_THIS(TConvex, con);
  return con.type;
}
/*************************
*  neGeometry::SetBoxSize *
*************************/
void neGeometry::SetBoxSize(f32 width, f32 height, f32 depth) {
  CAST_THIS(TConvex, con);
  con.SetBoxSize(width, height, depth);
}
/*************************
*  neGeometry::SetBoxSize *
*************************/
void neGeometry::SetBoxSize(const neV3 & boxSize) {
  CAST_THIS(TConvex, con);
  con.SetBoxSize(boxSize[0], boxSize[1], boxSize[2]);
}
/*************************
*  neGeometry::GetBoxSize *
*************************/
neBool neGeometry::GetBoxSize(neV3 & boxSize) { // return false if geometry is not a box
  CAST_THIS(TConvex, con);
  if (con.type != TConvex::BOX){
    return false;
  }
  boxSize = con.as.box.boxSize * 2.0f;
  return true;
}

/********************************
*  neGeometry::SetSphereDiameter *
********************************/
void neGeometry::SetSphereDiameter(f32 diameter){
  CAST_THIS(TConvex, con);
  con.type = TConvex::SPHERE;
  con.as.sphere.radius = diameter * 0.5f;
  con.as.sphere.radiusSq = con.as.sphere.radius * con.as.sphere.radius;
}
/********************************
*  neGeometry::GetSphereDiameter *
********************************/
neBool neGeometry::GetSphereDiameter(f32 & diameter) {// return false if geometry is not a sphere
  CAST_THIS(TConvex, con);
  if (con.type != TConvex::SPHERE){
    return false;
  }
  diameter = con.Radius() * 2.0f;
  return true;
}
/*************************
*  neGeometry::SetCapsule *
*************************/
void neGeometry::SetCapsule(f32 diameter, f32 height) {
  CAST_THIS(TConvex, con);
  con.type = TConvex::CAPSULE;
  con.as.capsule.radius = diameter * 0.5f;
  con.as.capsule.radiusSq = con.as.capsule.radius * con.as.capsule.radius;
  con.as.capsule.halfHeight = height * 0.5f;
}

/*************************
*  neGeometry::GetCapsule *
*************************/
neBool neGeometry::GetCapsule(f32 & diameter, f32 & height) {// return false if geometry is not a capsule
  CAST_THIS(TConvex, con);
  if (con.type != TConvex::CAPSULE){
    return false;
  }
  diameter = con.CapsuleRadius() * 2.0f;
  height   = con.CapsuleHalfHeight() * 2.0f;
  return true;
}
/****************************
*  neGeometry::SetConvexMesh *
****************************/
void neGeometry::SetConvexMesh(neByte * convexData){
  CAST_THIS(TConvex, con);
  con.SetConvexMesh(convexData);
}
/****************************
*  neGeometry::GetConvexMesh *
****************************/
neBool neGeometry::GetConvexMesh(neByte *& convexData){
  CAST_THIS(TConvex, con);
  if (con.type != TConvex::CONVEXDCD){
    return false;
  }
  convexData = con.as.convexDCD.convexData;
  return true;
}

/*******************************
*  neGeometry::SetMaterialIndex *
*******************************/
void neGeometry::SetMaterialIndex(s32 index){
  CAST_THIS(TConvex, con);
  con.SetMaterialId(index);
}
/*******************************
*  neGeometry::GetMaterialIndex *
*******************************/
s32  neGeometry::GetMaterialIndex(){
  CAST_THIS(TConvex, con);
  return con.matIndex;
}

/***************************
*  neGeometry::SetTransform *
***************************/
void neGeometry::SetTransform(neT3 & t){
  CAST_THIS(TConvex, con);
  con.SetTransform(t);
}
/***************************
*  neGeometry::GetTransform *
***************************/
neT3 neGeometry::GetTransform(){
  CAST_THIS(TConvex, con);
  return con.c2p;
}

/***************************
*  neGeometry::SetBreakFlag *
***************************/
void neGeometry::SetBreakageFlag(neBreakFlag flag){
  CAST_THIS(TConvex, con);
  con.breakInfo.flag = flag;
}
/***************************
*  neGeometry::GetBreakFlag *
***************************/
neGeometry::neBreakFlag neGeometry::GetBreakageFlag(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.flag;
}
/******************************
*  neGeometry::SetBreakageMass *
******************************/
void neGeometry::SetBreakageMass(f32 mass){
  CAST_THIS(TConvex, con);
  con.breakInfo.mass = mass;
}
/******************************
*  neGeometry::GetBreakageMass *
******************************/
f32  neGeometry::GetBreakageMass(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.mass;
}

/***************************************
*  neGeometry::SetBreakageInertiaTensor *
***************************************/
void neGeometry::SetBreakageInertiaTensor(const neV3 & tensor){
  CAST_THIS(TConvex, con);
  con.breakInfo.inertiaTensor = tensor;
}
/***************************************
*  neGeometry::GetBreakageInertiaTensor *
***************************************/
neV3 neGeometry::GetBreakageInertiaTensor(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.inertiaTensor;
}
/***********************************
*  neGeometry::SetBreakageMagnitude *
***********************************/
void neGeometry::SetBreakageMagnitude(f32 mag){
  CAST_THIS(TConvex, con);
  con.breakInfo.breakMagnitude = mag;
}
/***********************************
*  neGeometry::GetBreakageMagnitude *
***********************************/
f32  neGeometry::GetBreakageMagnitude(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.breakMagnitude;
}
/************************************
*  neGeometry::SetBreakageAbsorption *
************************************/
void neGeometry::SetBreakageAbsorption(f32 absorb){
  CAST_THIS(TConvex, con);
  con.breakInfo.breakAbsorb = absorb;
}
/*******************************
*  neGeometry::SetBreakagePlane *
*******************************/
void neGeometry::SetBreakagePlane(const neV3 & planeNormal){
  CAST_THIS(TConvex, con);
  con.breakInfo.breakPlane = planeNormal;
}
/*******************************
*  neGeometry::GetBreakagePlane *
*******************************/
neV3 neGeometry::GetBreakagePlane(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.breakPlane;
}
/************************************
*  neGeometry::GetBreakageAbsorption *
************************************/
f32  neGeometry::GetBreakageAbsorption(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.breakAbsorb;
}
/**************************************
*  neGeometry::SetBreakNeighbourRadius *
**************************************/
void neGeometry::SetBreakageNeighbourRadius(f32 radius){
  CAST_THIS(TConvex, con);
  con.breakInfo.neighbourRadius = radius;
}

/**************************************
*  neGeometry::GetBreakNeighbourRadius *
**************************************/
f32 neGeometry::GetBreakageNeighbourRadius(){
  CAST_THIS(TConvex, con);
  return con.breakInfo.neighbourRadius;
}

/*************************************
* neAnimatedBody as neCollisionBody_ *
**************************************/
/*************************
* neAnimatedBody::SetPos *
*************************/
void neAnimatedBody::SetPos(const neV3 & p){
  CAST_THIS(neCollisionBody_, cb);
  cb.b2w.pos = p;
  cb.UpdateAABB();
  cb.moved = true;
}
/*************************
* neAnimatedBody::GetPos *
*************************/
neV3 neAnimatedBody::GetPos(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.b2w.pos;
}

/********************************
* neAnimatedBody::SetRotationM3 *
********************************/
void neAnimatedBody::SetRotationM3(const neM3 & m){
  CAST_THIS(neCollisionBody_, cb);
  cb.b2w.rot = m;
  cb.moved = true;
}
/********************************
* neAnimatedBody::GetRotationM3 *
********************************/
neM3 neAnimatedBody::GetRotationM3(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.b2w.rot;
}

/*******************************
* neAnimatedBody::SetRotationQ *
*******************************/
void neAnimatedBody::SetRotationQ(const neQ & q){
  CAST_THIS(neCollisionBody_, cb);
  cb.b2w.rot = q.BuildMatrix3();
  cb.moved = true;
}
/*******************************
* neAnimatedBody::GetRotationQ *
*******************************/
neQ  neAnimatedBody::GetRotationQ(){
  CAST_THIS(neCollisionBody_, cb);
  neQ q;
  q.SetupFromMatrix3(cb.b2w.rot);
  return q;
}

/*******************************
* neAnimatedBody::GetTransform *
*******************************/
neT3 neAnimatedBody::GetTransform(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.b2w;
}

/*********************************
* neAnimatedBody::SetCollisionID *
*********************************/
void neAnimatedBody::SetCollisionID(s32 cid){
  CAST_THIS(neCollisionBody_, cb);
  cb.cid = cid;
}
/*********************************
* neAnimatedBody::GetCollisionID *
*********************************/
s32  neAnimatedBody::GetCollisionID(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.cid;
}

/******************************
* neAnimatedBody::SetUserData *
******************************/
void neAnimatedBody::SetUserData(void* userData){
  CAST_THIS(neCollisionBody_, cb);
  cb.userData = userData;
}
/******************************
*  neAnimatedBody::GetUserData *
******************************/
void*  neAnimatedBody::GetUserData(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.userData;
}

/***********************************
*  neAnimatedBody::GetGeometryCount *
***********************************/
s32  neAnimatedBody::GetGeometryCount(){
  CAST_THIS(neCollisionBody_, cb);
  return cb.col.convexCount;
}

/*********************************************
* interface neAnimatedBody -> neRigidBodyBase*
**********************************************/
/*************************************
*  neAnimatedBody::UpdateBoundingInfo *
*************************************/
void neAnimatedBody::UpdateBoundingInfo(){
  CAST_THIS(neRigidBodyBase, rb);
  rb.RecalcBB();
}
/***********************************
*  neAnimatedBody::CollideConnected *
***********************************/
void neAnimatedBody::CollideConnected(neBool yes){
  CAST_THIS(neRigidBodyBase, rb);
  rb.CollideConnected(yes);
}
/*************************************
*  neAnimatedBody::IsCollideConnected *
*************************************/
neBool neAnimatedBody::CollideConnected(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.CollideConnected();
}
/*******************************************
*  neAnimatedBody::CollideDirectlyConnected *
*******************************************/
void neAnimatedBody::CollideDirectlyConnected(neBool yes){
  CAST_THIS(neRigidBodyBase, rb);
  rb.isCollideDirectlyConnected = yes;
}
/*******************************************
*  neAnimatedBody::CollideDirectlyConnected *
*******************************************/
neBool neAnimatedBody::CollideDirectlyConnected(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.isCollideDirectlyConnected;
}
#ifndef NO_ANIMATED_SENSOR
/****************************
*  neAnimatedBody::AddSensor *
****************************/
neSensor * neAnimatedBody::AddSensor(){
  CAST_THIS(neRigidBodyBase, ab);
  neSensor_ * s = ab.AddSensor();
  return reinterpret_cast<neSensor *>(s);
}
/*******************************
*  neAnimatedBody::RemoveSensor *
*******************************/
neBool neAnimatedBody::RemoveSensor(neSensor * s){
  CAST_THIS(neRigidBodyBase, ab);
  if (!ab.sensors){
    return false;
  }
  neSensorItem * si = (neSensorItem *)ab.sensors;
  while (si){
    neSensor_ * sensor = (neSensor_ *) si;
    si = si->next;
    if (sensor == reinterpret_cast<neSensor_*>(s)){
      ab.sim->sensorHeap.Dealloc(sensor, 1);
      return true;
    }
  }
  return false;
}
/*************************************
*  neAnimatedBody::BeginIterateSensor *
*************************************/
void neAnimatedBody::BeginIterateSensor(){
  CAST_THIS(neRigidBodyBase, ab);
  ab.BeginIterateSensor();
}
/********************************
*  neAnimatedBody::GetNextSensor *
********************************/
neSensor * neAnimatedBody::GetNextSensor(){
  CAST_THIS(neRigidBodyBase, ab);
  return reinterpret_cast<neSensor *>(ab.GetNextSensor());
}
#endif // NO_ANIMATED_SENSOR
/*************************
*  neAnimatedBody::Active *
*************************/
void neAnimatedBody::Active(neBool yes, neRigidBody * hint){
  CAST_THIS(neRigidBodyBase, ab);
  ab.Active(yes, (neRigidBodyBase *)hint);
}
/*************************
*  neAnimatedBody::Active *
*************************/
void neAnimatedBody::Active(neBool yes, neAnimatedBody * hint){
  CAST_THIS(neRigidBodyBase, ab);
  ab.Active(yes, (neRigidBodyBase *)hint);
}
/***************************
*  neAnimatedBody::IsActive *
***************************/
neBool neAnimatedBody::Active(){
  CAST_THIS(neRigidBodyBase, ab);
  return ab.isActive;
}

/***********************************************
* interface neAnimatedBody -> neCollisionBody_ *
***********************************************/
/******************************
*  neAnimatedBody::AddGeometry *
******************************/
neGeometry * neAnimatedBody::AddGeometry(){
  CAST_THIS(neCollisionBody_, ab);
  TConvex * g = ab.AddGeometry();
  return reinterpret_cast<neGeometry *>(g);
}
/*********************************
*  neAnimatedBody::RemoveGeometry *
*********************************/
neBool neAnimatedBody::RemoveGeometry(neGeometry * g){
  CAST_THIS(neCollisionBody_, ab);
  if (!ab.col.convex){
    return false;
  }
  TConvexItem * gi = (TConvexItem *)ab.col.convex;
  while (gi){
    TConvex * convex = reinterpret_cast<TConvex *>(gi);
    gi = gi->next;
    if (convex == reinterpret_cast<TConvex *>(g))  {
      if (ab.col.convex == convex){
        ab.col.convex = (TConvex*)gi;
      }
      ab.sim->geometryHeap.Dealloc(convex, 1);
      ab.col.convexCount--;
      if (ab.col.convexCount == 0){
        ab.col.convex = NULL;
        if (ab.IsInRegion() && !ab.isCustomCD){
          ab.sim->region.RemoveBody(&ab);
        }
      }
      return true;
    }
  }
  return false;
}

/***************************************
*  neAnimatedBody::BeginIterateGeometry *
***************************************/
void neAnimatedBody::BeginIterateGeometry(){
  CAST_THIS(neCollisionBody_, ab);
  ab.BeginIterateGeometry();
}
/**********************************
*  neAnimatedBody::GetNextGeometry *
**********************************/
neGeometry * neAnimatedBody::GetNextGeometry(){
  CAST_THIS(neCollisionBody_, ab);
  return reinterpret_cast<neGeometry *>(ab.GetNextGeometry());
}
/********************************
*  neAnimatedBody::BreakGeometry *
********************************/
neRigidBody * neAnimatedBody::BreakGeometry(neGeometry * geo){
  CAST_THIS(neCollisionBody_, cb);
  neRigidBody_ * newBody = cb.sim->CreateRigidBodyFromConvex((TConvex*)geo, &cb);
  return (neRigidBody *)newBody;
}
/**********************************************
*  neAnimatedBody::UseCustomCollisionDetection *
**********************************************/
void neAnimatedBody::UseCustomCollisionDetection(neBool yes,  const neT3 * obb, f32 boundingRadius){
  CAST_THIS(neCollisionBody_, ab);
  if (yes){
    ab.obb = *obb;
    ab.col.boundingRadius = boundingRadius;
    ab.isCustomCD = yes;
    if (ab.isActive && !ab.IsInRegion()){
      ab.sim->region.AddBody(&ab, NULL);
    }
  }
  else
  {
    ab.isCustomCD = yes;
    this->UpdateBoundingInfo();
    if (ab.IsInRegion() && GetGeometryCount() == 0)  {
      ab.sim->region.RemoveBody(&ab);
    }
  }
}
/**********************************************
*  neAnimatedBody::UseCustomCollisionDetection *
***********************************************/
neBool neAnimatedBody::UseCustomCollisionDetection(){
  CAST_THIS(neCollisionBody_, ab);
  return ab.isCustomCD;
}


/*******************************************
* interface neRigidBody -> neRigidBodyBase *
*******************************************/
/***************************
*  neRigidBody::SetUserData *
***************************/
void neRigidBody::SetUserData(void* userData){
  CAST_THIS(neRigidBodyBase, rb);
  rb.userData = userData;
}
/***************************
*  neRigidBody::GetUserData *
***************************/
void*  neRigidBody::GetUserData(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.userData;
}
/******************************
*  neRigidBody::SetCollisionID *
******************************/
void neRigidBody::SetCollisionID(s32 cid){
  CAST_THIS(neRigidBodyBase, rb);
  rb.cid = cid;
}
/******************************
*  neRigidBody::GetCollisionID *
******************************/
s32  neRigidBody::GetCollisionID(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.cid;
}
/********************************
*  neRigidBody::GetGeometryCount *
********************************/
s32 neRigidBody::GetGeometryCount(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.col.convexCount;
}
/**********************************
*  neRigidBody::UpdateBoundingInfo *
**********************************/
void neRigidBody::UpdateBoundingInfo(){
  CAST_THIS(neRigidBodyBase, rb);
  rb.RecalcBB();
}
/****************************************
* interface neRigidBody -> neRigidBody_ *
****************************************/
/***********************
*  neRigidBody::SetMass *
***********************/
void neRigidBody::SetMass(f32 mass){
  CAST_THIS(neRigidBody_, rb);
  ASSERT(neIsFinite(mass));
  rb.mass = mass;
  rb.oneOnMass = 1.0f / mass;
}
/***********************
*  neRigidBody::GetMass *
***********************/
f32 neRigidBody::GetMass(){
  CAST_THIS(neRigidBody_, rb);
  return rb.mass;
}

/**********************************
*  neRigidBody::SetInertiaTensorV3 *
**********************************/
void neRigidBody::SetInertiaTensor(const neV3 & v){
  CAST_THIS(neRigidBody_, rb);
  neM3 tensor;
  tensor.SetIdentity();
  tensor[0][0] = v[0];
  tensor[1][1] = v[1];
  tensor[2][2] = v[2];
  rb.Ibody = tensor;
  rb.IbodyInv.SetInvert(tensor);
}
/**********************************
*  neRigidBody::SetInertiaTensorM3 *
**********************************/
void neRigidBody::SetInertiaTensor(const neM3 & tensor){
  CAST_THIS(neRigidBody_, rb);
  rb.Ibody = tensor;
  rb.IbodyInv.SetInvert(tensor);
}
/********************************
* neRigidBody::SetLinearDamping *
********************************/
void neRigidBody::SetLinearDamping(f32 damp){
  CAST_THIS(neRigidBody_, rb);
  rb.linearDamp = neAbs(damp);
}
/********************************
* neRigidBody::GetLinearDamping *
********************************/
f32  neRigidBody::GetLinearDamping(){
  CAST_THIS(neRigidBody_, rb);
  return rb.linearDamp;
}
/*********************************
* neRigidBody::SetAngularDamping *
**********************************/
void neRigidBody::SetAngularDamping(f32 damp){
  CAST_THIS(neRigidBody_, rb);
  rb.angularDamp = neAbs(damp);
}
/*********************************
* neRigidBody::GetAngularDamping *
**********************************/
f32  neRigidBody::GetAngularDamping(){
  CAST_THIS(neRigidBody_, rb);
  return rb.angularDamp;
}
/************************************
*  neRigidBody::SetSleepingParameter *
************************************/
void neRigidBody::SetSleepingParameter(f32 sleepingParam){
  CAST_THIS(neRigidBody_, rb);
  rb.sleepingParam = sleepingParam;
}
/************************************
*  neRigidBody::GetSleepingParameter *
************************************/
f32 neRigidBody::GetSleepingParameter(){
  CAST_THIS(neRigidBody_, rb);
  return rb.sleepingParam;
}

/**********************
*  neRigidBody::SetPos *
**********************/
void neRigidBody::SetPos(const neV3 & p){
  CAST_THIS(neRigidBody_, rb);
  rb.SetPos(p);
  rb.WakeUp();
}
/**********************
*  neRigidBody::GetPos *
**********************/
neV3 neRigidBody::GetPos(){
  CAST_THIS(neRigidBody_, rb);
  return rb.GetPos();
}

/*****************************
*  neRigidBody::SetRotationM3 *
*****************************/
void neRigidBody::SetRotationM3(const neM3 & m){
  ASSERT(m.IsOrthogonalNormal());
  CAST_THIS(neRigidBody_, rb);
  rb.State().rot() = m;
  rb.State().q.SetupFromMatrix3(m);
  rb.WakeUp();
}
/*****************************
*  neRigidBody::GetRotationM3 *
*****************************/
neM3 neRigidBody::GetRotationM3(){
  CAST_THIS(neRigidBody_, rb);
  return rb.State().rot();
}

/****************************
*  neRigidBody::SetRotationQ *
****************************/
void neRigidBody::SetRotationQ(const neQ & q){
  CAST_THIS(neRigidBody_, rb);
  rb.State().q = q;
  rb.State().rot() = q.BuildMatrix3();
  rb.WakeUp();
}
/****************************
*  neRigidBody::GetRotationQ *
****************************/
neQ  neRigidBody::GetRotationQ(){
  CAST_THIS(neRigidBody_, rb);
  return rb.State().q;
}

/****************************
*  neRigidBody::GetTransform *
****************************/
neT3 neRigidBody::GetTransform(){
  CAST_THIS(neRigidBody_, rb);
  rb.State().b2w.rot[0].v[3] = 0.0f;
  rb.State().b2w.rot[1].v[3] = 0.0f;
  rb.State().b2w.rot[2].v[3] = 0.0f;
  rb.State().b2w.pos.v[3] = 1.0f;
  return rb.State().b2w;
}

/***************************
*  neRigidBody::SetVelocity *
***************************/
void neRigidBody::SetVelocity(const neV3 & v){
  CAST_THIS(neRigidBody_, rb);
  rb.Derive().linearVel = v;
  rb.WakeUpAllJoint();
}
/***************************
*  neRigidBody::GetVelocity *
***************************/
neV3 neRigidBody::GetVelocity(){
  CAST_THIS(neRigidBody_, rb);
  return rb.Derive().linearVel;
}

/**********************************
*  neRigidBody::GetAngularVelocity *
**********************************/
neV3 neRigidBody::GetAngularVelocity(){
  CAST_THIS(neRigidBody_, rb);
  return rb.Derive().angularVel;
}
/**********************************
*  neRigidBody::SetAngularMomemtum *
**********************************/
void neRigidBody::SetAngularMomentum(const neV3& am){
  CAST_THIS(neRigidBody_, rb);
  rb.SetAngMom(am);
  rb.WakeUpAllJoint();
}
/**********************************
*  neRigidBody::GetAngularMomemtum *
**********************************/
neV3 neRigidBody::GetAngularMomentum(){
  CAST_THIS(neRigidBody_, rb);
  return rb.State().angularMom;
}
/**********************************
*  neRigidBody::GetVelocityAtPoint *
**********************************/
neV3 neRigidBody::GetVelocityAtPoint(const neV3 & pt){
  CAST_THIS(neRigidBody_, rb);
  return rb.VelocityAtPoint(pt);
}
/***********************************
*  neRigidBody::UpdateInertiaTensor *
***********************************/
void neRigidBody::UpdateInertiaTensor(){
  CAST_THIS(neRigidBody_, rb);
  rb.RecalcInertiaTensor();
}

/******************************
*  neRigidBody::SetForce (COG) *
******************************/
void neRigidBody::SetForce(const neV3 & force){
  CAST_THIS(neRigidBody_, rb);
  if (force.IsConsiderZero())  {
    rb.force = force;
    return;
  }
  rb.force = force;
  rb.WakeUp();
}
/************************
*  neRigidBody::GetForce *
************************/
neV3 neRigidBody::GetForce(){
  CAST_THIS(neRigidBody_, rb);
  return rb.force;
}

/*******************************
*  neRigidBody::SetForceAtPoint *
********************************/
void neRigidBody::SetForce(const neV3 & force, const neV3 & pos){
  CAST_THIS(neRigidBody_, rb);
  if (force.IsConsiderZero()){
    rb.force = force;
    rb.torque = ((pos - rb.GetPos()).Cross(force));
    return;
  }
  rb.force = force;
  rb.torque = ((pos - rb.GetPos()).Cross(force));
  rb.WakeUp();
}

/*************************
*  neRigidBody::SetTorque *
*************************/
void neRigidBody::SetTorque(const neV3 & torque){
  CAST_THIS(neRigidBody_, rb);
  if (torque.IsConsiderZero()){
    rb.torque = torque;
    return;
  }
  rb.torque = torque;
  rb.WakeUp();
}
/*************************
*  neRigidBody::GetTorque *
*************************/
neV3 neRigidBody::GetTorque(){
  CAST_THIS(neRigidBody_, rb);
  return rb.torque;
}

/**************************
*  neRigidBody::AddImpulse *
**************************/
void neRigidBody::ApplyImpulse(const neV3 & impulse){
  CAST_THIS(neRigidBody_, rb);
  neV3 dv = impulse * rb.oneOnMass;
  rb.Derive().linearVel += dv;
  rb.WakeUpAllJoint();
}

/*********************************
*  neRigidBody::AddImpulseAtPoint *
*********************************/
void neRigidBody::ApplyImpulse(const neV3 & impulse, const neV3 & pos){
  CAST_THIS(neRigidBody_, rb);
  neV3 dv = impulse * rb.oneOnMass;
  neV3 da = (pos - rb.GetPos()).Cross(impulse);
  rb.Derive().linearVel += dv;
  neV3 newAM = rb.State().angularMom + da;
  rb.SetAngMom(newAM);
  rb.WakeUp();
}

/**************************
*  neRigidBody::ApplyTwist *
**************************/
void neRigidBody::ApplyTwist(const neV3 & twist){
  CAST_THIS(neRigidBody_, rb);
  neV3 newAM = twist;
  rb.SetAngMom(newAM);
  rb.WakeUp();
}

/*****************************
*  neRigidBody::AddController *
*****************************/
neRigidBodyController * neRigidBody::AddController(RigidBodyControllerCallback * rbcc, s32 period){
  CAST_THIS(neRigidBody_, rb);
  return (neRigidBodyController *)rb.AddController(rbcc, period);
}
/********************************
*  neRigidBody::RemoveController *
********************************/
neBool neRigidBody::RemoveController(neRigidBodyController * rbController){
  CAST_THIS(neRigidBody_, rb);
  if (!rb.controllers){
    return false;
  }
  neControllerItem * ci = (neControllerItem *)rb.controllers;
  while (ci){
    neController * con = reinterpret_cast<neController *>(ci);
    ci = ci->next;
    if (con == reinterpret_cast<neController *>(rbController)){
      rb.sim->controllerHeap.Dealloc(con, 1);
      return true;
    }
  }
  return false;
}

/**************************************
*  neRigidBody::BeginIterateController *
**************************************/
void neRigidBody::BeginIterateController(){
  CAST_THIS(neRigidBody_, rb);
  rb.BeginIterateController();
}
/*********************************
*  neRigidBody::GetNextController *
*********************************/
neRigidBodyController * neRigidBody::GetNextController(){
  CAST_THIS(neRigidBody_, rb);
  return (neRigidBodyController *)rb.GetNextController();
}

/*****************************
*  neRigidBody::GravityEnable *
*****************************/
void neRigidBody::GravityEnable(neBool yes){
  CAST_THIS(neRigidBody_, rb);
  rb.GravityEnable(yes);
}

/*******************************
*  neRigidBody::GravityIsEnable *
*******************************/
neBool neRigidBody::GravityEnable(){
  CAST_THIS(neRigidBody_, rb);
  return rb.gravityOn;
}

/********************************
*  neRigidBody::CollideConnected *
********************************/
void neRigidBody::CollideConnected(neBool yes){
  CAST_THIS(neRigidBody_, rb);
  rb.CollideConnected(yes);
}
/**********************************
*  neRigidBody::CollideIsConnected *
**********************************/
neBool neRigidBody::CollideConnected(){
  CAST_THIS(neRigidBody_, rb);
  return rb.CollideConnected();
}

/****************************************
*  neRigidBody::CollideDirectlyConnected *
*****************************************/
void neRigidBody::CollideDirectlyConnected(neBool yes){
  CAST_THIS(neRigidBody_, rb);
  rb.isCollideDirectlyConnected = yes;
}
/******************************************
*  neRigidBody::CollideIsDirectlyConnected *
******************************************/
neBool neRigidBody::CollideDirectlyConnected(){
  CAST_THIS(neRigidBody_, rb);
  return rb.isCollideDirectlyConnected;
}

/***************************
*  neRigidBody::AddGeometry *
***************************/
neGeometry * neRigidBody::AddGeometry(){
  CAST_THIS(neRigidBody_, rb);
  TConvex * g = rb.AddGeometry();
  return reinterpret_cast<neGeometry *>(g);
}

/******************************
*  neRigidBody::RemoveGeometry *
******************************/
neBool neRigidBody::RemoveGeometry(neGeometry * g){
  CAST_THIS(neRigidBody_, rb);
  if (!rb.col.convex){
    return false;
  }
  TConvexItem * gi = (TConvexItem *)rb.col.convex;
  while (gi){
    TConvex * convex = reinterpret_cast<TConvex *>(gi);
    gi = gi->next;
    if (convex == reinterpret_cast<TConvex *>(g))  {
      if (rb.col.convex == convex){
        rb.col.convex = (TConvex*)gi;
      }
      rb.sim->geometryHeap.Dealloc(convex, 1);
      rb.col.convexCount--;
      if (rb.col.convexCount == 0){
        rb.col.convex = NULL;
        if (rb.IsInRegion() && !rb.isCustomCD){
          rb.sim->region.RemoveBody(&rb);
        }
      }
      return true;
    }
  }
  return false;
}

/************************************
*  neRigidBody::BeginIterateGeometry *
************************************/
void neRigidBody::BeginIterateGeometry(){
  CAST_THIS(neRigidBody_, rb);
  rb.BeginIterateGeometry();
}
/*******************************
*  neRigidBody::GetNextGeometry *
*******************************/
neGeometry * neRigidBody::GetNextGeometry(){
  CAST_THIS(neRigidBody_, rb);
  return reinterpret_cast<neGeometry *>(rb.GetNextGeometry());
}

/*****************************
*  neRigidBody::BreakGeometry *
*****************************/
neRigidBody * neRigidBody::BreakGeometry(neGeometry * geo){
  CAST_THIS(neRigidBody_, rb_);
  neRigidBody_ * newBody = rb_.sim->CreateRigidBodyFromConvex((TConvex*)geo, &rb_);
  return (neRigidBody *)newBody;
}

/*******************************************
*  neRigidBody::UseCustomCollisionDetection *
*******************************************/
void neRigidBody::UseCustomCollisionDetection(neBool yes,  const neT3 * obb, f32 boundingRadius){
  CAST_THIS(neRigidBody_, rb);
  if (yes){
    rb.obb = *obb;
    rb.col.boundingRadius = boundingRadius;
    rb.isCustomCD = yes;
    if (rb.isActive && !rb.IsInRegion()){
      rb.sim->region.AddBody(&rb, NULL);
    }
  }
  else
  {
    rb.isCustomCD = yes;
    this->UpdateBoundingInfo();
    if (rb.IsInRegion() && GetGeometryCount() == 0)  {
      rb.sim->region.RemoveBody(&rb);
    }
  }
}
/*******************************************
*  neRigidBody::UseCustomCollisionDetection *
*******************************************/
neBool neRigidBody::UseCustomCollisionDetection(){
  CAST_THIS(neRigidBody_, rb);
  return rb.isCustomCD;
}

/*************************
*  neRigidBody::AddSensor *
*************************/
neSensor * neRigidBody::AddSensor(){
  CAST_THIS(neRigidBody_, rb);
  neSensor_ * s = rb.AddSensor();
  return reinterpret_cast<neSensor *>(s);
}
/****************************
*  neRigidBody::RemoveSensor *
****************************/
neBool neRigidBody::RemoveSensor(neSensor * s){
  CAST_THIS(neRigidBody_, rb);
  if (!rb.sensors){
    return false;
  }
  neSensorItem * si = (neSensorItem *)rb.sensors;
  while (si){
    neSensor_ * sensor = reinterpret_cast<neSensor_ *>(si);
    si = si->next;
    if (sensor == reinterpret_cast<neSensor_ *>(s))  {
      rb.sim->sensorHeap.Dealloc(sensor, 1);
      return true;
    }
  }
  return false;
}

/**********************************
* neRigidBody::BeginIterateSensor *
**********************************/
void neRigidBody::BeginIterateSensor(){
  CAST_THIS(neRigidBody_, rb);
  rb.BeginIterateSensor();
}
/*****************************
* neRigidBody::GetNextSensor *
*****************************/
neSensor * neRigidBody::GetNextSensor(){
  CAST_THIS(neRigidBody_, rb);
  return reinterpret_cast<neSensor *>(rb.GetNextSensor());
}

/**********************
* neRigidBody::Active *
**********************/
void neRigidBody::Active(neBool yes, neRigidBody * hint){
  CAST_THIS(neRigidBodyBase, rb);
  rb.Active(yes, (neRigidBodyBase *)hint);
}
/**********************
* neRigidBody::Active *
**********************/
void neRigidBody::Active(neBool yes, neAnimatedBody * hint){
  CAST_THIS(neRigidBodyBase, rb);
  rb.Active(yes, (neRigidBodyBase *)hint);
}

/************************
* neRigidBody::IsActive *
************************/
neBool neRigidBody::Active(){
  CAST_THIS(neRigidBodyBase, rb);
  return rb.isActive;
}
/**********************
* neRigidBody::IsIdle *
**********************/
neBool neRigidBody::IsIdle(){
  CAST_THIS(neRigidBody_, rb);
  return (rb.status == neRigidBody_::NE_RBSTATUS_IDLE);
}
/**********************
* neRigidBody::WakeUp *
**********************/
void neRigidBody::WakeUp(){
  CAST_THIS(neRigidBody_, rb);
  rb.WakeUp();
}
/**************************
* neRigidBody::IsParticle *
**************************/
neBool neRigidBody::IsParticle(){
  CAST_THIS(neRigidBody_, rb);
  return rb.IsParticle();
}


/**************************************************
* interface neRigidBodyController -> neController *
**************************************************/
/**************************************
*  neRigidBodyController::GetRigidBody *
**************************************/
neRigidBody * neRigidBodyController::GetRigidBody(){
  CAST_THIS(neController, c);
  return (neRigidBody *)c.rb;
}
/**********************************************
*  neRigidBodyController::SetControllerForceV3 *
**********************************************/
void neRigidBodyController::SetControllerForceV3(const neV3 & force){
  CAST_THIS(neController, c);
  c.forceA = force;
}
/**********************************************
*  neRigidBodyController::GetControllerForceV3 *
**********************************************/
neV3 neRigidBodyController::GetControllerForceV3(){
  CAST_THIS(neController, c);
  return c.forceA;
}
/***********************************************
*  neRigidBodyController::SetControllerTorqueV3 *
***********************************************/
void neRigidBodyController::SetControllerTorqueV3(const neV3 & torque){
  CAST_THIS(neController, c);
  c.torqueA = torque;
}
/***********************************************
*  neRigidBodyController::GetControllerTorqueV3 *
***********************************************/
neV3 neRigidBodyController::GetControllerTorqueV3(){
  CAST_THIS(neController, c);
  return c.torqueA;
}

/********************************************************
*  neRigidBodyController::SetControllerForceWithTorqueV3 *
********************************************************/
void neRigidBodyController::SetControllerForceWithTorqueV3(const neV3 & force, const neV3 & pos){
  CAST_THIS(neController, c);
  c.forceA = force;
  c.torqueA = ((pos - c.rb->GetPos()).Cross(force));
}

#undef CAST_THIS

/*******************
*  Helper functions *
*******************/

/*******************
*  BoxInertiaTensor *
*******************/
neV3 neBoxInertiaTensor(const neV3 & boxSize, f32 mass){
  return neBoxInertiaTensor(boxSize[0], boxSize[1], boxSize[2], mass);
}

neV3 neBoxInertiaTensor(f32 width, f32 height, f32 depth, f32 mass){
  neV3 ret;

  f32 maxdim = width;

  if (height > maxdim){
    maxdim = height;
  }
  if (depth > maxdim){
    maxdim = depth;
  }

  f32  xsq = maxdim;
  f32  ysq = maxdim;
  f32  zsq = maxdim;

  xsq *= xsq;
  ysq *= ysq;
  zsq *= zsq;

  ret[0] = (ysq + zsq) * mass / 3.0f;
  ret[1] = (xsq + zsq) * mass / 3.0f;
  ret[2] = (xsq + ysq) * mass / 3.0f;

  return ret;
}

neV3 neSphereInertiaTensor(f32 diameter, f32 mass){
  f32 radius = diameter * 0.5f;
  f32 value = 2.0f / 5.0f * mass * radius * radius;
  neV3 ret;
  ret.Set(value);
  return ret;
}

neV3 neCapsuleInertiaTensor(f32 diameter, f32 height, f32 mass){
  f32 radius = diameter * 0.5f;
  f32 radiusSq = radius * radius;
  f32 Ixz = 1.0f / 12.0f * mass * height * height + 0.25f * mass * radiusSq;
  f32 Iyy = 0.5f * mass * radiusSq;
  neV3 ret;
  ret.Set(Ixz, Iyy, Ixz);
  return ret;
}
