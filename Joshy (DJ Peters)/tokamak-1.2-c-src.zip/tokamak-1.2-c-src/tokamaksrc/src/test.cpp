#include "rigidbody.h"

void test()
{
	/*
	v3 t;
	t.v[1] = 0;
	t.x = 0;

	t4 a, b;

	t4Copy(a, b);
	*/
	//CRigidBody rb;
}