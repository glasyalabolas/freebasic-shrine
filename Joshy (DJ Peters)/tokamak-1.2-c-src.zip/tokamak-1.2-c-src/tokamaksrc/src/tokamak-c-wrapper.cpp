#include "tokamak-c-wrapper.h"

#ifdef TOKAMAK_COMPILE_DLL
 #if 0
BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved) {
    switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
      break;
    }
    return TRUE;
}

 #endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**********
* globals *
**********/
neV3 gV3;
neT3 gT3;
neM3 gM3;
neQ  gQ;

/**************
* neSimulator *
**************/
neSimulator * CreateSimulator(const neSimulatorSizeInfo & sizeInfo, f32 gx, f32 gy, f32 gz) {
  gV3.Set(gx,gy,gz);
  return neSimulator::CreateSimulator(sizeInfo, NULL, &gV3);
}
neSimulator * CreateSimulatorV3(const neSimulatorSizeInfo & sizeInfo, const neV3 & grav) {
  return neSimulator::CreateSimulator(sizeInfo, NULL, &grav);
}

void DestroySimulator(neSimulator * & sim){
  if (sim) {
    neSimulator::DestroySimulator(sim);
    sim=NULL;
  }
}

void SimulatorSetGravity(neSimulator * sim, f32 gx, f32 gy, f32 gz){
  gV3.Set(gx,gy,gz);
  sim->SetGravity(gV3);
}
void SimulatorGetGravity(neSimulator * sim, f32 & gx, f32 & gy, f32 & gz){
  gV3 = sim->GetGravity();
  gx=gV3[0]; gy=gV3[1]; gz=gV3[2];
}

void SimulatorSetGravityV3(neSimulator * sim, const neV3 & g){
  sim->SetGravity(g);
}
neV3 SimulatorGetGravityV3(neSimulator * sim){
  return sim->GetGravity();
}

neRigidBody * SimulatorCreateRigidBody(neSimulator * sim){
  return sim->CreateRigidBody();
}
neRigidBody * SimulatorCreateRigidParticle(neSimulator * sim){
  return sim->CreateRigidParticle();
}
void SimulatorFreeRigidBody(neSimulator * sim, neRigidBody * & body){
  if (body) {
    sim->FreeRigidBody(body); body=NULL;
  }
}

neAnimatedBody * SimulatorCreateAnimatedBody(neSimulator * sim){
  return sim->CreateAnimatedBody();
}
void SimulatorFreeAnimatedBody(neSimulator * sim, neAnimatedBody * & body) {
  if (body) {
    sim->FreeAnimatedBody(body); body=NULL;
  }
}
/// Active
neAnimatedBody * SimulatorBeginIterateActiveAnimatedBody(neSimulator * sim){
  return sim->BeginIterateActiveAnimatedBody();
}
neAnimatedBody * SimulatorGetNextActiveAnimatedBody(neSimulator * sim, neAnimatedBody* ab){
  return sim->GetNextActiveAnimatedBody(ab);
}

neRigidBody * SimulatorBeginIterateActiveRigidBody(neSimulator * sim){
  return sim->BeginIterateActiveRigidBody();
}
neRigidBody * SimulatorGetNextActiveRigidBody(neSimulator * sim, neRigidBody* rb){
  return sim->GetNextActiveRigidBody(rb);
}

neRigidBody * SimulatorBeginIterateActiveRigidParticleBody(neSimulator * sim){
  return sim->BeginIterateActiveRigidParticleBody();
}
neRigidBody * SimulatorGetNextActiveRigidParticleBody(neSimulator * sim, neRigidBody* rb){
  return sim->GetNextActiveRigidParticleBody(rb);
}

/// Inactive
neAnimatedBody * SimulatorBeginIterateInactiveAnimatedBody(neSimulator * sim){
  return sim->BeginIterateInactiveAnimatedBody();
}
neAnimatedBody * SimulatorGetNextInactiveAnimatedBody(neSimulator * sim, neAnimatedBody* ab){
  return sim->GetNextInactiveAnimatedBody(ab);
}

neRigidBody * SimulatorBeginIterateInactiveRigidBody(neSimulator * sim){
  return sim->BeginIterateInactiveRigidBody();
}
neRigidBody * SimulatorGetNextInactiveRigidBody(neSimulator * sim, neRigidBody* rb){
  return sim->GetNextInactiveRigidBody(rb);
}

neRigidBody * SimulatorBeginIterateInactiveRigidParticleBody(neSimulator * sim){
  return sim->BeginIterateInactiveRigidParticleBody();
}
neRigidBody * SimulatorGetNextInactiveRigidParticleBody(neSimulator * sim, neRigidBody* rb){
  return sim->GetNextInactiveRigidParticleBody(rb);
}


bool SimulatorSetMaterial(neSimulator * sim, s32 index, f32 friction, f32 restitution){
  return sim->SetMaterial(index,friction,restitution);
}
bool SimulatorGetMaterial(neSimulator * sim, s32 index, f32& friction, f32& restitution){
  return sim->GetMaterial(index,friction,restitution);
}

void SimulatorAdvance(neSimulator * sim, f32 sec){
#ifndef NO_PERFORMANCE
  sim->Advance(sec,1,NULL);
#else
  sim->Advance(sec,1);
#endif
}
void SimulatorAdvanceSteps(neSimulator * sim, f32 sec, s32 steps){
#ifndef NO_PERFORMANCE
  sim->Advance(sec,steps,NULL);
#else
  sim->Advance(sec,steps);
#endif
}
void SimulatorAdvanceMinMax(neSimulator * sim, f32 sec, f32 minTimeStep, f32 maxTimeStep){
#ifndef NO_PERFORMANCE
  sim->Advance(sec,minTimeStep,maxTimeStep,NULL);
#else
  sim->Advance(sec,minTimeStep,maxTimeStep);
#endif
}

void SimulatorSetTerrainMesh(neSimulator * sim, neTriangleMesh * mesh){
  if (mesh) sim->SetTerrainMesh(mesh);
}
void SimulatorFreeTerrainMesh(neSimulator * sim){
  sim->FreeTerrainMesh();
}
neJoint * SimulatorCreateRigidBodyWorldJoint(neSimulator * sim, neRigidBody * bodyA){
  return sim->CreateJoint(bodyA);
}
neJoint * SimulatorCreateRigidBodyRigidBodyJoint(neSimulator * sim, neRigidBody * bodyA, neRigidBody * bodyB){
  return sim->CreateJoint(bodyA, bodyB);
}
neJoint * SimulatorCreateRigidBodyAnimatedBodyJoint(neSimulator * sim, neRigidBody * bodyA, neAnimatedBody * bodyB){
  return sim->CreateJoint(bodyA, bodyB);
}
void SimulatorFreeJoint(neSimulator * sim, neJoint * & joint){
  if(joint) {
    sim->FreeJoint(joint); joint=0;
  }
}

void SimulatorSetCollisionCallback(neSimulator * sim, neCollisionCallback * cb){
  sim->SetCollisionCallback(cb);
}
neCollisionCallback * SimulatorGetCollisionCallback(neSimulator * sim){
  return sim->GetCollisionCallback();
}

void SimulatorSetBreakageCallback(neSimulator * sim, neBreakageCallback * cb){
  sim->SetBreakageCallback(cb);
}
neBreakageCallback * SimulatorGetBreakageCallback(neSimulator * sim){
  return sim->GetBreakageCallback();
}

void SimulatorSetTerrainTriangleQueryCallback(neSimulator * sim, neTerrainTriangleQueryCallback * cb){
  sim->SetTerrainTriangleQueryCallback(cb);
}
neTerrainTriangleQueryCallback * SimulatorGetTerrainTriangleQueryCallback(neSimulator * sim){
  return sim->GetTerrainTriangleQueryCallback();
}

void SimulatorSetCustomCDRB2RBCallback(neSimulator * sim, neCustomCDRB2RBCallback * cb){
  sim->SetCustomCDRB2RBCallback(cb);
}
neCustomCDRB2RBCallback * SimulatorGetCustomCDRB2RBCallback(neSimulator * sim){
  return sim->GetCustomCDRB2RBCallback();
}

void SimulatorSetCustomCDRB2ABCallback(neSimulator * sim, neCustomCDRB2ABCallback * cb){
  sim->SetCustomCDRB2ABCallback(cb);
}
neCustomCDRB2ABCallback * SimulatorGetCustomCDRB2ABCallback(neSimulator * sim){
  return sim->GetCustomCDRB2ABCallback();
}

void SimulatorSetLogOutputCallback(neSimulator * sim, neLogOutputCallback * cb){
  sim->SetLogOutputCallback(cb);
}
neLogOutputCallback * SimulatorGetLogOutputCallback(neSimulator * sim){
  return sim->GetLogOutputCallback();
}

void SimulatorSetLogOutputLevel(neSimulator * sim, u32 level){
  sim->SetLogOutputLevel(level);
}
u32 SimulatorGetLogOutputLevel(neSimulator * sim){
  return sim->GetLogOutputLevel();
}

neSimulatorSizeInfo SimulatorGetCurrentSizeInfo(neSimulator * sim){
  return sim->GetCurrentSizeInfo();
}
neSimulatorSizeInfo SimulatorGetStartSizeInfo(neSimulator * sim){
  return sim->GetStartSizeInfo();
}
s32 SimulatorGetMemoryAllocated(neSimulator * sim){
  s32 memoryAllocated;
  sim->GetMemoryAllocated(memoryAllocated);
  return memoryAllocated;
}

s32 SimulatorGetIdleBodyCount(neSimulator * sim){
  return sim->GetIdleBodyCount();
}

neCollisionTable * SimulatorGetCollisionTable(neSimulator * sim){
  return sim->GetCollisionTable();
}

/*******************
* neCollisionTable *
*******************/
void CollisionTableSet(neCollisionTable * tbl, s32 collisionID1, s32 collisionID2, u32 response){
  tbl->Set(collisionID1, collisionID2, response);
}
u32 CollisionTableGet(neCollisionTable * tbl, s32 collisionID1, s32 collisionID2){
  return tbl->Get(collisionID1, collisionID2);
}
s32 CollisionTableGetMaxCollisionID(neCollisionTable * tbl){
  return tbl->GetMaxCollisionID();
}


/*************
* neGeometry *
*************/
u32 CAPI GeometryGetType(neGeometry * geo) {
  return geo->GetType();
}

void GeometrySetUserData(neGeometry * geo, void* userData){
  geo->SetUserData(userData);
}
void* GeometryGetUserData(neGeometry * geo){
  return geo->GetUserData();
}

void GeometrySetCubeSize(neGeometry * geo, f32 cubeSize){
  geo->SetBoxSize(cubeSize,cubeSize,cubeSize);
}
void GeometrySetBoxSize(neGeometry * geo, f32 width, f32 height, f32 depth){
  geo->SetBoxSize(width,height,depth);
}
bool GeometryGetBoxSize(neGeometry * geo, f32 & width, f32 & height, f32 & depth){
  bool ok = geo->GetBoxSize(gV3);
  width=gV3[0]; height=gV3[1]; depth=gV3[2];
  return ok;
}

void GeometrySetBoxSizeV3(neGeometry * geo, const neV3 & boxSize){
  geo->SetBoxSize(boxSize);
}
bool GeometryGetBoxSizeV3(neGeometry * geo, neV3 & boxSize){
  return geo->GetBoxSize(boxSize);
}

void GeometrySetSphereDiameter(neGeometry * geo, f32 diameter){
  geo->SetSphereDiameter(diameter);
}
bool GeometryGetSphereDiameter(neGeometry * geo, f32 & diameter){
  return geo->GetSphereDiameter(diameter);
}

void GeometrySetCapsule(neGeometry * geo, f32 diameter, f32 height){
  geo->SetCapsule(diameter, height);
}
bool GeometryGetCapsule(neGeometry * geo, f32 & diameter, f32 & height){
  return geo->GetCapsule(diameter, height);
}

void GeometrySetConvexMesh(neGeometry * geo, neByte * convexData){
  geo->SetConvexMesh(convexData);
}
bool GeometryGetConvexMesh(neGeometry * geo, neByte * & convexData){
  return geo->GetConvexMesh(convexData);
}

void GeometrySetPosition(neGeometry* geo, f32 x, f32 y, f32 z) {
  gT3 = geo->GetTransform();
  gT3.pos.Set(x,y,z); geo->SetTransform(gT3);
}
void GeometryGetPosition(neGeometry* geo, f32 & x, f32 & y, f32 & z) {
  gT3 = geo->GetTransform();
  x=gT3.pos[0]; y=gT3.pos[1]; z=gT3.pos[2];
}
void GeometrySetPositionV3(neGeometry* geo, const neV3 & position) {
  gT3 = geo->GetTransform();
  gT3.pos=position; geo->SetTransform(gT3);
}
neV3 GeometryGetPositionV3(neGeometry* geo) {
  gT3 = geo->GetTransform();
  return gT3.pos;
}



void GeometrySetPositionRotation(neGeometry* geo,
                                 f32 px, f32 py, f32 pz,
                                 f32 rp, f32 ry, f32 rr) {
  gV3.Set(NE_DEG_TO_RAD(rp), NE_DEG_TO_RAD(ry), NE_DEG_TO_RAD(rr));
  gT3.pos.Set(px,py,pz);
  gT3.rot.RotateXYZ(gV3);
  geo->SetTransform(gT3);
}
void GeometryGetPositionRotation(neGeometry* geo,
                                 f32 & px, f32 & py, f32 & pz,
                                 f32 & rp, f32 & ry, f32 & rr){
  gT3 = geo->GetTransform();
  gV3 = gT3.pos;
  //gM3 = gT3.rot;
  px = gV3[0]; py = gV3[1]; pz = gV3[2];
  M3GetRotAngle(gT3.rot,rp,ry,rr);
  //rp = NE_RAD_TO_DEG(gV3[0]);
  //ry = NE_RAD_TO_DEG(gV3[1]);
  //rr = NE_RAD_TO_DEG(gV3[2]);
}
void GeometrySetPositionRotationV3(neGeometry* geo, const neV3 & pos, const neV3 & rot) {
  gT3.pos = pos;
  gV3.Set(NE_DEG_TO_RAD(rot[0]), NE_DEG_TO_RAD(rot[1]), NE_DEG_TO_RAD(rot[2]));
  gT3.rot.RotateXYZ(gV3);
  geo->SetTransform(gT3);
}
void GeometryGetPositionRotationV3(neGeometry* geo, neV3 & pos, neV3 & rot){
  gT3 = geo->GetTransform();
  pos = gT3.pos;
  rot = M3GetRotAngleV3(gM3);
  //rot[0] = NE_RAD_TO_DEG(gV3[0]);
  //rot[1] = NE_RAD_TO_DEG(gV3[1]);
  //rot[2] = NE_RAD_TO_DEG(gV3[2]);
}


void GeometrySetTransform(neGeometry * geo, neT3 & t){
  geo->SetTransform(t);
}
neT3 GeometryGetTransform(neGeometry * geo){
  return geo->GetTransform();
}

void GeometrySetMaterialIndex(neGeometry * geo, s32 index){
  geo->SetMaterialIndex(index);
}
s32 GeometryGetMaterialIndex(neGeometry * geo){
  return geo->GetMaterialIndex();
}

void GeometrySetBreakageFlag(neGeometry * geo, u32 flag){
  geo->SetBreakageFlag(flag);
}
u32 GeometryGetBreakageFlag(neGeometry * geo){
  return geo->GetBreakageFlag();
}

void GeometrySetBreakageMass(neGeometry * geo, f32 mass){
  geo->SetBreakageMass(mass);
}
f32  GeometryGetBreakageMass(neGeometry * geo){
  return geo->GetBreakageMass();
}

void GeometrySetBreakageInertiaTensor(neGeometry * geo, f32 tx, f32 ty, f32 tz){
  gV3.Set(tx,ty,tz);
  geo->SetBreakageInertiaTensor(gV3);
}
void GeometryGetBreakageInertiaTensor(neGeometry * geo, f32 & tx, f32 & ty, f32 & tz){
  gV3 = geo->GetBreakageInertiaTensor();
  tx=gV3[0]; ty=gV3[1]; tz=gV3[2];
}

void GeometrySetBreakageInertiaTensorV3(neGeometry * geo, const neV3 & tensor){
  geo->SetBreakageInertiaTensor(tensor);
}
neV3 GeometryGetBreakageInertiaTensorV3(neGeometry * geo){
  return geo->GetBreakageInertiaTensor();
}

void GeometrySetBreakageMagnitude(neGeometry * geo, f32 mag){
  geo->SetBreakageMagnitude(mag);
}
f32  GeometryGetBreakageMagnitude(neGeometry * geo){
  return geo->GetBreakageMagnitude();
}

void GeometrySetBreakageAbsorption(neGeometry * geo, f32 absorb){
  geo->SetBreakageAbsorption(absorb);
}
f32  GeometryGetBreakageAbsorption(neGeometry * geo){
  return geo->GetBreakageAbsorption();
}

void GeometrySetBreakagePlane(neGeometry * geo, f32 nx, f32 ny, f32 nz){
  gV3.Set(nx,ny,nz);
  geo->SetBreakagePlane(gV3);
}
void GeometryGetBreakagePlane(neGeometry * geo, f32 & nx, f32 & ny, f32 & nz){
  gV3 = geo->GetBreakagePlane();
  nx=gV3[0]; ny=gV3[1]; nz=gV3[2];
}

void GeometrySetBreakagePlaneV3(neGeometry * geo, const neV3 & planeNormal){
  geo->SetBreakagePlane(planeNormal);
}
neV3 GeometryGetBreakagePlaneV3(neGeometry * geo){
  return geo->GetBreakagePlane();
}

void GeometrySetBreakageNeighbourRadius(neGeometry * geo, f32 radius){
  geo->SetBreakageNeighbourRadius(radius);
}
f32 GeometryGetBreakageNeighbourRadius(neGeometry * geo){
  return geo->GetBreakageNeighbourRadius();
}

void GeometryGetOpenGLMatrix(neGeometry* geo, f32 * p){
  gT3 = geo->GetTransform();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}
void GeometryGetInverseOpenGLMatrix(neGeometry* geo, f32 * p){
  gT3 = geo->GetTransform().FastInverse();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}

neV3 GeometryRotateVector(neGeometry* geo, const neV3 & v) {
  return geo->GetTransform().rot * v;
}
neV3 GeometryTransformVector(neGeometry* geo, const neV3 & v) {
  return geo->GetTransform() * v;
}
void GeometryRotateVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3 = geo->GetTransform().rot;
  for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
void GeometryTransformVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = geo->GetTransform();
  for (i=0;i<n;i++) { d[i] = gT3 * s[i];}
}
void GeometryInverseRotateVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3.SetInvert(geo->GetTransform().rot);
  for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
void GeometryInverseTransformVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = geo->GetTransform().FastInverse();
  for (i=0;i<n;i++) { d[i] = gT3 * s[i];}
}
/*****************
* neAnimatedBody *
*****************/
void AnimatedBodySetUserData(neAnimatedBody * ab, void* userData){
  ab->SetUserData(userData);
}
void* AnimatedBodyGetUserData(neAnimatedBody * ab){
  return ab->GetUserData();
}

void AnimatedBodySetPosition(neAnimatedBody * ab, f32   x, f32   y, f32   z){
  gV3.Set(x,y,z); ab->SetPos(gV3);
}
void AnimatedBodyGetPosition(neAnimatedBody * ab, f32 & x, f32 & y, f32 & z){
  gT3 = ab->GetTransform();
  gV3 = gT3.pos;
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}

void AnimatedBodySetPositionV3(neAnimatedBody * ab, const neV3 & p){
  ab->SetPos(p);
}
neV3 AnimatedBodyGetPositionV3(neAnimatedBody * ab){
  return ab->GetPos();
}

void AnimatedBodySetRotation(neAnimatedBody* ab, f32 p, f32 y, f32 r) {
  gV3.Set( NE_DEG_TO_RAD(p), NE_DEG_TO_RAD(y), NE_DEG_TO_RAD(r) );
  gM3.RotateXYZ(gV3);
  ab->SetRotationM3(gM3);
}
void AnimatedBodyGetRotation(neAnimatedBody* ab, f32 & rp, f32 & ry, f32 & rr) {
  gM3 = ab->GetRotationM3();
  M3GetRotAngle(gM3,rp,ry,rr);
}

void AnimatedBodySetRotationV3(neAnimatedBody* ab, const neV3 & rot) {
  gV3.Set( NE_DEG_TO_RAD(rot[0]), NE_DEG_TO_RAD(rot[1]), NE_DEG_TO_RAD(rot[2]) );
  gM3.RotateXYZ(gV3);
  ab->SetRotationM3(gM3);
}
neV3 AnimatedBodyGetRotationV3(neAnimatedBody* ab) {
  gM3 = ab->GetRotationM3();
  gV3 = M3GetRotAngleV3(gM3);
  return gV3;
}

void AnimatedBodySetRotationM3(neAnimatedBody * ab, const neM3 & m){
  ab->SetRotationM3(m);
}
neM3 AnimatedBodyGetRotationM3(neAnimatedBody * ab){
  return ab->GetRotationM3();
}

void AnimatedBodySetRotationQ(neAnimatedBody * ab, const neQ & q){
  ab->SetRotationQ(q);
}
neQ AnimatedBodyGetRotationQ(neAnimatedBody * ab){
  return ab->GetRotationQ();
}

//! rotation in degree
void AnimatedBodySetPositionRotation(neAnimatedBody* ab,
                                     f32 px, f32 py, f32 pz,
                                     f32 rp, f32 ry, f32 rr) {

  gV3.Set(px, py, pz);
  ab->SetPos(gV3);
  gV3.Set(NE_DEG_TO_RAD(rp),NE_DEG_TO_RAD(ry),NE_DEG_TO_RAD(rr));
  gM3.RotateXYZ(gV3);
  ab->SetRotationM3(gM3);
}
void AnimatedBodyGetPositionRotation(neAnimatedBody* ab,
                                     f32 & px, f32 & py, f32 & pz,
                                     f32 & rp, f32 & ry, f32 & rr){
  gV3 = ab->GetPos();
  px=gV3[0]; py=gV3[1]; pz=gV3[2];
  gM3 = ab->GetRotationM3();
  M3GetRotAngle(gM3,rp,ry,rr);
  //rx = NE_RAD_TO_DEG(gV3[0]);
  //ry = NE_RAD_TO_DEG(gV3[1]);
  //rz = NE_RAD_TO_DEG(gV3[2]);
}
void AnimatedBodySetPositionRotationV3(neAnimatedBody* ab, const neV3 & pos, const neV3 & rot) {
  gV3.Set(NE_DEG_TO_RAD(rot[0]),NE_DEG_TO_RAD(rot[1]),NE_DEG_TO_RAD(rot[2]));
  gM3.RotateXYZ(gV3);
  ab->SetPos(pos);
  ab->SetRotationM3(gM3);
}
void AnimatedBodyGetPositionRotationV3(neAnimatedBody* ab, neV3 & pos, neV3 & rot){
  pos = ab->GetPos();
  gM3 = ab->GetRotationM3();
  rot = M3GetRotAngleV3(gM3);
  //rot[0] = NE_RAD_TO_DEG(gV3[0]);
  //rot[1] = NE_RAD_TO_DEG(gV3[1]);
  //rot[2] = NE_RAD_TO_DEG(gV3[2]);
}

void AnimatedBodySetTransform(neAnimatedBody * ab, const neT3 & t){
  ab->SetPos(t.pos); ab->SetRotationM3(t.rot);
}
neT3 AnimatedBodyGetTransform(neAnimatedBody * ab){
  return ab->GetTransform();
}

void AnimatedBodySetCollisionID(neAnimatedBody * ab, s32 cid){
  ab->SetCollisionID(cid);
}
s32 AnimatedBodyGetCollisionID(neAnimatedBody * ab){
  return ab->GetCollisionID();
}

s32 AnimatedBodyGetGeometryCount(neAnimatedBody * ab){
  return ab->GetGeometryCount();
}

void AnimatedBodyUpdateBoundingInfo(neAnimatedBody * ab){
  ab->UpdateBoundingInfo();
}

void AnimatedBodySetCollideConnected(neAnimatedBody * ab, bool yes){
  ab->CollideConnected(yes);
}
bool AnimatedBodyGetCollideConnected(neAnimatedBody * ab){
  return ab->CollideConnected();
}

void AnimatedBodySetCollideDirectlyConnected(neAnimatedBody * ab, bool yes){
  ab->CollideDirectlyConnected(yes);
}
bool AnimatedBodyGetCollideDirectlyConnected(neAnimatedBody * ab){
  return ab->CollideDirectlyConnected();
}

neGeometry * AnimatedBodyAddGeometry(neAnimatedBody * ab){
  return ab->AddGeometry();
}
bool AnimatedBodyRemoveGeometry(neAnimatedBody * ab, neGeometry * geo){
  return ab->RemoveGeometry(geo);
}

void AnimatedBodyBeginIterateGeometry(neAnimatedBody * ab){
  ab->BeginIterateGeometry();
}
neGeometry * AnimatedBodyGetNextGeometry(neAnimatedBody * ab){
  return ab->GetNextGeometry();
}

neRigidBody * AnimatedBodyBreakGeometry(neAnimatedBody * ab, neGeometry * geo){
  return ab->BreakGeometry(geo);
}

void AnimatedBodySetUseCustomCollisionDetection(neAnimatedBody * ab, bool yes,  const neT3 * obb, f32 boundingRadius){
  ab->UseCustomCollisionDetection(yes,obb,boundingRadius);
}
bool AnimatedBodyGetUseCustomCollisionDetection(neAnimatedBody * ab){
  return ab->UseCustomCollisionDetection();
}
#ifndef NO_ANIMATED_SENSOR
neSensor * AnimatedBodyAddSensor(neAnimatedBody * ab){
  return ab->AddSensor();
}
bool AnimatedBodyRemoveSensor(neAnimatedBody * ab, neSensor * sen){
  return ab->RemoveSensor(sen);
}
void AnimatedBodyBeginIterateSensor(neAnimatedBody * ab){
  ab->BeginIterateSensor();
}
neSensor * AnimatedBodyGetNextSensor(neAnimatedBody * ab){
  return ab->GetNextSensor();
}
#endif
void AnimatedBodySetActive(neAnimatedBody * ab, bool yes){
  ab->Active(yes,(neRigidBody *)0);
}
bool AnimatedBodyGetActive(neAnimatedBody * ab){
  return ab->Active();
}
void AnimatedBodySetActiveWithRigidBodyHint(neAnimatedBody * ab, bool yes, neRigidBody * hint){
  ab->Active(yes,hint);
}
void AnimatedBodySetActiveWithAnimatedBodyHint(neAnimatedBody * ab, bool yes, neAnimatedBody * hint){
  ab->Active(yes,hint);
}

void AnimatedBodyGetOpenGLMatrix(neAnimatedBody* ab, f32 * p) {
  gT3 = ab->GetTransform();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}
void AnimatedBodyGetInverseOpenGLMatrix(neAnimatedBody* ab, f32 * p) {
  gT3 = ab->GetTransform().FastInverse();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}

neV3 AnimatedBodyRotateVector(neAnimatedBody* ab, const neV3 & v) {
  return ab->GetTransform().rot * v;
}
neV3 AnimatedBodyTransformVector(neAnimatedBody* ab, const neV3 & v) {
  return ab->GetTransform()*v;
}
void AnimatedBodyRotateVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3 = ab->GetTransform().rot;
  for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
void AnimatedBodyTransformVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = ab->GetTransform();
  for (i=0;i<n;i++) { d[i] = gT3 * s[i];}
}
void AnimatedBodyInverseRotateVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3.SetInvert(ab->GetTransform().rot);
  for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
void AnimatedBodyInverseTransformVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = ab->GetTransform().FastInverse();
  for (i=0;i<n;i++) { d[i] = gT3 * s[i];}
}

/**************
* neRigidBody *
**************/
void RigidBodySetUserData(neRigidBody* rb, void* userData){
  rb->SetUserData(userData);
}
void* RigidBodyGetUserData(neRigidBody* rb){
  return rb->GetUserData();
}

void RigidBodySetMass(neRigidBody* rb, f32 mass){
  if (mass<1.0f) mass=1.0f; /// !!! added:
  rb->SetMass(mass);
}
f32 RigidBodyGetMass(neRigidBody* rb){
  return rb->GetMass();
}

void RigidBodySetInertiaTensor(neRigidBody* rb, f32 tx, f32 ty, f32 tz){
  gV3.Set(tx,ty,tz); rb->SetInertiaTensor(gV3);
}
void RigidBodySetInertiaTensorV3(neRigidBody* rb, const neV3 & tensor){
  rb->SetInertiaTensor(tensor);
}
void RigidBodySetInertiaTensorM3(neRigidBody* rb, const neM3 & tensor){
  rb->SetInertiaTensor(tensor);
}

void RigidBodySetPosition(neRigidBody* rb, f32 x, f32 y, f32 z) {
  gV3.Set(x,y,z); rb->SetPos(gV3);
}
void RigidBodyGetPosition(neRigidBody* rb, f32 & x, f32 & y, f32 & z) {
  gV3 = rb->GetPos();
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}

void RigidBodySetPositionV3(neRigidBody* rb, const neV3 & p){
  rb->SetPos(p);
}
neV3 RigidBodyGetPositionV3(neRigidBody* rb){
  return rb->GetPos();
}

void RigidBodySetRotation(neRigidBody* rb, f32 rp, f32 ry, f32 rr) {
  gV3.Set(NE_DEG_TO_RAD(rp),NE_DEG_TO_RAD(ry),NE_DEG_TO_RAD(rr));
  gM3.RotateXYZ(gV3);
  rb->SetRotationM3(gM3);
}
void RigidBodyGetRotation(neRigidBody* rb, f32 & rp, f32 & ry, f32 & rr) {
  gM3 = rb->GetRotationM3();
  M3GetRotAngle(gM3,rp,ry,rr);
}

void RigidBodySetRotationV3(neRigidBody* rb, const neV3 & rot) {
  gV3.Set( NE_DEG_TO_RAD(rot[0]),NE_DEG_TO_RAD(rot[1]),NE_DEG_TO_RAD(rot[2]) );
  gM3.RotateXYZ(gV3);
  rb->SetRotationM3(gM3);
}
neV3 RigidBodyGetRotationV3(neRigidBody* rb) {
  gM3 = rb->GetRotationM3();
  return M3GetRotAngleV3(gM3);
}

void RigidBodySetRotationM3(neRigidBody* rb, const neM3 & m3){
  rb->SetRotationM3(m3);
}
neM3 RigidBodyGetRotationM3(neRigidBody* rb){
  return rb->GetRotationM3();
}

void RigidBodySetRotationQ(neRigidBody* rb, const neQ & q){
  rb->SetRotationQ(q);
}
neQ RigidBodyGetRotationQ(neRigidBody* rb){
  return rb->GetRotationQ();
}
//! rotation in degree
void RigidBodySetPositionRotation(neRigidBody* rb,
                                  f32 px, f32 py, f32 pz,
                                  f32 rp, f32 ry, f32 rr) {
  gV3.Set(NE_DEG_TO_RAD(rp),NE_DEG_TO_RAD(ry),NE_DEG_TO_RAD(rr));
  gM3.RotateXYZ(gV3);
  gV3.Set(px,py,pz);
  rb->SetPos(gV3);
  rb->SetRotationM3(gM3);
}
void RigidBodyGetPositionRotation(neRigidBody* rb,
                                  f32 & px, f32 & py, f32 & pz,
                                  f32 & rp, f32 & ry, f32 & rr){
  gV3 = rb->GetPos();
  px = gV3[0];
  py = gV3[1];
  pz = gV3[2];
  gM3 = rb->GetRotationM3();
  M3GetRotAngle(gM3,rp,ry,rr);
}
void RigidBodySetPositionRotationV3(neRigidBody* rb, const neV3 & pos, const neV3 & rot) {
  rb->SetPos(pos);
  gV3.Set(NE_DEG_TO_RAD(rot[0]),NE_DEG_TO_RAD(rot[1]),NE_DEG_TO_RAD(rot[2]));
  gM3.RotateXYZ(gV3);
  rb->SetRotationM3(gM3);
}
void RigidBodyGetPositionRotationV3(neRigidBody* rb, neV3 & pos, neV3 & rot){
  pos = rb->GetPos();
  gM3 = rb->GetRotationM3();
  rot = M3GetRotAngleV3(gM3);
}

neT3 RigidBodyGetTransform(neRigidBody* rb){
  return rb->GetTransform();
}

void RigidBodySetCollisionID(neRigidBody* rb, s32 cid){
  rb->SetCollisionID(cid);
}
s32 RigidBodyGetCollisionID(neRigidBody* rb){
  return rb->GetCollisionID();
}

s32 RigidBodyGetGeometryCount(neRigidBody* rb){
  return rb->GetGeometryCount();
}

void RigidBodySetLinearDamping(neRigidBody* rb, f32 damp){
  rb->SetLinearDamping(damp);
}
f32 RigidBodyGetLinearDamping(neRigidBody* rb){
  return rb->GetLinearDamping();
}

void RigidBodySetAngularDamping(neRigidBody* rb, f32 damp){
  rb->SetAngularDamping(damp);
}
f32 RigidBodyGetAngularDamping(neRigidBody* rb){
  return rb->GetAngularDamping();
}

void RigidBodySetSleepingParameter(neRigidBody* rb, f32 sleepingParam){
  rb->SetSleepingParameter(sleepingParam);
}
f32 RigidBodyGetSleepingParameter(neRigidBody* rb){
  return rb->GetSleepingParameter();
}

void RigidBodySetVelocity(neRigidBody* rb, f32 vx, f32 vy, f32 vz){
  gV3.Set(vx,vy,vz);
  rb->SetVelocity(gV3);
}
void RigidBodyGetVelocity(neRigidBody* rb, f32 & vx, f32 & vy, f32 & vz){
  gV3 = rb->GetVelocity();
  vx=gV3[0]; vy=gV3[1]; vz=gV3[2];
}

void RigidBodySetVelocityV3(neRigidBody* rb, const neV3 & v){
  rb->SetVelocity(v);
}
neV3 RigidBodyGetVelocityV3(neRigidBody* rb){
  return rb->GetVelocity();
}

void RigidBodyGetVelocityAtPoint(neRigidBody* rb,
                                 f32 px, f32 py, f32 pz,
                                 f32 & vx, f32 & vy, f32 & vz){
  gV3.Set(px,py,pz);
  gV3 = rb->GetVelocityAtPoint(gV3);
  vx=gV3[0]; vy=gV3[1]; vz=gV3[2];
}
neV3 RigidBodyGetVelocityAtPointV3(neRigidBody* rb, const neV3 & pt){
  return rb->GetVelocityAtPoint(pt);
}
void RigidBodyGetAngularVelocity(neRigidBody* rb,f32 & vx, f32 & vy, f32 & vz){
  gV3 = rb->GetAngularVelocity();
  vx=gV3[0]; vy=gV3[1]; vz=gV3[2];
}
neV3 RigidBodyGetAngularVelocityV3(neRigidBody* rb){
  return rb->GetAngularVelocity();
}
void RigidBodySetAngularMomentum(neRigidBody* rb, f32 mx, f32 my, f32 mz){
  gV3.Set(mx,my,mz);
  rb->SetAngularMomentum(gV3);
}
void RigidBodyGetAngularMomentum(neRigidBody* rb, f32 & mx, f32 & my, f32 & mz){
  gV3 = rb->GetAngularMomentum();
  mx=gV3[0]; my=gV3[1]; mz=gV3[2];
}

void RigidBodySetAngularMomentumV3(neRigidBody* rb, const neV3& am){
  rb->SetAngularMomentum(am);
}
neV3 RigidBodyGetAngularMomentumV3(neRigidBody* rb){
  return rb->GetAngularMomentum();
}

void RigidBodyUpdateBoundingInfo(neRigidBody* rb){
  rb->UpdateBoundingInfo();
}

void RigidBodyUpdateInertiaTensor(neRigidBody* rb){
  rb->UpdateInertiaTensor();
}

void RigidBodySetForce(neRigidBody* rb, f32 fx, f32 fy, f32 fz){
  gV3.Set(fx,fy,fz);
  rb->SetForce(gV3);
}
void RigidBodyGetForce(neRigidBody* rb, f32 & fx, f32 & fy, f32 & fz){
  gV3 = rb->GetForce();
  fx=gV3[0]; fy=gV3[1]; fz=gV3[2];
}

void RigidBodySetForceV3(neRigidBody* rb, const neV3 & force){
  rb->SetForce(force);
}
neV3 RigidBodyGetForceV3(neRigidBody* rb){
  return rb->GetForce();
}

void RigidBodySetForceAtPosition(neRigidBody* rb,
                                 f32 fx, f32 fy, f32 fz,
                                 f32 px, f32 py, f32 pz){
  neV3 force; force.Set(fx,fy,fz);
  gV3.Set(px,py,pz);
  rb->SetForce(force,gV3);
}
void RigidBodySetForceAtPositionV3(neRigidBody* rb, const neV3 & force, const neV3 & pos){
  rb->SetForce(force, pos);
}

void CAPI RigidBodySetTorque(neRigidBody* rb, f32 tx, f32 ty, f32 tz){
  gV3.Set(tx,ty,tz); rb->SetTorque(gV3);
}
void CAPI RigidBodyGetTorque(neRigidBody* rb, f32 & tx, f32 & ty, f32 & tz){
  gV3 = rb->GetTorque(); tx = gV3[0]; ty=gV3[1]; tz=gV3[2];
}
void RigidBodySetTorqueV3(neRigidBody* rb, const neV3 & torque){
  rb->SetTorque(torque);
}
neV3 RigidBodyGetTorqueV3(neRigidBody* rb){
  return rb->GetTorque();
}

void RigidBodyApplyImpulse(neRigidBody* rb, f32 ix, f32 iy, f32 iz){
  gV3.Set(ix,iy,iz);
  rb->ApplyImpulse(gV3);
}
void RigidBodyApplyImpulseV3(neRigidBody* rb, const neV3 & impulse){
  rb->ApplyImpulse(impulse);
}

void CAPI RigidBodyApplyImpulseAtPosition(neRigidBody* rb,
                                          f32 ix, f32 iy, f32 iz,
                                          f32 px, f32 py, f32 pz){
  neV3 impulse; impulse.Set(ix,iy,iz); gV3.Set(px,py,pz);
  rb->ApplyImpulse(impulse, gV3);
}
void RigidBodyApplyImpulseAtPositionV3(neRigidBody* rb, const neV3 & impulse, const neV3 & pos){
  rb->ApplyImpulse(impulse, pos);
}

void CAPI RigidBodyApplyTwist(neRigidBody* rb, f32 tx, f32 ty, f32 tz){
  gV3.Set(tx,ty,tz);
  rb->ApplyTwist(gV3);
}
void RigidBodyApplyTwistV3(neRigidBody* rb, const neV3 & twist){
  rb->ApplyTwist(twist);
}

void RigidBodyGravityEnable(neRigidBody* rb, bool yes){
  rb->GravityEnable(yes);
}
bool RigidBodyGravityIsOn(neRigidBody* rb){
  return rb->GravityEnable();
}

void RigidBodySetCollideConnected(neRigidBody* rb, bool yes){
  rb->CollideConnected(yes);
}
bool RigidBodyGetCollideConnected(neRigidBody* rb){
  return rb->CollideConnected();
}

void RigidBodySetCollideDirectlyConnected(neRigidBody* rb, bool yes){
  rb->CollideDirectlyConnected(yes);
}
bool RigidBodyGetCollideDirectlyConnected(neRigidBody* rb){
  return rb->CollideDirectlyConnected();
}

neGeometry * RigidBodyAddGeometry(neRigidBody* rb){
  return rb->AddGeometry();
}
bool RigidBodyRemoveGeometry(neRigidBody* rb, neGeometry * geo){
  return rb->RemoveGeometry(geo);
}

void RigidBodyBeginIterateGeometry(neRigidBody* rb){
  rb->BeginIterateGeometry();
}
neGeometry * RigidBodyGetNextGeometry(neRigidBody* rb){
  return rb->GetNextGeometry();
}

neRigidBody * RigidBodyBreakGeometry(neRigidBody* rb, neGeometry * geo){
  return rb->BreakGeometry(geo);
}

void RigidBodySetUseCustomCollisionDetection(neRigidBody* rb, bool yes, const neT3 * obb, f32 boundingRadius){
  rb->UseCustomCollisionDetection(yes,obb,boundingRadius);
}
bool RigidBodyGetUseCustomCollisionDetection(neRigidBody* rb){
  return rb->UseCustomCollisionDetection();
}

neSensor * RigidBodyAddSensor(neRigidBody* rb){
  return rb->AddSensor();
}
bool RigidBodyRemoveSensor(neRigidBody* rb, neSensor * sen){
  return rb->RemoveSensor(sen);
}

void RigidBodyBeginIterateSensor(neRigidBody* rb){
  rb->BeginIterateSensor();
}
neSensor * RigidBodyGetNextSensor(neRigidBody* rb){
  return rb->GetNextSensor();
}

void RigidBodySetActive(neRigidBody* rb, bool yes){
  rb->Active(yes,(neRigidBody *)0);
}
bool RigidBodyGetActive(neRigidBody* rb){
  return (rb->Active()!=0);
}
void RigidBodySetActiveWithRigidBodyHint(neRigidBody* rb, bool yes, neRigidBody * hint){
  rb->Active(yes, hint);
}
void RigidBodySetActiveWithAnimatedBodyHint(neRigidBody* rb, bool yes, neAnimatedBody * hint){
  rb->Active(yes, hint);
}

bool RigidBodyIsIdle(neRigidBody* rb){
  return (rb->IsIdle()!=0);
}
void RigidBodyWakeUp(neRigidBody* rb){
  rb->WakeUp();
}
bool RigidBodyIsParticle(neRigidBody* rb){
  return (rb->IsParticle()!=0);
}
void RigidBodyGetOpenGLMatrix(neRigidBody* rb, f32 * p) {
  gT3 = rb->GetTransform();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}
void RigidBodyGetInverseOpenGLMatrix(neRigidBody* rb, f32 * p) {
  gT3 = rb->GetTransform().FastInverse();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}

neV3 RigidBodyRotateVector(neRigidBody* rb, const neV3 & v) {
  return rb->GetTransform().rot * v;
}
neV3 RigidBodyTransformVector(neRigidBody* rb, const neV3 & v) {
  return rb->GetTransform() * v;
}

void RigidBodyRotateVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3 = rb->GetTransform().rot;
  for (i=0; i<n; i++) { d[i] = gM3 * s[i]; }
}
void RigidBodyTransformVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = rb->GetTransform();
  for (i=0; i<n; i++) { d[i] = gT3 * s[i]; }
}
void RigidBodyInverseRotateVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3.SetInvert(rb->GetTransform().rot);
  for (i=0; i<n; i++) { d[i] = gM3 * s[i]; }
}
void RigidBodyInverseTransformVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = rb->GetTransform().FastInverse();
  for (i=0; i<n; i++) { d[i] = gT3 * s[i]; }
}
/************************
* neRigidBodyController *
************************/
neRigidBodyController * RigidBodyAddController(neRigidBody* rb, RigidBodyControllerCallback * rbccb, s32 period){
  return rb->AddController(rbccb, period);
}
bool RigidBodyRemoveController(neRigidBody* rb, neRigidBodyController * controller){
  return rb->RemoveController(controller);
}
void RigidBodyBeginIterateController(neRigidBody* rb){
  rb->BeginIterateController();
}
neRigidBodyController * RigidBodyGetNextController(neRigidBody* rb){
  return rb->GetNextController();
}

neRigidBody * RigidBodyControllerGetRigidBody(neRigidBodyController * controller){
  return controller->GetRigidBody();
}
/******************************
* neRigidBodyController Force *
******************************/
void RigidBodyControllerSetForce(neRigidBodyController * controller, f32 fx, f32 fy, f32 fz){
  gV3.Set(fx,fy,fz); controller->SetControllerForceV3(gV3);
}
void RigidBodyControllerGetForce(neRigidBodyController * controller, f32 & fx, f32 & fy, f32 &fz){
  gV3 = controller->GetControllerForceV3();
  fx=gV3[0]; fy=gV3[1]; fz=gV3[2];
}
void RigidBodyControllerSetForceV3(neRigidBodyController * controller, const neV3 & force){
  controller->SetControllerForceV3(force);
}
neV3 RigidBodyControllerGetForceV3(neRigidBodyController * controller){
  return controller->GetControllerForceV3();
}
void RigidBodyControllerSetForceWithTorque(neRigidBodyController * controller,
                                           f32 fx, f32 fy, f32 fz,
                                           f32 px, f32 py, f32 pz){
  neV3 position;
  gV3.Set(fx, fy, fz);
  position.Set(px, py, pz);
  controller->SetControllerForceWithTorqueV3(gV3, position);
}
/*******************************
* neRigidBodyController Torque *
*******************************/
void RigidBodyControllerSetTorque(neRigidBodyController * controller, f32 tx, f32 ty, f32 tz){
  gV3.Set(tx,ty,tz); controller->SetControllerTorqueV3(gV3);
}
void RigidBodyControllerGetTorque(neRigidBodyController * controller, f32 & tx, f32 & ty, f32 & tz){
  gV3 = controller->GetControllerTorqueV3();
  tx=gV3[0]; ty=gV3[1]; tz=gV3[2];
}
void RigidBodyControllerSetTorqueV3(neRigidBodyController * controller, const neV3 & torque){
  controller->SetControllerTorqueV3(torque);
}
neV3 RigidBodyControllerGetTorqueV3(neRigidBodyController * controller){
  return controller->GetControllerTorqueV3();
}
void RigidBodyControllerSetForceWithTorqueV3(neRigidBodyController * controller, const neV3 & force, const neV3 & position){
  controller->SetControllerForceWithTorqueV3(force, position);
}

/***********
* neSensor *
***********/
void SensorSetUserData(neSensor* sensor, void* userData){
  sensor->SetUserData(userData);
}
void* SensorGetUserData(neSensor* sensor){
  return sensor->GetUserData();
}
void SensorSetLineSensor(neSensor* sensor,
                         f32 sx, f32 sy, f32 sz,
                         f32 ex, f32 ey, f32 ez) {
  neV3 e; gV3.Set(sx,sy,sz); e.Set(ex,ey,ez);
  sensor->SetLineSensor(gV3, e);
}
void SensorSetLineSensorV3(neSensor* sensor, const neV3 & s, const neV3 & e){
  sensor->SetLineSensor(s, e);
}
void SensorGetLinePosition(neSensor* sensor, f32 & x, f32 & y, f32 & z){
  gV3 = sensor->GetLinePos();
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}
neV3 SensorGetLinePositionV3(neSensor* sensor){
  return sensor->GetLinePos();
}
void SensorGetLineVector(neSensor* sensor, f32 & x, f32 & y, f32 & z){
  gV3 = sensor->GetLineVector();
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}
neV3 SensorGetLineVectorV3(neSensor* sensor){
  return sensor->GetLineVector();
}

void SensorGetLineUnitVector(neSensor* sensor, f32 & x, f32 & y, f32 & z){
  gV3 = sensor->GetLineUnitVector();
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}
neV3 SensorGetLineUnitVectorV3(neSensor* sensor){
  return sensor->GetLineUnitVector();
}

f32 SensorGetDetectDepth(neSensor* sensor){
  return sensor->GetDetectDepth();
}

void SensorGetDetectNormal(neSensor* sensor, f32 & nx, f32 & ny, f32 & nz){
  gV3 = sensor->GetDetectNormal();
  nx=gV3[0]; ny=gV3[1]; nz=gV3[2];
}
neV3 SensorGetDetectNormalV3(neSensor* sensor){
  return sensor->GetDetectNormal();
}

void SensorGetDetectContactPoint(neSensor* sensor, f32 & x, f32 & y, f32 & z){
  gV3 = sensor->GetDetectContactPoint();
  x=gV3[0]; y=gV3[1]; z=gV3[2];
}
neV3 SensorGetDetectContactPointV3(neSensor* sensor){
  return sensor->GetDetectContactPoint();
}
neRigidBody * SensorGetDetectRigidBody(neSensor* sensor){
  return sensor->GetDetectRigidBody();
}
neAnimatedBody * SensorGetDetectAnimatedBody(neSensor* sensor){
  return sensor->GetDetectAnimatedBody();
}
s32 SensorGetDetectMaterial(neSensor* sensor){
  return sensor->GetDetectMaterial();
}

/**********
* neJoint *
**********/
void JointSetType(neJoint * joint, u32 t){
  joint->SetType((neJoint::ConstraintType)t);
}
u32 JointGetType(neJoint * joint){
  return (u32)joint->GetType();
}

void JointSetUserData(neJoint * joint, void* userData){
  joint->SetUserData(userData);
}
void* JointGetUserData(neJoint * joint){
  return joint->GetUserData();
}

neRigidBody * JointGetRigidBodyA(neJoint * joint){
  return joint->GetRigidBodyA();
}
neRigidBody * JointGetRigidBodyB(neJoint * joint){
  return joint->GetRigidBodyB();
}
neAnimatedBody * JointGetAnimatedBodyB(neJoint * joint){
  return joint->GetAnimatedBodyB();
}
/// joint world frame
void JointSetFrameWorld(neJoint * joint, const neT3 & frame) {
  joint->SetJointFrameWorld(frame);
}
void JointSetPositionRotationFrameWorld(neJoint * joint,
                                        f32 px, f32 py, f32 pz,
                                        f32 rp, f32 ry, f32 rr) {
  gT3.pos.Set(px, py, pz); gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrix( rp, ry, rr );
  joint->SetJointFrameWorld(gT3);
}
void JointSetPositionRotationFrameWorldV3(neJoint * joint, const neV3 & pos, const neV3 & rot) {
  gT3.pos = pos;  gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrixV3(rot);
  joint->SetJointFrameWorld(gT3);
}
/// joint frame A
void JointSetFrameA(neJoint * joint, const neT3 & frame) {
  joint->SetJointFrameA(frame);
}
neT3 JointGetFrameA(neJoint * joint){
  return joint->GetJointFrameA();
}
void JointSetPositionRotationFrameA(neJoint * joint,
                                    f32 px,f32 py,f32 pz,
                                    f32 rp,f32 ry,f32 rr){
  gT3.pos.Set(px, py, pz); gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrix( rp, ry, rr );
  joint->SetJointFrameA(gT3);
}
void JointSetPositionRotationFrameAV3(neJoint * joint,  const neV3 & pos, const neV3 & rot) {
  gT3.pos = pos; gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrixV3(rot);
  joint->SetJointFrameA(gT3);
}
/// joint frame B
void JointSetFrameB(neJoint * joint, const neT3 & frameB) {
  joint->SetJointFrameB(frameB);
}
neT3 JointGetFrameB(neJoint * joint){
  return joint->GetJointFrameB();
}
void JointSetPositionRotationFrameB(neJoint * joint,
                                    f32 px, f32 py, f32 pz,
                                    f32 rp, f32 ry, f32 rr){
  gT3.pos.Set(px, py, pz); gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrix( rp, ry, rr );
  joint->SetJointFrameB(gT3);
}
void JointSetPositionRotationFrameBV3(neJoint * joint, const neV3 & pos, const neV3 & rot) {
  gT3.pos = pos;  gT3.pos.v[3] = 0;
  gT3.rot = CreateRotMatrixV3(rot);
  joint->SetJointFrameB(gT3);
}



void JointSetJointLength(neJoint * joint, f32 length){
  joint->SetJointLength(length);
}
f32 JointGetJointLength(neJoint * joint){
  return joint->GetJointLength();
}

void JointEnable(neJoint * joint, bool yes){
  joint->Enable(yes);
}
bool JointIsEnabled(neJoint * joint){
  return joint->IsEnabled();
}

void JointSetDampingFactor(neJoint * joint, f32 factor){
  joint->SetDampingFactor(factor);
}
f32 JointGetDampingFactor(neJoint * joint){
  return joint->GetDampingFactor();
}

void JointSetEpsilon(neJoint * joint, f32 epsilon){
  joint->SetEpsilon(epsilon);
}
f32 JointGetEpsilon(neJoint * joint){
  return joint->GetEpsilon();
}

void JointSetIteration(neJoint * joint, s32 iteration){
  joint->SetIteration(iteration);
}
s32 JointGetIteration(neJoint * joint){
  return joint->GetIteration();
}

/// joint limits
void JointSetLowerLimit(neJoint * joint, f32 limit){
  joint->SetLowerLimit(limit);
}
f32 JointGetLowerLimit(neJoint * joint){
  return joint->GetLowerLimit();
}
void JointSetUpperLimit(neJoint * joint, f32 limit){
  joint->SetUpperLimit(limit);
}
f32 JointGetUpperLimit(neJoint * joint){
  return joint->GetUpperLimit();
}
void JointLimitEnable(neJoint * joint, bool yes){
  joint->EnableLimit(yes);
}
bool JointIsLimitEnabled(neJoint * joint){
  return joint->EnableLimit();
}
/// ball-socket joint second limit
void JointSetLowerLimit2(neJoint * joint, f32 limit){
  joint->SetLowerLimit2(limit);
}
f32 JointGetLowerLimit2(neJoint * joint){
  return joint->GetLowerLimit2();
}
void JointSetUpperLimit2(neJoint * joint, f32 limit){
  joint->SetUpperLimit2(limit);
}
f32 JointGetUpperLimit2(neJoint * joint){
  return joint->GetUpperLimit2();
}
void JointLimit2Enable(neJoint * joint, bool yes){
  joint->EnableLimit2(yes);
}
bool JointIsLimit2Enabled(neJoint * joint){
  return (joint->EnableLimit2()!=0);
}

/// hinge joint motor
void JointMotorEnable(neJoint * joint, bool yes){
  joint->EnableMotor(yes);
}
bool JointIsMotorEnabled(neJoint * joint){
  return (joint->EnableMotor()!=0);
}
void JointSetMotor(neJoint * joint, f32 desireValue, f32 maxForce){
  joint->SetMotor(desireValue, maxForce);
}
void JointGetMotor(neJoint * joint, f32 & desireValue, f32 & maxForce){
 joint->GetMotor(desireValue, maxForce);
}

/********************
* neJointController *
********************/
neJointController * JointAddController(neJoint * joint, JointControllerCallback * jccb, s32 period){
  return joint->AddController(jccb, period);
}
bool JointRemoveController(neJoint * joint, neJointController * controller){
  return (joint->RemoveController(controller)!=0);
}
void JointBeginIterateController(neJoint * joint){
  joint->BeginIterateController();
}
neJointController * JointGetNextController(neJoint * joint){
  return joint->GetNextController();
}

neJoint * JointControllerGetJoint(neJointController * controller){
  return controller->GetJoint();
}

void JointControllerSetForceBodyAV3(neJointController * controller, const neV3 & force){
  controller->SetControllerForceBodyAV3(force);
}
neV3 JointControllerGetForceBodyAV3(neJointController * controller){
  return controller->GetControllerForceBodyAV3();
}

void JointControllerSetForceBodyBV3(neJointController * controller, const neV3 & force){
  controller->SetControllerForceBodyBV3(force);
}
neV3 JointControllerGetForceBodyBV3(neJointController * controller){
  return controller->GetControllerForceBodyBV3();
}

void JointControllerSetTorqueBodyAV3(neJointController * controller, const neV3 & torque){
  controller->SetControllerTorqueBodyAV3(torque);
}
neV3 JointControllerGetTorqueBodyAV3(neJointController * controller){
  return controller->GetControllerTorqueBodyAV3();
}

void JointControllerSetTorqueBodyBV3(neJointController * controller, const neV3 & torque){
  controller->SetControllerTorqueBodyBV3(torque);
}
neV3 JointControllerGetTorqueBodyBV3(neJointController * controller){
  return controller->GetControllerTorqueBodyBV3();
}

void JointControllerSetForceWithTorqueBodyAV3(neJointController * controller, const neV3 & force, const neV3 & pos){
  controller->SetControllerForceWithTorqueBodyAV3(force, pos);
}
void JointControllerSetForceWithTorqueBodyBV3(neJointController * controller, const neV3 & force, const neV3 & pos){
  controller->SetControllerForceWithTorqueBodyBV3(force, pos);
}

/********
 * neV3 *
 *******/
neV3 CreateV3(f32 x,f32 y,f32 z){
  gV3.Set(x,y,z); return gV3;
}
void V3Set(neV3 & v,f32 x,f32 y,f32 z){
  v.Set(x,y,z);
}
void V3SetV3(neV3 & v,const neV3 other){
  v.Set(other);
}
void V3SetAbs(neV3 & v){
  v.SetAbs(v);
}
neV3 V3Abs(const neV3 & v){
  gV3.SetAbs(v); return gV3;
}
void CAPI V3SetMin(neV3 & v,const neV3 & a,const neV3 & b){
  v.SetMin(a,b);
}
neV3 CAPI V3Min(const neV3 & a,const neV3 & b){
  gV3.SetMin(a,b); return gV3;
}
void CAPI V3SetMax(neV3 & v,const neV3 & a,const neV3 & b){
  v.SetMax(a,b);
}
neV3 CAPI V3Max(const neV3 & a,const neV3 & b){
  gV3.SetMax(a,b); return gV3;
}


neV3 V3Neg(const neV3 & v){
  return -v;
}
void V3Dec(neV3 & a,const neV3 & b){
  a-=b;
}
void V3Inc(neV3 & a,const neV3 & b){
  a+=b;
}
neV3 V3Sub(const neV3 & a,const neV3 & b){
  return a-b;
}
neV3 V3Add(const neV3 & a,const neV3 & b){
  return a+b;
}
neV3 V3Mul(const neV3 & a, f32 scalar){
  return a*scalar;
}
neV3 V3Div(const neV3 & a, f32 scalar){
  return a/scalar;
}
neV3 V3MulV3(const neV3 & a,const neV3 & b){
  return a*b;
}
neV3 V3MulM3(const neV3 & v,const neM3 & m3){
  return v*m3;
}
neV3 V3AddMul(const neV3 & a,const neV3 & b, f32 t){
  return a + b*t;
}
f32 V3Dot(const neV3 & a,const neV3 & b){
  return a.Dot(b);
}
neV3 V3Cross(const neV3 & a,const neV3 & b) {
  return a.Cross(b);
}
neV3 V3NormalizedCross(const neV3 & a, const neV3 & b) {
  gV3=a.Cross(b); gV3.Normalize(); return gV3;
}
void V3Project(neV3 & a,const neV3 & b) {
  a=a.Project(b);
}
neV3 V3Projected(const neV3 & a,const neV3 & b){
  return a.Project(b);
}
float V3LengthSquared(const neV3 & v) {
  return v.Dot(v);
}
float V3Length(const neV3 & v){
  return v.Length();
}
float V3DistanceSquared(const neV3 & a,const neV3 & b){
  gV3 = b-a; return gV3.Dot(gV3);
}
float V3Distance(const neV3 & a,const neV3 & b){
  gV3 = b-a; return gV3.Length();
}

void V3Normalize(neV3 & v){
  v.Normalize();
}
neV3 V3Normalized(const neV3 & v){
  gV3 = v; gV3.Normalize(); return gV3;
}
void V3RotateX(neV3 & v, f32 deg){
  v.RotateX(NE_DEG_TO_RAD(deg));
}
void V3RotateY(neV3 & v, f32 deg){
  v.RotateY(NE_DEG_TO_RAD(deg));
}
void V3RotateZ(neV3 & v, f32 deg){
  v.RotateZ(NE_DEG_TO_RAD(deg));
}
neV3 V3RotatedX(const neV3 & v, f32 deg){
  gV3=v; gV3.RotateX(NE_DEG_TO_RAD(deg)); return gV3;
}
neV3 V3RotatedY(const neV3 & v, f32 deg){
  gV3=v; gV3.RotateY(NE_DEG_TO_RAD(deg)); return gV3;
}
neV3 V3RotatedZ(const neV3 & v, f32 deg){
  gV3=v; gV3.RotateZ(NE_DEG_TO_RAD(deg)); return gV3;
}
neV3 V3Lerp(const neV3 & a, const neV3 & b, f32 t){
  if (t<0.000001f)
    return a;
  else if (t>0.999999f)
    return b;
  return a + (b-a)*t;
}
f32 V3GetPitch(const neV3 & v){
  return NE_RAD_TO_DEG(v.GetPitch());
}
f32 V3GetYaw(const neV3 & v){
  return NE_RAD_TO_DEG(v.GetYaw());
}
/// neV3 tools
neV3 CAPI V3Between(const neV3 & a, const neV3 & b){
  return a + (b-a)*0.5f;
}
f32 CAPI V3GetDistanceToLine(const neV3 & v,const neV3 & a,const neV3 & b){
  gV3=v; return gV3.GetDistanceFromLine(a,b);
}
f32 CAPI V3GetDistanceAndNearestPointOnLine(const neV3 & v,const neV3 & a,const neV3 & b, neV3 & n){
  gV3=v; f32 d = gV3.GetDistanceFromLine2(n,a,b);
  return d;
}
f32 CAPI V3GetDistanceAndNearestPointOnRay(const neV3 & v,const neV3 & origin,const neV3 & direction, neV3 & n){
  gV3=v; f32 d = gV3.GetDistanceFromLineAndProject(n,origin,direction);
  return d;
}
void V3ChooseAxis(neV3 & normalizedAxis, neV3 & crossAxis, const neV3 & normal){
  ChooseAxis(normalizedAxis,crossAxis,normal);
}
void V3RemoveComponent(neV3 & v, f32 x, f32 y, f32 z){
  gV3.Set(x,y,z); v.RemoveComponent(gV3);
}
void V3RemoveComponentV3(neV3 & v, const neV3 & o){
  v.RemoveComponent(o);
}

/****************
* InertiaTensor *
****************/
neV3 CubeInertiaTensorV3(f32 fSize, f32 fMass){
  if (fMass<1.0f ) fMass=1.0f;
  if (fSize<0.01f) fSize=0.01f;
  return neBoxInertiaTensor(fSize, fSize, fSize, fMass);
}
neV3 BoxInertiaTensorV3(f32 fWidth, f32 fHeight, f32 fDepth, f32 fMass){
  if (fMass  <1.0f ) fMass  =1.0f;
  if (fWidth <0.01f) fWidth =0.01f;
  if (fHeight<0.01f) fHeight=0.01f;
  if (fDepth <0.01f) fDepth =0.01f;
  return neBoxInertiaTensor(fWidth, fHeight, fDepth, fMass);
}
neV3 SphereInertiaTensorV3(f32 fDiameter, f32 fMass){
  if (fMass    <1.0f ) fMass=1.0f;
  if (fDiameter<0.01f) fDiameter=0.01f;
  return neSphereInertiaTensor(fDiameter, fMass);
}
neV3 CapsuleInertiaTensorV3(f32 fDiameter, f32 fHeight, f32 fMass){
  if (fMass    <1.0f ) fMass    =1.0f;
  if (fDiameter<0.01f) fDiameter=0.01f;
  if (fHeight  <0.01f) fHeight  =0.01f;
  return neCapsuleInertiaTensor(fDiameter, fHeight, fMass);
}

/********
 * neM3 *
 *******/
 //! create identity matrix
neM3 CreateIdentityMatrix(void){
  gM3.SetIdentity(); return gM3;
}
neM3 CreateRotXMatrix(f32 deg){
  f32 s,c,r=NE_DEG_TO_RAD(deg);
  s = sinf(r); c = cosf(r);
  gM3[0].Set(1.0f,0.0f,0.0f);
  gM3[1].Set(0.0f,   c,   s);
  gM3[2].Set(0.0f,  -s,   c);
  return gM3;
}
neM3 CreateRotYMatrix(f32 deg){
  f32 s,c,r=NE_DEG_TO_RAD(deg);
  s = sinf(r); c = cosf(r);
  gM3[0].Set(   c,0.0f,  -s);
  gM3[1].Set(0.0f,1.0f,0.0f);
  gM3[2].Set(   s,0.0f,   c);
  return gM3;
}
neM3 CreateRotZMatrix(f32 deg){
  f32 s,c,r=NE_DEG_TO_RAD(deg);
  s = sinf(r); c = cosf(r);
   gM3[0].Set(   c,   s,0.0f);
  gM3[1].Set(  -s,   c,0.0f);
  gM3[2].Set(0.0f,0.0f,1.0f);
  return gM3;
}

neM3 CreateRotXYZMatrix(f32 xdeg,f32 ydeg,f32 zdeg) {
  neM3 rx, ry, rz;
  f32 s, c, r = NE_DEG_TO_RAD(xdeg);
  s = sinf(r); c = cosf(r);
  rx[0].Set(1.0f,0.0f,0.0f);
  rx[1].Set(0.0f,   c,   s);
  rx[2].Set(0.0f,  -s,   c);

  r = NE_DEG_TO_RAD(ydeg);
  s = sinf(r); c = cosf(r);
  ry[0].Set(   c,0.0f,  -s);
  ry[1].Set(0.0f,1.0f,0.0f);
  ry[2].Set(   s,0.0f,   c);

  r = NE_DEG_TO_RAD(zdeg);
  s = sinf(r); c = cosf(r);
  rz[0].Set( c  ,   s,0.0f);
  rz[1].Set(-s  ,   c,0.0f);
  rz[2].Set(0.0f,0.0f,1.0f);

  gM3 = rz*ry*rx;
  return gM3;
}

void M3SetTranspose(neM3 & m3) {
  m3.SetTranspose(m3);
}
neM3 M3GetTranspose(const neM3 & m3) {
  gM3=m3; gM3.SetTranspose(gM3); return gM3;
}
//! create matrix from pitch yaw roll
neM3 CreateRotMatrix(f32 p, f32 y, f32 r){
  gV3.Set(p,y,r);
  return CreateRotMatrixV3(gV3);
}

//! create matrix from pitch yaw roll vector
neM3 CreateRotMatrixV3(const neV3 & pyr){

  f32 p = NE_DEG_TO_RAD(pyr[0]*0.5f);
  f32 y = NE_DEG_TO_RAD(pyr[1]*0.5f);
  f32 r = NE_DEG_TO_RAD(pyr[2]*0.5f);

  f32 cr = cosf( r);
  f32 cp = cosf( p);
  f32 cy = cosf(-y);
  f32 sr = sinf( r);
  f32 sp = sinf( p);
  f32 sy = sinf(-y);
  f32 cpcy = cp*cy;
  f32 spsy = sp*sy;
  f32 spcy = sp*cy;
  f32 cpsy = cp*sy;
  gQ.X = cr*spcy + sr*cpsy;
  gQ.Y = cr*cpsy - sr*spcy;
  gQ.Z = sr*cpcy - cr*spsy;
  gQ.W = cr*cpcy + sr*spsy;
  return gQ.BuildMatrix3();
}
//! create matrix from quaternion
neM3 CreateRotMatrixQ(const neQ & q){
  return q.BuildMatrix3();
}
//! create matrix from Axis and angle
neM3 CreateRotMatrixAxisAngle(f32 axisx, f32 axisy, f32 axisz, f32 angle){
  gV3.Set(axisx, axisy, axisz);
  gQ.Set(NE_DEG_TO_RAD(angle),gV3);
  return gQ.BuildMatrix3();
}
//! create matrix from Axis and angle vector
neM3 CeateRotMatrixAxisAngleV3(const neV3 & axis, f32 angle){
  gQ.Set(NE_DEG_TO_RAD(angle),axis);
  return gQ.BuildMatrix3();
}
//! set identity matrix from Axis and angle vector
void M3SetIdentity(neM3 & m3){
  m3.SetIdentity();
}
//! get pitch yaw roll (deg) from matrix
void M3GetRotAngle(const neM3 & m3, f32 & rp, f32 & ry, f32 & rr){
  gV3 = M3GetRotAngleV3(m3);
  rp = gV3[0];
  ry = gV3[1];
  rr = gV3[2];
}
//! get pitch yaw roll (deg) vector from matrix
neV3 M3GetRotAngleV3(const neM3 & m3){
  f32 gA[9];
  gA[0] = m3.M[0].v[0];
  gA[1] = m3.M[0].v[1];
  gA[2] = m3.M[0].v[2];
  //gA[3] = m3.M[1].v[0];
  gA[4] = m3.M[1].v[1];
  //gA[5] = m3.gA[1].v[2];
  gA[6] = m3.M[2].v[0];
  gA[7] = m3.M[2].v[1];
  gA[8] = m3.M[2].v[2];

  neV3 r;
  if (gA[7]<1.0f) {
    if (gA[7]>-1.0f) {
      r.v[0] = (f32)asin((double)gA[7]);
      r.v[1] = (f32)atan2(-gA[6],gA[8]);
      r.v[2] = (f32)atan2(-gA[1],gA[4]);
    } else {
      r.v[0] = -1.570796f;
      r.v[1] = 0.0f;
      r.v[2] = (f32)-atan2(gA[2],gA[0]);
    }
  } else {
    r.v[0] = 1.570796f;
    r.v[1] = 0.0f;
    r.v[2] = (f32)atan2(gA[2],gA[0]);
  }
  r.v[0] = NE_RAD_TO_DEG(r.v[0]);
  r.v[1] = NE_RAD_TO_DEG(r.v[1]);
  r.v[2] = NE_RAD_TO_DEG(r.v[2]);
  return r;
}
neM3 M3Add(const neM3 & a, const neM3 & b){
  return a+b;
}
neM3 M3Sub(const neM3 & a, const neM3 & b){
  return a-b;
}
neM3 M3Mul(const neM3 & a, f32 scalar){
  return a*scalar;
}
neV3 M3MulV3(const neM3 & m, const neV3 v){
  return m*v;
}
neM3 M3MulM3(const neM3 & a, const neM3 & b){
  return a*b;
}
neM3 M3Mul3(const neM3 & a, const neM3 & b, const neM3 & c){
  return a*b*c;
}
neM3 M3Mul4(const neM3 & a, const neM3 & b, const neM3 & c, const neM3 & d){
  return a*b*c*d;
}
neM3 M3Lerp(const neM3 & ma, const neM3 & mb,f32 t){
  neQ a,b;
  if      (t<0.000001f)
    return ma;
  else if (t>0.999999f)
    return mb;

  a.SetupFromMatrix3(ma);
  b.SetupFromMatrix3(mb);
  gQ = a + (b-a) * t;
  return gQ.BuildMatrix3();
}
bool M3SetInverse(neM3 & m3){
  return m3.SetInvert(m3);
}
neM3 M3GetInverse(const neM3 & m3){
  gM3.SetInvert(m3);
  return gM3;
}
neV3 M3RotateVector(const neM3 & m3, const neV3 & v){
  return m3*v;
}
void M3RotateVectors(const neM3 & m3, neV3 * d, const neV3 * s, s32 n){
  s32 i; for (i=0;i<n;i++){ d[i] = m3 * s[i]; }
}
void M3InverseRotateVectors(const neM3 & m3, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3.SetInvert(m3); for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
/********
 * neT3 *
 *******/
neT3 CreateIdentityTransform(void){
  gT3.SetIdentity(); return gT3;
}

void T3SetIdentiy(neT3 & t3){
  t3.SetIdentity();
}
void T3SetPosition(neT3 & t3, f32 px, f32 py, f32 pz){
  gV3.Set(px,py,pz);
  t3.pos=gV3;
}
void T3SetPositionV3(neT3 & t, const neV3 & pos){
  t.pos=pos;
}
void T3SetRotation(neT3 & t3, f32 rp, f32 ry, f32 rr){
  gV3.Set(NE_DEG_TO_RAD(rp),NE_DEG_TO_RAD(ry),NE_DEG_TO_RAD(rr));
  t3.rot.RotateXYZ(gV3);
}
void T3SetRotationV3(neT3 & t3, const neV3 & rot){
  gV3.Set(NE_DEG_TO_RAD(rot[0]),NE_DEG_TO_RAD(rot[1]),NE_DEG_TO_RAD(rot[2]));
  t3.rot.RotateXYZ(gV3);
}
void T3SetRotationM3(neT3 & t3, const neM3 & rot){
  t3.rot=rot;
}
void T3SetPositionRotation(neT3 & t3, f32 px, f32 py, f32 pz, f32 rp, f32 ry, f32 rr){
  t3.pos.Set(px,py,pz);
  gV3.Set(NE_DEG_TO_RAD(rp),NE_DEG_TO_RAD(ry),NE_DEG_TO_RAD(rr));
  t3.rot.RotateXYZ(gV3);
}
void T3SetPositionRotationV3(neT3 & t3, const neV3 & pos, const neV3 & rot){
  t3.pos=pos;
  gV3.Set(NE_DEG_TO_RAD(rot[0]),NE_DEG_TO_RAD(rot[1]),NE_DEG_TO_RAD(rot[2]));
  t3.rot.RotateXYZ(gV3);
}
void T3SetPositionRotationM3(neT3 & t3, const neV3 & pos, const neM3 & rot){
  t3.pos=pos;
  t3.rot=rot;
}

neV3 T3MulV3(const neT3 & t3, const neV3 & v){
  gT3=t3; return gT3*v;
}
neT3 T3MulT3(const neT3 & a, const neT3 & b){
  gT3=a; return gT3*b;
}
neT3 T3Mul3(const neT3 & a, const neT3 & b, const neT3 & c){
  gT3=a; return gT3*b*c;
}
neT3 T3Mul4(const neT3 & a, const neT3 & b, const neT3 & c, const neT3 & d){
  gT3=a; return gT3*b*c*d;
}

void CAPI T3SetInverse(neT3 & t3){
  t3=t3.FastInverse();
}
neT3 CAPI T3GetInverse(const neT3 & t3){
  gT3 = t3; return gT3.FastInverse();
}

void CAPI T3GetOpenGLMatrix(const neT3 & t3, f32 * p){
  gT3 = t3;
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}
void CAPI T3GetOpenGLMatrixInverted(const neT3 & t3, f32 * p){
  gT3 = t3; gT3 = gT3.FastInverse();
  gT3.rot[0].v[3] = 0.0f;
  gT3.rot[1].v[3] = 0.0f;
  gT3.rot[2].v[3] = 0.0f;
  gT3.pos.v[3] = 1.0f;
  memcpy(p,&gT3,16*sizeof(f32));
}
neV3 CAPI T3RotateVector(const neT3 & t3, const neV3 & v){
  return t3.rot * v;
}
neV3 CAPI T3TransformVector(const neT3 & t3, const neV3 & v){
  gT3 = t3; return gT3 * v;
}
void CAPI T3RotateVectors(const neT3 & t3, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3=t3.rot;
  for (i=0;i<n;i++){ d[i] = gM3 * s[i]; }
}
void CAPI T3TransformVectors(const neT3 & t3, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = t3;
  for (i=0;i<n;i++) { d[i] = gT3 * s[i]; }
}
void CAPI T3InverseRotateVectors(const neT3 & t3, neV3 * d, const neV3 * s, s32 n){
  s32 i; gM3.SetInvert(t3.rot);
  for (i=0;i<n;i++){ d[i] = gM3 * s[i];}
}
void CAPI T3InverseTransformVectors(const neT3 & t3, neV3 * d, const neV3 * s, s32 n){
  s32 i; gT3 = t3; gT3=gT3.FastInverse();
  for (i=0;i<n;i++) { d[i] = gT3 * s[i]; }
}

/*******
 * neQ *
 ******/
neQ CreateQuaternion(f32 x, f32 y, f32 z, f32 w){
  gQ.Set(x,y,z,w);
  return gQ;
}
neQ CreateQuaternionV3(const neV3 & xyz, f32 w){
  gQ.Set(xyz,w);
  return gQ;
}
neQ CreateQuaternionM3(const neM3 & m){
  gQ.SetupFromMatrix3(m);
  return gQ;
}
neQ CreateQuaternionAxisAngle(const neV3 & axis, f32 angle){
  gQ.Set(NE_DEG_TO_RAD(angle),axis);
  return gQ;
}
void QNormalize(neQ & q){
  q.Normalize();
}
neQ QNormalized(const neQ & q){
  gQ = q;
  return gQ.Normalize();
}
neQ QMulQ(const neQ & a, const neQ & b){
  return a*b;
}
neQ  CAPI QMul3(const neQ & a, const neQ & b, const neQ & c){
  return a*b*c;
}
neQ  CAPI QMul4(const neQ & a, const neQ & b, const neQ & c, const neQ & d){
  return a*b*c*d;
}
void QGetAxisAngle(const neQ & q, f32 & axisx, f32 & axisy, f32 & axisz, f32 & angle){
  q.GetAxisAngle(gV3,angle);
  axisx = gV3[0];
  axisy = gV3[1];
  axisz = gV3[2];
  angle = NE_RAD_TO_DEG(angle);
}
void QGetAxisAngleV3(const neQ & q, neV3& axis, f32 & angle){
  q.GetAxisAngle(axis,angle);
  angle=NE_RAD_TO_DEG(angle);
}
neQ QLerp(const neQ & a, const neQ & b,f32 t){
  if (t<=0.0f)
    return a;
  else if (t>=1.0f)
    return b;

  return a + (b-a) * t;
}

#ifdef __cplusplus
}
#endif
