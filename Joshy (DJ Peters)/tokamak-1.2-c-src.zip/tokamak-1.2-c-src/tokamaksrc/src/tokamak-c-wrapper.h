#ifndef __tokamak_c_wrapper_h__
#define __tokamak_c_wrapper_h__

#include "math/ne_type.h"
#include "math/ne_debug.h"
#include "tokamak.h"
#include "containers.h"
#include "scenery.h"
#include "collision.h"
#include "constraint.h"
#include "rigidbody.h"
#include "stack.h"
#include "simulator.h"
#include "message.h"
// #include "Matrix3D.h"

#ifdef TOKAMAK_COMPILE_DLL
 #define CAPI __declspec(dllexport)
#else
 #define CAPI
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**************
* neSimulator *
***************/
neSimulator * CAPI CreateSimulator(const neSimulatorSizeInfo & sizeInfo, f32 gx, f32 gy, f32 gz);
neSimulator * CAPI CreateSimulatorV3(const neSimulatorSizeInfo & sizeInfo, const neV3 & grav);
void CAPI DestroySimulator(neSimulator * & sim);

void CAPI SimulatorSetGravity(neSimulator * sim, f32 gx, f32 gy, f32 gz);
void CAPI SimulatorGetGravity(neSimulator * sim, f32 & gx, f32 & gy, f32 & gz);

void CAPI SimulatorSetGravityV3(neSimulator * sim, const neV3 & g);
neV3 CAPI SimulatorGetGravityV3(neSimulator * sim);

neRigidBody * CAPI SimulatorCreateRigidBody(neSimulator * sim);
neRigidBody * CAPI SimulatorCreateRigidParticle(neSimulator * sim);
void CAPI SimulatorFreeRigidBody(neSimulator * sim,neRigidBody * & body);

neAnimatedBody * CAPI SimulatorCreateAnimatedBody(neSimulator * sim);
void CAPI SimulatorFreeAnimatedBody(neSimulator * sim, neAnimatedBody * & body);

neAnimatedBody * CAPI SimulatorBeginIterateActiveAnimatedBody(neSimulator * sim);
neAnimatedBody * CAPI SimulatorGetNextActiveAnimatedBody(neSimulator * sim, neAnimatedBody* ab);

neRigidBody * CAPI SimulatorBeginIterateActiveRigidBody(neSimulator * sim);
neRigidBody * CAPI SimulatorGetNextActiveRigidBody(neSimulator * sim, neRigidBody* rb);

neRigidBody * CAPI SimulatorBeginIterateActiveRigidParticleBody(neSimulator * sim);
neRigidBody * CAPI SimulatorGetNextActiveRigidParticleBody(neSimulator * sim, neRigidBody* rb);

neAnimatedBody * CAPI SimulatorBeginIterateInactiveAnimatedBody(neSimulator * sim);
neAnimatedBody * CAPI SimulatorGetNextInactiveAnimatedBody(neSimulator * sim, neAnimatedBody* ab);

neRigidBody * CAPI SimulatorBeginIterateInactiveRigidBody(neSimulator * sim);
neRigidBody * CAPI SimulatorGetNextInactiveRigidBody(neSimulator * sim, neRigidBody* rb);

neRigidBody * CAPI SimulatorBeginIterateInactiveRigidParticleBody(neSimulator * sim);
neRigidBody * CAPI SimulatorGetNextInactiveRigidParticleBody(neSimulator * sim, neRigidBody* rb);


bool CAPI SimulatorSetMaterial(neSimulator * sim, s32 index, f32   friction, f32   restitution);
bool CAPI SimulatorGetMaterial(neSimulator * sim, s32 index, f32 & friction, f32 & restitution);

void CAPI SimulatorAdvance(neSimulator * sim, f32 sec);
void CAPI SimulatorAdvanceSteps(neSimulator * sim, f32 sec, s32 steps);
void CAPI SimulatorAdvanceMinMax(neSimulator * sim, f32 sec, f32 minTimeStep, f32 maxTimeStep);

void CAPI SimulatorSetTerrainMesh(neSimulator * sim, neTriangleMesh * tris);
void CAPI SimulatorFreeTerrainMesh(neSimulator * sim);

neJoint * CAPI SimulatorCreateRigidBodyWorldJoint(neSimulator * sim, neRigidBody * bodyA);
neJoint * CAPI SimulatorCreateRigidBodyRigidBodyJoint(neSimulator * sim, neRigidBody * bodyA, neRigidBody * bodyB);
neJoint * CAPI SimulatorCreateRigidBodyAnimatedBodyJoint(neSimulator * sim, neRigidBody * bodyA, neAnimatedBody * bodyB);
void CAPI SimulatorFreeJoint(neSimulator * sim, neJoint * & constraint);

void CAPI SimulatorSetCollisionCallback(neSimulator * sim, neCollisionCallback * fn);
neCollisionCallback * CAPI SimulatorGetCollisionCallback(neSimulator * sim);

void CAPI SimulatorSetBreakageCallback(neSimulator * sim, neBreakageCallback * cb);
neBreakageCallback * CAPI SimulatorGetBreakageCallback(neSimulator * sim);

void CAPI SimulatorSetTerrainTriangleQueryCallback(neSimulator * sim, neTerrainTriangleQueryCallback * cb);
neTerrainTriangleQueryCallback * CAPI SimulatorGetTerrainTriangleQueryCallback(neSimulator * sim);

void CAPI SimulatorSetCustomCDRB2RBCallback(neSimulator * sim, neCustomCDRB2RBCallback * cb);
neCustomCDRB2RBCallback * CAPI SimulatorGetCustomCDRB2RBCallback(neSimulator * sim);

void CAPI SimulatorSetCustomCDRB2ABCallback(neSimulator * sim, neCustomCDRB2ABCallback * cb);
neCustomCDRB2ABCallback * CAPI SimulatorGetCustomCDRB2ABCallback(neSimulator * sim);

void CAPI SimulatorSetLogOutputCallback(neSimulator * sim, neLogOutputCallback * fn);
neLogOutputCallback * CAPI SimulatorGetLogOutputCallback(neSimulator * sim);

void CAPI SimulatorSetLogOutputLevel(neSimulator * sim, u32 lvl);
u32  CAPI SimulatorGetLogOutputLevel(neSimulator * sim);

neSimulatorSizeInfo CAPI SimulatorGetCurrentSizeInfo(neSimulator * sim);
neSimulatorSizeInfo CAPI SimulatorGetStartSizeInfo(neSimulator * sim);
s32 CAPI SimulatorGetMemoryAllocated(neSimulator * sim);
s32 CAPI SimulatorGetIdleBodyCount(neSimulator * sim);

neCollisionTable * CAPI SimulatorGetCollisionTable(neSimulator * sim);

/*******************
* neCollisionTable *
********************/
void CAPI CollisionTableSet(neCollisionTable * tbl, s32 collisionID1, s32 collisionID2, u32 response);
u32  CAPI CollisionTableGet(neCollisionTable * tbl, s32 collisionID1, s32 collisionID2);
s32  CAPI CollisionTableGetMaxCollisionID(neCollisionTable * tbl);

/*************
* neGeometry *
**************/
u32   CAPI GeometryGetType(neGeometry * geo);
void  CAPI GeometrySetUserData(neGeometry * geo, void* userData);
void* CAPI GeometryGetUserData(neGeometry * geo);

void CAPI GeometrySetCubeSize(neGeometry * geo, f32 cubeSize);

void CAPI GeometrySetBoxSize(neGeometry * geo, f32 width, f32 height, f32 depth);
bool CAPI GeometryGetBoxSize(neGeometry * geo, f32 & width, f32 & height, f32 & depth);

void CAPI GeometrySetBoxSizeV3(neGeometry * geo, const neV3 & boxSize);
bool CAPI GeometryGetBoxSizeV3(neGeometry * geo, neV3 & boxSize);

void CAPI GeometrySetCapsule(neGeometry * geo, f32   diameter, f32   height);
bool CAPI GeometryGetCapsule(neGeometry * geo, f32 & diameter, f32 & height);

void CAPI GeometrySetSphereDiameter(neGeometry * geo, f32   diameter);
bool CAPI GeometryGetSphereDiameter(neGeometry * geo, f32 & diameter);

void CAPI GeometrySetConvexMesh(neGeometry * geo, neByte *   convexData);
bool CAPI GeometryGetConvexMesh(neGeometry * geo, neByte * & convexData);

void CAPI GeometrySetPosition(neGeometry* geo, f32 x, f32 y, f32 z);
void CAPI GeometryGetPosition(neGeometry* geo, f32 & x, f32 & y, f32 & z);

void CAPI GeometrySetPositionV3(neGeometry* geo, const neV3 & position);
neV3 CAPI GeometryGetPositionV3(neGeometry* geo);

void CAPI GeometrySetPositionRotation(neGeometry* geo, f32   px, f32   py, f32   pz, f32   rp, f32   ry, f32   rr);
void CAPI GeometryGetPositionRotation(neGeometry* geo, f32 & px, f32 & py, f32 & pz, f32 & rx, f32 & ry, f32 & rz);

void CAPI GeometrySetPositionRotationV3(neGeometry* geo, const neV3 & position, const neV3 & rotation);
void CAPI GeometryGetPositionRotationV3(neGeometry* geo,       neV3 & position,       neV3 & rotation);

void CAPI GeometrySetTransform(neGeometry * geo, neT3 & t);
neT3 CAPI GeometryGetTransform(neGeometry * geo);

void CAPI GeometrySetMaterialIndex(neGeometry * geo, s32 index);
s32  CAPI GeometryGetMaterialIndex(neGeometry * geo);

void CAPI GeometrySetBreakageFlag(neGeometry * geo, u32 flag);
u32  CAPI GeometryGetBreakageFlag(neGeometry * geo);

void CAPI GeometrySetBreakageMass(neGeometry * geo, f32 mass);
f32  CAPI GeometryGetBreakageMass(neGeometry * geo);

void CAPI GeometrySetBreakageInertiaTensor(neGeometry * geo, f32 tx, f32 ty, f32 tz);
void CAPI GeometryGetBreakageInertiaTensor(neGeometry * geo, f32 & tx, f32 & ty, f32 & tz);

void CAPI GeometrySetBreakageInertiaTensorV3(neGeometry * geo, const neV3 & tensor);
neV3 CAPI GeometryGetBreakageInertiaTensorV3(neGeometry * geo);

void CAPI GeometrySetBreakageMagnitude(neGeometry * geo, f32 mag);
f32  CAPI GeometryGetBreakageMagnitude(neGeometry * geo);

void CAPI GeometrySetBreakageAbsorption(neGeometry * geo, f32 absorb);
f32  CAPI GeometryGetBreakageAbsorption(neGeometry * geo);

void CAPI GeometrySetBreakagePlane(neGeometry * geo, f32 nx, f32 ny, f32 nz);
void CAPI GeometryGetBreakagePlane(neGeometry * geo, f32 & nx, f32 & ny, f32 & nz);

void CAPI GeometrySetBreakagePlaneV3(neGeometry * geo, const neV3 & planeNormal);
neV3 CAPI GeometryGetBreakagePlaneV3(neGeometry * geo);

void CAPI GeometrySetBreakageNeighbourRadius(neGeometry * geo, f32 radius);
f32  CAPI GeometryGetBreakageNeighbourRadius(neGeometry * geo);

void CAPI GeometryGetOpenGLMatrix(neGeometry* geo, f32 * p);
void CAPI GeometryGetInverseOpenGLMatrix(neGeometry* geo, f32 * p);
neV3 CAPI GeometryRotateVector(neGeometry* geo, const neV3 & v);
neV3 CAPI GeometryTransformVector(neGeometry* geo, const neV3 & v);
void CAPI GeometryRotateVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n);
void CAPI GeometryTransformVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n);
void CAPI GeometryInverseRotateVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n);
void CAPI GeometryInverseTransformVectors(neGeometry* geo, neV3 * d, const neV3 * s, s32 n);

/*****************
* neAnimatedBody *
******************/
void   CAPI AnimatedBodySetUserData(neAnimatedBody * ab, void* userData);
void * CAPI AnimatedBodyGetUserData(neAnimatedBody * ab);

void CAPI AnimatedBodySetPosition(neAnimatedBody* ab, f32 x, f32 y, f32 z);
void CAPI AnimatedBodyGetPosition(neAnimatedBody* ab, f32 & x, f32 & y, f32 & z);

void CAPI AnimatedBodySetPositionV3(neAnimatedBody * ab, const neV3 & position);
neV3 CAPI AnimatedBodyGetPositionV3(neAnimatedBody * ab);

void CAPI AnimatedBodySetRotation(neAnimatedBody* ab, f32 p, f32 y, f32 r);
void CAPI AnimatedBodyGetRotation(neAnimatedBody* ab, f32 & p, f32 & y, f32 & r);

void CAPI AnimatedBodySetRotationV3(neAnimatedBody* ab, const neV3 & rotation);
neV3 CAPI AnimatedBodyGetRotationV3(neAnimatedBody* ab);

void CAPI AnimatedBodySetRotationM3(neAnimatedBody * ab, const neM3 & m);
neM3 CAPI AnimatedBodyGetRotationM3(neAnimatedBody * ab);

void CAPI AnimatedBodySetRotationQ(neAnimatedBody * ab, const neQ & q);
neQ  CAPI AnimatedBodyGetRotationQ(neAnimatedBody * ab);

void CAPI AnimatedBodySetPositionRotation(neAnimatedBody* ab, f32   px, f32   py, f32   pz, f32   rp, f32   ry, f32   rr);
void CAPI AnimatedBodyGetPositionRotation(neAnimatedBody* ab, f32 & px, f32 & py, f32 & pz, f32 & rx, f32 & ry, f32 & rz);

void CAPI AnimatedBodySetPositionRotationV3(neAnimatedBody* ab, const neV3 & position, const neV3 & rotation);
void CAPI AnimatedBodyGetPositionRotationV3(neAnimatedBody* ab,       neV3 & position,       neV3 & rotation);

void CAPI AnimatedBodySetTransform(neAnimatedBody * ab, const neT3 & t);
neT3 CAPI AnimatedBodyGetTransform(neAnimatedBody * ab);

void CAPI AnimatedBodySetCollisionID(neAnimatedBody * ab, s32 cid);
s32  CAPI AnimatedBodyGetCollisionID(neAnimatedBody * ab);

s32  CAPI AnimatedBodyGetGeometryCount(neAnimatedBody * ab);

void CAPI AnimatedBodyUpdateBoundingInfo(neAnimatedBody * ab);

void CAPI AnimatedBodySetCollideConnected(neAnimatedBody * ab, bool yes);
bool CAPI AnimatedBodyGetCollideConnected(neAnimatedBody * ab);

void CAPI AnimatedBodySetCollideDirectlyConnected(neAnimatedBody * ab, bool yes);
bool CAPI AnimatedBodyGetCollideDirectlyConnected(neAnimatedBody * ab);

neGeometry * CAPI AnimatedBodyAddGeometry(neAnimatedBody * ab);
bool CAPI AnimatedBodyRemoveGeometry(neAnimatedBody * ab, neGeometry * geo);
void CAPI AnimatedBodyBeginIterateGeometry(neAnimatedBody * ab);
neGeometry *  CAPI AnimatedBodyGetNextGeometry(neAnimatedBody * ab);

neRigidBody * CAPI AnimatedBodyBreakGeometry(neAnimatedBody * ab, neGeometry * geo);

void CAPI AnimatedBodySetUseCustomCollisionDetection(neAnimatedBody * ab, bool yes,  const neT3 * obb, f32 boundingRadius);
bool CAPI AnimatedBodyGetUseCustomCollisionDetection(neAnimatedBody * ab);

#ifndef NO_ANIMATED_SENSOR
neSensor * CAPI AnimatedBodyAddSensor(neAnimatedBody * ab);
bool CAPI AnimatedBodyRemoveSensor(neAnimatedBody * ab, neSensor * sen);
void CAPI AnimatedBodyBeginIterateSensor(neAnimatedBody * ab);
neSensor * CAPI AnimatedBodyGetNextSensor(neAnimatedBody * ab);
#endif

void CAPI AnimatedBodySetActive(neAnimatedBody * ab, bool yes);
bool CAPI AnimatedBodyGetActive(neAnimatedBody * ab);
void CAPI AnimatedBodySetActiveWithRigidBodyHint(neAnimatedBody * ab, bool yes, neRigidBody * hint);
void CAPI AnimatedBodySetActiveWithAnimatedBodyHint(neAnimatedBody * ab, bool yes, neAnimatedBody * hint);

void CAPI AnimatedBodyGetOpenGLMatrix(neAnimatedBody* ab, f32 * p);
void CAPI AnimatedBodyGetInverseOpenGLMatrix(neAnimatedBody* ab, f32 * p);
neV3 CAPI AnimatedBodyRotateVector(neAnimatedBody* ab, const neV3 & v);
neV3 CAPI AnimatedBodyTransformVector(neAnimatedBody* ab, const neV3 & v);
void CAPI AnimatedBodyRotateVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n);
void CAPI AnimatedBodyTransformVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n);
void CAPI AnimatedBodyInverseRotateVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n);
void CAPI AnimatedBodyInverseTransformVectors(neAnimatedBody* ab, neV3 * d, const neV3 * s, s32 n);

/**************
* neRigidBody *
***************/
void  CAPI RigidBodySetUserData(neRigidBody* rb, void* userData);
void* CAPI RigidBodyGetUserData(neRigidBody* rb);

void CAPI RigidBodySetMass(neRigidBody* rb, f32 mass);
f32  CAPI RigidBodyGetMass(neRigidBody* rb);

void CAPI RigidBodySetInertiaTensor(neRigidBody* rb, f32 tx, f32 ty, f32 tz);
void CAPI RigidBodySetInertiaTensorV3(neRigidBody* rb, const neV3 & tensor);
void CAPI RigidBodySetInertiaTensorM3(neRigidBody* rb, const neM3 & tensor);


void CAPI RigidBodySetCollisionID(neRigidBody* rb, s32 cid);
s32 CAPI RigidBodyGetCollisionID(neRigidBody* rb);

s32 CAPI RigidBodyGetGeometryCount(neRigidBody* rb);

void CAPI RigidBodySetLinearDamping(neRigidBody* rb, f32 damp);
f32 CAPI RigidBodyGetLinearDamping(neRigidBody* rb);

void CAPI RigidBodySetAngularDamping(neRigidBody* rb, f32 damp);
f32 CAPI RigidBodyGetAngularDamping(neRigidBody* rb);

void CAPI RigidBodySetSleepingParameter(neRigidBody* rb, f32 sleepingParam);
f32 CAPI RigidBodyGetSleepingParameter(neRigidBody* rb);

void CAPI RigidBodySetPosition(neRigidBody* rb, f32   x, f32   y, f32   z);
void CAPI RigidBodyGetPosition(neRigidBody* rb, f32 & x, f32 & y, f32 & z);

void CAPI RigidBodySetPositionV3(neRigidBody* rb, const neV3 & p);
neV3 CAPI RigidBodyGetPositionV3(neRigidBody* rb);

void CAPI RigidBodySetRotation(neRigidBody* rb, f32   p, f32   y, f32   r);
void CAPI RigidBodyGetRotation(neRigidBody* rb, f32 & p, f32 & y, f32 & r);

void CAPI RigidBodySetRotationV3(neRigidBody* rb, const neV3 & rot);
neV3 CAPI RigidBodyGetRotationV3(neRigidBody* rb);

void CAPI RigidBodySetRotationM3(neRigidBody* rb, const neM3 & m);
neM3 CAPI RigidBodyGetRotationM3(neRigidBody* rb);

void CAPI RigidBodySetRotationQ(neRigidBody* rb, const neQ & q);
neQ  CAPI RigidBodyGetRotationQ(neRigidBody* rb);

void CAPI RigidBodySetPositionRotation(neRigidBody* rb, f32   px, f32   py, f32   pz, f32   rp, f32   ry, f32   rr);
void CAPI RigidBodyGetPositionRotation(neRigidBody* rb, f32 & px, f32 & py, f32 & pz, f32 & rx, f32 & ry, f32 & rz);

void CAPI RigidBodySetPositionRotationV3(neRigidBody* rb, const neV3 & position, const neV3 & rotation);
void CAPI RigidBodyGetPositionRotationV3(neRigidBody* rb,       neV3 & position,       neV3 & rotation);

neT3 CAPI RigidBodyGetTransform(neRigidBody* rb);

void CAPI RigidBodySetVelocity(neRigidBody* rb, f32 vx, f32 vy, f32 vz);
void CAPI RigidBodyGetVelocity(neRigidBody* rb, f32 & vx, f32 & vy, f32 & vz);

void CAPI RigidBodySetVelocityV3(neRigidBody* rb, const neV3 & v);
neV3 CAPI RigidBodyGetVelocityV3(neRigidBody* rb);

void CAPI RigidBodyGetVelocityAtPoint(neRigidBody* rb,
                                      f32 px, f32 py, f32 pz,
                                      f32 & vx, f32 & vy, f32 & vz);
neV3 CAPI RigidBodyGetVelocityAtPointV3(neRigidBody* rb, const neV3 & pt);

void CAPI RigidBodyGetAngularVelocity(neRigidBody* rb,f32 & vx, f32 & vy, f32 & vz);
neV3 CAPI RigidBodyGetAngularVelocityV3(neRigidBody* rb);

void CAPI RigidBodySetAngularMomentum(neRigidBody* rb, f32 mx, f32 my, f32 mz);
void CAPI RigidBodyGetAngularMomentum(neRigidBody* rb, f32 & mx, f32 & my, f32 & mz);

void CAPI RigidBodySetAngularMomentumV3(neRigidBody* rb, const neV3& am);
neV3 CAPI RigidBodyGetAngularMomentumV3(neRigidBody* rb);

void CAPI RigidBodyUpdateBoundingInfo(neRigidBody* rb);
void CAPI RigidBodyUpdateInertiaTensor(neRigidBody* rb);

void CAPI RigidBodySetForceAtPosition(neRigidBody* rb, f32 fx, f32 fy, f32 fz, f32 px, f32 py, f32 pz);
void CAPI RigidBodySetForceAtPositionV3(neRigidBody* rb, const neV3 & force, const neV3 & pos);

void CAPI RigidBodySetForce(neRigidBody* rb, f32 fx, f32 fy, f32 fz);
void CAPI RigidBodyGetForce(neRigidBody* rb, f32 & fx, f32 & fy, f32 & fz);

void CAPI RigidBodySetForceV3(neRigidBody* rb, const neV3 & force);
neV3 CAPI RigidBodyGetForceV3(neRigidBody* rb);

void CAPI RigidBodySetTorque(neRigidBody* rb, f32 tx, f32 ty, f32 tz);
void CAPI RigidBodyGetTorque(neRigidBody* rb, f32 & tx, f32 & ty, f32 & tz);

void CAPI RigidBodySetTorqueV3(neRigidBody* rb, const neV3 & torque);
neV3 CAPI RigidBodyGetTorqueV3(neRigidBody* rb);

void CAPI RigidBodyApplyImpulseAtPosition(neRigidBody* rb, f32 ix, f32 iy, f32 iz, f32 px, f32 py, f32 pz);
void CAPI RigidBodyApplyImpulseAtPositionV3(neRigidBody* rb, const neV3 & impulse, const neV3 & pos);

void CAPI RigidBodyApplyImpulse(neRigidBody* rb, f32 ix, f32 iy, f32 iz);
void CAPI RigidBodyApplyImpulseV3(neRigidBody* rb, const neV3 & impulse);

void CAPI RigidBodyApplyTwist(neRigidBody* rb, f32 tx, f32 ty, f32 tz);
void CAPI RigidBodyApplyTwistV3(neRigidBody* rb, const neV3 & twist);

void CAPI RigidBodyGravityEnable(neRigidBody* rb, bool yes);
bool CAPI RigidBodyGravityIsOn(neRigidBody* rb);

void CAPI RigidBodySetCollideConnected(neRigidBody* rb, bool yes);
bool CAPI RigidBodyGetCollideConnected(neRigidBody* rb);

void CAPI RigidBodySetCollideDirectlyConnected(neRigidBody* rb, bool yes);
bool CAPI RigidBodyGetCollideDirectlyConnected(neRigidBody* rb);

neGeometry * CAPI RigidBodyAddGeometry(neRigidBody* rb);
bool CAPI RigidBodyRemoveGeometry(neRigidBody* rb, neGeometry * geo);

void CAPI RigidBodyBeginIterateGeometry(neRigidBody* rb);
neGeometry * CAPI RigidBodyGetNextGeometry(neRigidBody* rb);

neRigidBody * CAPI RigidBodyBreakGeometry(neRigidBody* rb, neGeometry * geo);

void CAPI RigidBodySetUseCustomCollisionDetection(neRigidBody* rb, bool yes, const neT3 * obb, f32 boundingRadius);
bool CAPI RigidBodyGetUseCustomCollisionDetection(neRigidBody* rb);

neSensor * CAPI RigidBodyAddSensor(neRigidBody* rb);
bool CAPI RigidBodyRemoveSensor(neRigidBody* rb, neSensor * sen);

void CAPI RigidBodyBeginIterateSensor(neRigidBody* rb);
neSensor * CAPI RigidBodyGetNextSensor(neRigidBody* rb);

void CAPI RigidBodySetActive(neRigidBody* rb, bool yes);
bool CAPI RigidBodyGetActive(neRigidBody* rb);
void CAPI RigidBodySetActiveWithRigidBodyHint(neRigidBody* rb, bool yes, neRigidBody * hint);
void CAPI RigidBodySetActiveWithAnimatedBodyHint(neRigidBody* rb, bool yes, neAnimatedBody * hint);

bool CAPI RigidBodyIsIdle(neRigidBody* rb);
void CAPI RigidBodyWakeUp(neRigidBody* rb);
bool CAPI RigidBodyIsParticle(neRigidBody* rb);

void CAPI RigidBodyGetOpenGLMatrix(neRigidBody* rb, f32 * p);
void CAPI RigidBodyGetInverseOpenGLMatrix(neRigidBody* rb, f32 * p);
neV3 CAPI RigidBodyRotateVector(neRigidBody* rb, const neV3 & v);
neV3 CAPI RigidBodyTransformVector(neRigidBody* rb, const neV3 & v);
void CAPI RigidBodyRotateVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n);
void CAPI RigidBodyTransformVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n);
void CAPI RigidBodyInverseRotateVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n);
void CAPI RigidBodyInverseTransformVectors(neRigidBody* rb, neV3 * d, const neV3 * s, s32 n);


/************************
* neRigidBodyController *
*************************/
neRigidBodyController * CAPI RigidBodyAddController(neRigidBody* rb, RigidBodyControllerCallback * rbccb, s32 period);
bool CAPI RigidBodyRemoveController(neRigidBody* rb, neRigidBodyController * rbController);
void CAPI RigidBodyBeginIterateController(neRigidBody* rb);
neRigidBodyController * CAPI RigidBodyGetNextController(neRigidBody* rb);

neRigidBody * CAPI RigidBodyControllerGetRigidBody(neRigidBodyController * controller);

void CAPI RigidBodyControllerSetForceAtPosition(neRigidBodyController * controller, f32 fx, f32 fy, f32 fz, f32 px, f32 py, f32 pz);
void CAPI RigidBodyControllerSetForceAtPositionV3(neRigidBodyController * controller, const neV3 & force, const neV3 & pos);

void CAPI RigidBodyControllerSetForce(neRigidBodyController * controller, f32   fx, f32   fy, f32   fz);
void CAPI RigidBodyControllerGetForce(neRigidBodyController * controller, f32 & fx, f32 & fy, f32 & fz);
void CAPI RigidBodyControllerSetForceV3(neRigidBodyController * controller, const neV3 & force);
neV3 CAPI RigidBodyControllerGetForceV3(neRigidBodyController * controller);

void CAPI RigidBodyControllerSetTorque(neRigidBodyController * controller, f32   tx, f32   ty, f32   tz);
void CAPI RigidBodyControllerGetTorque(neRigidBodyController * controller, f32 & tx, f32 & ty, f32 & tz);
void CAPI RigidBodyControllerSetTorqueV3(neRigidBodyController * controller, const neV3 & torque);
neV3 CAPI RigidBodyControllerGetTorqueV3(neRigidBodyController * controller);

/***********
* neSensor *
************/
void CAPI SensorSetUserData(neSensor* sensor, void* userData);
void* CAPI SensorGetUserData(neSensor* sensor);

void CAPI SensorSetLineSensor(neSensor* sensor, f32 px,f32 py,f32 pz, f32 ex,f32 ey,f32 ez);
void CAPI SensorGetLinePosition(neSensor* sensor, f32 & x, f32 & y, f32 & z);

void CAPI SensorSetLineSensorV3(neSensor* sensor, const neV3 & position, const neV3 & lineVector);
neV3 CAPI SensorGetLinePositionV3(neSensor* sensor);

void CAPI SensorGetLineVector(neSensor* sensor, f32 & x, f32 & y, f32 & z);
neV3 CAPI SensorGetLineVectorV3(neSensor* sensor);

void CAPI SensorGetLineUnitVector(neSensor* sensor, f32 & x, f32 & y, f32 & z);
neV3 CAPI SensorGetLineUnitVectorV3(neSensor* sensor);

f32 CAPI SensorGetDetectDepth(neSensor* sensor);

void CAPI SensorGetDetectNormal(neSensor* sensor, f32 & x, f32 & y, f32 & z);
neV3 CAPI SensorGetDetectNormalV3(neSensor* sensor);

void CAPI SensorGetDetectContactPoint(neSensor* sensor, f32 & x, f32 & y, f32 & z);
neV3 CAPI SensorGetDetectContactPointV3(neSensor* sensor);

neRigidBody * CAPI SensorGetDetectRigidBody(neSensor* sensor);
neAnimatedBody * CAPI SensorGetDetectAnimatedBody(neSensor* sensor);
s32 CAPI SensorGetDetectMaterial(neSensor* sensor);

/**********
* neJoint *
***********/
void CAPI JointSetType(neJoint * joint, u32 t);
u32 CAPI JointGetType(neJoint * joint);

void CAPI JointSetUserData(neJoint * joint, void* userData);
void* CAPI JointGetUserData(neJoint * joint);

neRigidBody * CAPI JointGetRigidBodyA(neJoint * joint);
neRigidBody * CAPI JointGetRigidBodyB(neJoint * joint);
neAnimatedBody * CAPI JointGetAnimatedBodyB(neJoint * joint);

void CAPI JointSetFrameA(neJoint * joint, const neT3 & frameA);
neT3 CAPI JointGetFrameA(neJoint * joint);

void CAPI JointSetFrameB(neJoint * joint, const neT3 & frameB);
neT3 CAPI JointGetFrameB(neJoint * joint);

void CAPI JointSetFrameWorld(neJoint * joint, const neT3 & frame);

void CAPI JointSetPositionRotationFrameA(neJoint * joint, f32 px, f32 py, f32 pz, f32 rx, f32 ry, f32 rz);
void CAPI JointSetPositionRotationFrameAV3(neJoint * joint, const neV3 & position, const neV3 & rotation);

void CAPI JointSetPositionRotationFrameB  (neJoint * joint, f32 px, f32 py, f32 pz, f32 rx, f32 ry, f32 rz);
void CAPI JointSetPositionRotationFrameBV3(neJoint * joint, const neV3 & position, const neV3 & rotation);

void CAPI JointSetPositionRotationFrameWorld(neJoint * joint, f32 px, f32 py, f32 pz, f32 rx, f32 ry, f32 rz);
void CAPI JointSetPositionRotationFrameWorldV3(neJoint * joint, const neV3 & position, const neV3 & rotation);

void CAPI JointSetJointLength(neJoint * joint, f32 length);
f32  CAPI JointGetJointLength(neJoint * joint);

void CAPI JointEnable(neJoint * joint, bool yes);
bool CAPI JointIsEnabled(neJoint * joint);

void CAPI JointSetDampingFactor(neJoint * joint, f32 factor);
f32  CAPI JointGetDampingFactor(neJoint * joint);

void CAPI JointSetEpsilon(neJoint * joint, f32 epsilon);
f32  CAPI JointGetEpsilon(neJoint * joint);

void CAPI JointSetIteration(neJoint * joint, s32 i);
s32  CAPI JointGetIteration(neJoint * joint);

void CAPI JointSetUpperLimit(neJoint * joint, f32 limit);
f32  CAPI JointGetUpperLimit(neJoint * joint);

void CAPI JointSetLowerLimit(neJoint * joint, f32 limit);
f32  CAPI JointGetLowerLimit(neJoint * joint);

void CAPI JointLimitEnable(neJoint * joint, bool yes);
bool CAPI JointIsLimitEnabled(neJoint * joint);

void CAPI JointSetUpperLimit2(neJoint * joint, f32 limit);
f32  CAPI JointGetUpperLimit2(neJoint * joint);

void CAPI JointSetLowerLimit2(neJoint * joint, f32 limit);
f32  CAPI JointGetLowerLimit2(neJoint * joint);

void CAPI JointLimit2Enable(neJoint * joint, bool yes);
bool CAPI JointIsLimit2Enabled(neJoint * joint);

void CAPI JointMotorEnable(neJoint * joint, bool yes);
bool CAPI JointIsMotorEnabled(neJoint * joint);

void CAPI JointSetMotor(neJoint * joint, f32   desireValue, f32   maxForce);
void CAPI JointGetMotor(neJoint * joint, f32 & desireValue, f32 & maxForce);

/********************
* neJointController *
*********************/
neJointController * CAPI JointAddController(neJoint * joint, JointControllerCallback * jccb, s32 period);
bool CAPI JointRemoveController(neJoint * joint, neJointController * controller);
void CAPI JointBeginIterateController(neJoint * joint);
neJointController * CAPI JointGetNextController(neJoint * joint);

neJoint * CAPI JointControllerGetJoint(neJointController * controller);

void CAPI JointControllerSetForceBodyAV3(neJointController * controller, const neV3 & force);
neV3 CAPI JointControllerGetForceBodyAV3(neJointController * controller);

void CAPI JointControllerSetForceBodyBV3(neJointController * controller, const neV3 & force);
neV3 CAPI JointControllerGetForceBodyBV3(neJointController * controller);

void CAPI JointControllerSetTorqueBodyAV3(neJointController * controller, const neV3 & torque);
neV3 CAPI JointControllerGetTorqueBodyAV3(neJointController * controller);

void CAPI JointControllerSetTorqueBodyBV3(neJointController * controller, const neV3 & torque);
neV3 CAPI JointControllerGetTorqueBodyBV3(neJointController * controller);

void CAPI JointControllerSetForceWithTorqueBodyAV3(neJointController * controller, const neV3 & force, const neV3 & pos);
void CAPI JointControllerSetForceWithTorqueBodyBV3(neJointController * controller, const neV3 & force, const neV3 & pos);

/****************
* InertiaTensor *
****************/
neV3 CAPI CubeInertiaTensorV3(f32 fSize, f32 fMass);
neV3 CAPI BoxInertiaTensorV3(f32 fWidth, f32 fHeight, f32 fDepth, f32 fMass);
neV3 CAPI SphereInertiaTensorV3(f32 fDiameter, f32 fMass);
neV3 CAPI CapsuleInertiaTensorV3(f32 fDiameter, f32 fHeight, f32 fMass);


/********
 * neV3 *
 *******/
neV3 CAPI CreateV3(f32 x,f32 y,f32 z);
void CAPI V3Set(neV3 & v,f32 x,f32 y,f32 z);
void CAPI V3SetV3(neV3 & v,const neV3 other);
void CAPI V3SetAbs(neV3 & v);
neV3 CAPI V3Abs(const neV3 & v);
void CAPI V3SetMin(neV3 & v,const neV3 & a,const neV3 & b);
neV3 CAPI V3Min(const neV3 & a,const neV3 & b);
void CAPI V3SetMax(neV3 & v,const neV3 & a,const neV3 & b);
neV3 CAPI V3Max(const neV3 & a,const neV3 & b);

neV3 CAPI V3Neg(const neV3 & v);
void CAPI V3Dec(neV3 & a,const neV3 & b);
void CAPI V3Inc(neV3 & a,const neV3 & b);
neV3 CAPI V3Sub(const neV3 & a,const neV3 & b);
neV3 CAPI V3Add(const neV3 & a,const neV3 & b);
neV3 CAPI V3Mul(const neV3 & a, f32 scalar);
neV3 CAPI V3Div(const neV3 & a, f32 scalar);
neV3 CAPI V3MulV3(const neV3 & a,const neV3 & b);
neV3 CAPI V3MulM3(const neV3 & v,const neM3 & m3);
neV3 CAPI V3AddMul(const neV3 & a,const neV3 & b,f32 t);
f32  CAPI V3Dot(const neV3 & a,const neV3 & b);
neV3 CAPI V3Cross(const neV3 & a,const neV3 & b);
neV3 CAPI V3NormalizedCross(const neV3 & a,const neV3 & b);
void CAPI V3Project(neV3 & a,const neV3 & b);
neV3 CAPI V3Projected(const neV3 & a,const neV3 & b);

float CAPI V3LengthSquared(const neV3 & v);
float CAPI V3Length(const neV3 & v);
float CAPI V3DistanceSquared(const neV3 & a,const neV3 & b);
float CAPI V3Distance(const neV3 & a,const neV3 & b);

void CAPI V3Normalize(neV3 & v);
neV3 CAPI V3Normalized(const neV3 & v);
void CAPI V3RotateX(neV3 & v, f32 deg);
void CAPI V3RotateY(neV3 & v, f32 deg);
void CAPI V3RotateZ(neV3 & v, f32 deg);
neV3 CAPI V3RotatedX(const neV3 & v, f32 deg);
neV3 CAPI V3RotatedY(const neV3 & v, f32 deg);
neV3 CAPI V3RotatedZ(const neV3 & v, f32 deg);

/// neV3 tools
f32  CAPI V3GetPitch(const neV3 & v);
f32  CAPI V3GetYaw(const neV3 & v);
neV3 CAPI V3Lerp(const neV3 & a, const neV3 & b,f32 t);
neV3 CAPI V3Between(const neV3 & a, const neV3 & b);
f32  CAPI V3GetDistanceToLine(const neV3 & v,const neV3 & a,const neV3 & b);
f32  CAPI V3GetDistanceAndNearestPointOnLine(const neV3 & v,const neV3 & a,const neV3 & b, neV3 & nearest);
f32  CAPI V3GetDistanceAndNearestPointOnRay(const neV3 & v,const neV3 & origin,const neV3 & direction, neV3 & nearest);
void CAPI V3ChooseAxis(neV3 & normalizedAxis, neV3 & crossAxis, const neV3 & normal);
void CAPI V3RemoveComponent(neV3 & v, f32 x, f32 y, f32 z);
void CAPI V3RemoveComponentV3(neV3 & v, const neV3 & o);


/********
 * neM3 *
 *******/
 //! create matrix from pitch yaw roll
neM3 CAPI CreateIdentityMatrix(void);
//! create matrix from pitch yaw roll
neM3 CAPI CreateRotMatrix(f32 p, f32 y, f32 r);
//! create matrix from pitch yaw roll vector
neM3 CAPI CreateRotMatrixV3(const neV3 & pyr);
//! create matrix from quaternion
neM3 CAPI CreateRotMatrixQ(const neQ & q);
//! create matrix from Axis and angle
neM3 CAPI CreateRotMatrixAxisAngle(f32 axisx, f32 axisy, f32 axisz, f32 degAngle);
//! create matrix from Axis and angle vector
neM3 CAPI CreateRotMatrixAxisAngleV3(const neV3 & axis, f32 degAngle);
neM3 CAPI CreateRotXMatrix(f32 deg);
neM3 CAPI CreateRotYMatrix(f32 deg);
neM3 CAPI CreateRotZMatrix(f32 deg);
neM3 CAPI CreateRotXYZMatrix(f32 xdeg,f32 ydeg,f32 zdeg);
//! get pitch yaw roll from matrix
void CAPI M3GetRotAngle(const neM3 & m3, f32 & rp, f32 & ry, f32 & rr);
//! get pitch yaw roll vector from matrix
neV3 CAPI M3GetRotAngleV3(const neM3 & m3);

void CAPI M3SetIdentity(neM3 & m3);
void CAPI M3SetTranspose(neM3 & m3);
neM3 CAPI M3GetTranspose(const neM3 & m3);

neM3 CAPI M3Add(const neM3 & a, const neM3 & b);
neM3 CAPI M3Sub(const neM3 & a, const neM3 & b);
neM3 CAPI M3Mul(const neM3 & a, f32 scalar);
neV3 CAPI M3MulV3(const neM3 & m, const neV3 v);
neV3 CAPI M3TransposeMulV3(const neM3 & m, const neV3 v);
neM3 CAPI M3MulM3(const neM3 & a, const neM3 & b);
neM3 CAPI M3Mul3(const neM3 & a, const neM3 & b, const neM3 & c);
neM3 CAPI M3Mul4(const neM3 & a, const neM3 & b, const neM3 & c, const neM3 & d);
neM3 CAPI M3Lerp(const neM3 & ma, const neM3 & mb,f32 t);
bool CAPI M3SetInverse(neM3 & m3);
neM3 CAPI M3GetInverse(const neM3 & m3);
/// neM3 tools
neV3 CAPI M3RotateVector(const neM3 & m3, const neV3 & v);
void CAPI M3RotateVectors(const neM3 & m3, neV3 * d, const neV3 * s, s32 n);
void CAPI M3InverseRotateVectors(const neM3 & m3, neV3 * d, const neV3 * s, s32 n);

/********
 * neT3 *
 *******/
neT3 CAPI CreateIdentityTransform(void);
void CAPI T3SetIdentiy(neT3 & t);
void CAPI T3SetPosition(neT3 & t, f32 px, f32 py, f32 pz);
void CAPI T3SetPositionV3(neT3 & t, const neV3 & pos);
void CAPI T3SetRotation(neT3 & t, f32 rp, f32 ry, f32 rr);
void CAPI T3SetRotationV3(neT3 & t, const neV3 & rot);
void CAPI T3SetRotationM3(neT3 & t, const neM3 & rot);
void CAPI T3SetPositionRotation(neT3 & t, f32 px, f32 py, f32 pz, f32 rp, f32 ry, f32 rr);
void CAPI T3SetPositionRotationV3(neT3 & t, const neV3 & pos, const neV3 & rot);
void CAPI T3SetPositionRotationM3(neT3 & t, const neV3 & pos, const neM3 & rot);

neV3 CAPI T3MulV3(const neT3 & t, const neV3 & v);
neT3 CAPI T3MulT3(const neT3 & a, const neT3 & b);
neT3 CAPI T3Mul3(const neT3 & a, const neT3 & b, const neT3 & c);
neT3 CAPI T3Mul4(const neT3 & a, const neT3 & b, const neT3 & c, const neT3 & d);
void CAPI T3SetInverse(neT3 & t);
neT3 CAPI T3GetInverse(const neT3 & t);
/// neT3 tools
void CAPI T3GetOpenGLMatrix(const neT3 & t, f32 * p);
void CAPI T3GetInverseOpenGLMatrix(const neT3 & t, f32 * p);
neV3 CAPI T3RotateVector(const neT3 & t, const neV3 & v);
neV3 CAPI T3TransformVector(const neT3 & t, const neV3 & v);
void CAPI T3RotateVectors(const neT3 & t, neV3 * d, const neV3 * s, s32 n);
void CAPI T3TransformVectors(const neT3 & t, neV3 * d, const neV3 * s, s32 n);
void CAPI T3InverseRotateVectors(const neT3 & t, neV3 * d, const neV3 * s, s32 n);
void CAPI T3InverseTransformVectors(const neT3 & t, neV3 * d, const neV3 * s, s32 n);

/*******
 * neQ *
 ******/
neQ  CAPI CreateQuaternion(f32 x, f32 y, f32 z, f32 w);
neQ  CAPI CreateQuaternionV3(const neV3 & xyz, f32 w);
neQ  CAPI CreateQuaternionM3(const neM3 & m);
neQ  CAPI CreateQuaternionAxisAngle(const neV3 & axis, f32 angle);
void CAPI QNormalize(neQ & q);
neQ  CAPI QNormalized(const neQ & q);
neQ  CAPI QMulQ(const neQ & a, const neQ & b);
neQ  CAPI QMul3(const neQ & a, const neQ & b, const neQ & c);
neQ  CAPI QMul4(const neQ & a, const neQ & b, const neQ & c, const neQ & d);
void CAPI QGetAxisAngle(const neQ & q, f32 & axisx, f32 & axisy, f32 & axisz, f32 & angle);
void CAPI QGetAxisAngleV3(const neQ & q, neV3& axis, f32 & angle);
neQ  CAPI QLerp(const neQ & a, const neQ & b,f32 t);


#ifdef __cplusplus
}
#endif

#endif //! __tokamak_c_wrapper_h__
