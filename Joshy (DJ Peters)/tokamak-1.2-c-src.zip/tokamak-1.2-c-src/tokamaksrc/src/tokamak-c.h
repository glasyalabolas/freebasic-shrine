#ifndef __tokamak_c_h__
#define __tokamak_c_h__

#include "math/ne_type.h"
#include "math/ne_debug.h"
#include "tokamak.h"
#include "containers.h"
#include "scenery.h"
#include "collision.h"
#include "constraint.h"
#include "rigidbody.h"
#include "stack.h"
#include "simulator.h"
#include "message.h"
#include "Matrix3D.h"

#ifdef TOKAMAK_IMPORT_DLL
 #define CAPI __declspec(dllimport)
#else
 #define CAPI
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef f32 float;


typedef neSimulator void;
typedef neGeometry  void;
typedef neAnimatedBody void;
typedef neRigidBody void;
typedef neJoint void;
typedef neSensor void;

typedef neV3 neV3;
struct neV3 {
  f32 x,y,z,pad
};
  

#ifdef __cplusplus
}
#endif

#endif //! __tokamak_c_h__
